// ── Typed API client ─────────────────────────────────────────────────────────
// All requests flow through `request()`. Each public method is a thin wrapper.

const API_BASE = '/api'

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...init?.headers },
    ...init,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }))
    throw new Error(err.error || `HTTP ${res.status}`)
  }
  return res.json()
}

// Root-path request (for /login and /logout which don't have /api prefix)
async function rootRequest<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    headers: { 'Content-Type': 'application/json', ...init?.headers },
    ...init,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }))
    throw new Error(err.error || `HTTP ${res.status}`)
  }
  return res.json().catch(() => ({} as T))
}

export interface LoginResponse {
  ok: boolean
  rol: string
  nombre: string
  perms: Record<string, string>
}

export interface MeResponse {
  auth: boolean
  nombre: string
  rol: string
  perms: Record<string, string>
}

export const api = {
  // Generic methods
  get:    <T>(path: string)             => request<T>(path),
  post:   <T>(path: string, body: any)  => request<T>(path, { method: 'POST',   body: JSON.stringify(body) }),
  put:    <T>(path: string, body: any)  => request<T>(path, { method: 'PUT',    body: JSON.stringify(body) }),
  delete: <T>(path: string)             => request<T>(path, { method: 'DELETE' }),

  // Auth — root-level routes, not under /api
  login: (username: string, password: string) =>
    rootRequest<LoginResponse>('/login', { method: 'POST', body: JSON.stringify({ username, password }) }),
  logout: () => rootRequest<{ ok: boolean }>('/logout', { method: 'GET' }),
  me:     () => request<MeResponse>('/me'),
}
