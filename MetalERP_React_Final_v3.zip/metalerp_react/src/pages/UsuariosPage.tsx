import { useState } from 'react'
import { Trash2 } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field } from '../components/ui'
import type { BadgeVariant } from '../components/ui'

interface Usuario {
  id: number; username: string; nombre: string
  rol: string; activo: number; creado: string
}

const ROLES = ['admin', 'operario', 'vendedor', 'almacen']
const ROL_VARIANT: Record<string, BadgeVariant> = {
  admin: 'red', operario: 'blue', vendedor: 'green', almacen: 'amber',
}

export default function UsuariosPage() {
  const toast = useToast()
  const { loading, reload, rows } = useResource<Usuario>({
    path: '/usuarios', errorMsg: 'Error cargando usuarios',
  })
  const [open, setOpen] = useState(false)
  const { values, bind, reset } = useForm({ username: '', password: '', nombre: '', rol: 'operario' })

  function openNew() {
    reset({ username: '', password: '', nombre: '', rol: 'operario' })
    setOpen(true)
  }

  async function save() {
    if (!values.username || !values.password || !values.nombre) {
      toast('Todos los campos requeridos', 'warn'); return
    }
    try {
      await api.post('/usuarios', values)
      toast('Usuario creado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function del(u: Usuario) {
    if (!window.confirm(`¿Eliminar al usuario ${u.username}? Esta acción es definitiva.`)) return
    try { await api.delete(`/usuarios/${u.id}`); toast('Usuario eliminado'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Usuarios del sistema"
        onReload={reload} primaryLabel="Nuevo usuario" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : rows.length === 0
          ? <EmptyState title="Sin usuarios" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Usuario</th><th>Nombre</th><th>Rol</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{rows.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.username}</td>
                  <td style={{ fontSize: 13 }}>{r.nombre}</td>
                  <td><Badge value={r.rol} variant={ROL_VARIANT[r.rol] || 'gray'} /></td>
                  <td><Badge value={r.activo ? 'Activo' : 'Inactivo'} /></td>
                  <td>
                    <button className="btn btn-xs btn-danger" onClick={() => del(r)} title="Eliminar">
                      <Trash2 size={11} />
                    </button>
                  </td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Nuevo usuario"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Crear usuario</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Usuario" required>
            <input className="form-input" {...bind('username')} placeholder="jperez" />
          </Field>
          <Field label="Rol">
            <select className="form-select" {...bind('rol')}>
              {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </Field>
          <Field label="Nombre completo" required span2>
            <input className="form-input" {...bind('nombre')} />
          </Field>
          <Field label="Contraseña" required span2>
            <input className="form-input" type="password" {...bind('password')} />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
