import { useState, useEffect } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, fmtDate } from '../components/ui'

interface Lote {
  id: number; numero: string; material_id: number
  mat_codigo: string; mat_descripcion: string; mat_unidad: string
  cantidad_original: number; cantidad_disponible: number; cantidad_activa: number
  estado: string; proveedor_id: number | null; proveedor_nombre: string | null
  referencia_proveedor: string | null; certificado: string | null; fecha_ingreso: string
}

interface Material { id: number; codigo: string; descripcion: string; unidad: string }

const ESTADOS = ['Ingresado', 'Aprobado', 'Rechazado', 'Agotado']

export default function LotesPage() {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('')
  const { loading, search, setSearch, reload, filtered, rows: _rows } = useResource<Lote>({
    path: estFilter ? `/lotes?estado=${estFilter}` : '/lotes',
    searchKeys: ['numero', 'mat_codigo', 'mat_descripcion'],
    errorMsg: 'Error cargando lotes',
  })
  const [mats, setMats] = useState<Material[]>([])
  const [open, setOpen] = useState(false)
  const { values, bind, reset } = useForm({ material_id: '', cantidad: '', referencia_proveedor: '', certificado: '', obs: '' })

  useEffect(() => { void _rows }, [_rows])

  async function openNew() {
    if (!mats.length) setMats(await api.get<Material[]>('/materiales?categoria=Material'))
    reset({ material_id: '', cantidad: '', referencia_proveedor: '', certificado: '', obs: '' })
    setOpen(true)
  }

  async function save() {
    if (!values.material_id || !values.cantidad) { toast('Material y cantidad requeridos', 'warn'); return }
    try {
      await api.post('/lotes', {
        material_id: Number(values.material_id),
        cantidad: Number(values.cantidad),
        referencia_proveedor: values.referencia_proveedor || null,
        certificado: values.certificado || null,
      })
      toast('Lote creado'); setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Lotes"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar lote..."
        onReload={reload} primaryLabel="Nuevo lote" onPrimary={openNew}
        rightChildren={
          <select className="form-select" style={{ width: 160 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
            <option value="">Todos los estados</option>
            {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin lotes" desc="Ingresá el primer lote de materia prima" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>N° Lote</th><th>Material</th><th>Original</th><th>Disponible</th>
                <th>Aprobado</th><th>Sin aprobar</th><th>Proveedor</th><th>Certificado</th><th>Ingreso</th><th>Estado</th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const sinAprobar = r.cantidad_disponible - r.cantidad_activa
                return (
                  <tr key={r.id}>
                    <td className="cell-mono">{r.numero}</td>
                    <td style={{ fontSize: 12 }}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                    <td style={{ fontSize: 12 }}>{r.cantidad_original} {r.mat_unidad}</td>
                    <td style={{ fontSize: 12, fontWeight: 600 }}>{r.cantidad_disponible}</td>
                    <td style={{ fontSize: 12, color: 'var(--c-green)', fontWeight: 600 }}>{r.cantidad_activa}</td>
                    <td style={{ fontSize: 12, color: sinAprobar > 0 ? 'var(--c-amber)' : 'var(--c-text-3)' }}>{sinAprobar.toFixed(2)}</td>
                    <td style={{ fontSize: 12 }}>{r.proveedor_nombre || r.referencia_proveedor || '—'}</td>
                    <td style={{ fontSize: 12 }}>{r.certificado || '—'}</td>
                    <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_ingreso)}</td>
                    <td><Badge value={r.estado} /></td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Nuevo ingreso de lote"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Material" required span2>
            <select className="form-select" {...bind('material_id')}>
              <option value="">— Seleccionar —</option>
              {mats.map(m => <option key={m.id} value={m.id}>{m.codigo} — {m.descripcion}</option>)}
            </select>
          </Field>
          <Field label="Cantidad" required><input className="form-input" type="number" min="0.01" step="0.01" {...bind('cantidad')} /></Field>
          <Field label="Referencia proveedor"><input className="form-input" {...bind('referencia_proveedor')} /></Field>
          <Field label="Certificado" span2>
            <input className="form-input" {...bind('certificado')} placeholder="N° de certificado de calidad" />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
