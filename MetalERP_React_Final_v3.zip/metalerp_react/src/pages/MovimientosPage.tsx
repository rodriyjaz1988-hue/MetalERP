import { useState } from 'react'
import { ArrowDown, ArrowUp } from 'lucide-react'
import { useResource } from '../hooks/useResource'
import { PageLoading, EmptyState, Toolbar, Card, fmtDate } from '../components/ui'

type MovTipo = 'entrada' | 'salida' | 'ajuste'

interface Mov {
  id: number; fecha: string; tipo: MovTipo
  material_id: number; mat_codigo: string; mat_descripcion: string; mat_unidad: string
  lote_id: number | null; lote_numero: string | null
  cantidad: number; referencia: string | null; usuario_nombre: string | null
}

const TIPO_COLOR: Record<MovTipo, string> = { entrada: 'green', salida: 'red', ajuste: 'amber' }
const TIPO_PREFIX: Record<MovTipo, string> = { entrada: '+', salida: '−', ajuste: '±' }

function TipoIcon({ tipo }: { tipo: MovTipo }) {
  if (tipo === 'entrada') return <ArrowDown size={11} />
  if (tipo === 'salida') return <ArrowUp size={11} />
  return null
}

export default function MovimientosPage() {
  const [tipoFilter, setTipoFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<Mov>({
    path: '/movimientos',
    searchKeys: ['mat_codigo', 'mat_descripcion', 'referencia'],
    filter: r => !tipoFilter || r.tipo === tipoFilter,
    errorMsg: 'Error cargando movimientos',
  })

  return (
    <div className="page">
      <Toolbar
        title="Movimientos de inventario"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar material..."
        onReload={reload}
        rightChildren={
          <select className="form-select" style={{ width: 140 }} value={tipoFilter} onChange={e => setTipoFilter(e.target.value)}>
            <option value="">Todos los tipos</option>
            <option value="entrada">Entradas</option>
            <option value="salida">Salidas</option>
            <option value="ajuste">Ajustes</option>
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin movimientos" desc="Aún no hay movimientos de inventario registrados" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Fecha</th><th>Tipo</th><th>Material</th><th>Lote</th>
                <th>Cantidad</th><th>Referencia</th><th>Usuario</th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const color = TIPO_COLOR[r.tipo]
                return (
                  <tr key={r.id}>
                    <td style={{ fontSize: 12 }}>{fmtDate(r.fecha)}</td>
                    <td>
                      <span className={`badge badge-${color}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 3 }}>
                        <TipoIcon tipo={r.tipo} /> {r.tipo}
                      </span>
                    </td>
                    <td style={{ fontSize: 12 }}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                    <td className="cell-mono">{r.lote_numero || '—'}</td>
                    <td style={{
                      fontSize: 13, fontWeight: 600,
                      color: color === 'green' ? 'var(--c-green)' : color === 'red' ? 'var(--c-red)' : undefined,
                    }}>
                      {TIPO_PREFIX[r.tipo]}{Math.abs(r.cantidad)} {r.mat_unidad}
                    </td>
                    <td style={{ fontSize: 12 }}>{r.referencia || '—'}</td>
                    <td style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{r.usuario_nombre || '—'}</td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>
    </div>
  )
}
