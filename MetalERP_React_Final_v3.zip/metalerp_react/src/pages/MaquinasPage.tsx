import { useEffect, useState } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field } from '../components/ui'

interface Cat { id: number; nombre: string }
interface Maq {
  id: number; codigo: string; nombre: string
  categoria_id: number | null; categoria_nombre: string | null
  ubicacion: string | null; estado: string
}

const ESTADOS = ['Operativa', 'En mantenimiento', 'Fuera de servicio']
const EMPTY = { codigo: '', nombre: '', categoria_id: '', ubicacion: '', estado: 'Operativa', obs: '' }

export default function MaquinasPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<Maq>({
    path: '/maquinas', searchKeys: ['codigo', 'nombre'], errorMsg: 'Error cargando máquinas',
  })
  const [cats, setCats] = useState<Cat[]>([])
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Maq | null>(null)
  const { values, bind, reset } = useForm(EMPTY)

  useEffect(() => { api.get<Cat[]>('/categorias_maquina').then(setCats).catch(() => {}) }, [])

  function openNew() { setEditing(null); reset(EMPTY); setOpen(true) }
  function openEdit(m: Maq) {
    setEditing(m)
    reset({ codigo: m.codigo, nombre: m.nombre, categoria_id: String(m.categoria_id ?? ''),
            ubicacion: m.ubicacion || '', estado: m.estado, obs: '' })
    setOpen(true)
  }

  async function save() {
    if (!values.codigo || !values.nombre) { toast('Código y nombre requeridos', 'warn'); return }
    const body = { ...values, categoria_id: values.categoria_id ? Number(values.categoria_id) : null }
    try {
      editing ? await api.put(`/maquinas/${editing.id}`, body) : await api.post('/maquinas', body)
      toast(editing ? 'Máquina actualizada' : 'Máquina creada')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Máquinas"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar máquina..."
        onReload={reload} primaryLabel="Nueva máquina" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin máquinas" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Código</th><th>Nombre</th><th>Categoría</th>
                <th>Ubicación</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.codigo}</td>
                  <td style={{ fontSize: 13 }}>{r.nombre}</td>
                  <td style={{ fontSize: 12 }}>{r.categoria_nombre || '—'}</td>
                  <td style={{ fontSize: 12 }}>{r.ubicacion || '—'}</td>
                  <td><Badge value={r.estado} /></td>
                  <td><button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button></td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar ${editing.codigo}` : 'Nueva máquina'}
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Código" required>
            <input className="form-input" {...bind('codigo')} placeholder="MAQ-001" />
          </Field>
          <Field label="Categoría">
            <select className="form-select" {...bind('categoria_id')}>
              <option value="">— Sin categoría —</option>
              {cats.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
          </Field>
          <Field label="Nombre" required span2>
            <input className="form-input" {...bind('nombre')} />
          </Field>
          <Field label="Ubicación"><input className="form-input" {...bind('ubicacion')} /></Field>
          <Field label="Estado">
            <select className="form-select" {...bind('estado')}>
              {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </Field>
        </div>
      </Modal>
    </div>
  )
}
