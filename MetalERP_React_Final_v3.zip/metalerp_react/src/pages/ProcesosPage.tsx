import { useState, useEffect } from 'react'
import { Eye } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import {
  Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field,
  fmtMoney,
} from '../components/ui'

interface Cat { id: number; nombre: string }
interface Cliente { id: number; razon: string }

interface Op {
  id: number; orden: number; nombre: string; descripcion: string | null
  es_tercerizada: number; proveedor_nombre: string | null
  tiempo_setup_min: number; tiempo_ciclo_min: number
  maq_nombre: string | null; cat_maq_nombre: string | null
  materiales: { codigo: string; descripcion: string; cantidad: number; unidad: string }[]
  productos_insumo: { codigo: string; descripcion: string; cantidad: number; unidad: string }[]
}

interface Producto {
  id: number; codigo: string; nombre: string; descripcion: string | null
  categoria_id: number | null; categoria_nombre: string | null
  cliente_id: number | null; cliente_nombre: string | null
  unidad: string; precio_venta: number; peso_kg: number
  tiempo_ciclo_total_min: number | null; activo: number
  operaciones?: Op[]
}

const EMPTY = {
  codigo: '', nombre: '', descripcion: '', categoria_id: '', cliente_id: '',
  unidad: 'unid', precio_venta: '0', peso_kg: '0', obs: '',
}

function OpRow({ op, idx }: { op: Op; idx: number }) {
  return (
    <div style={{
      border: '1px solid var(--c-border)', borderRadius: 10, padding: 14,
      background: op.es_tercerizada ? 'var(--c-amber-bg)' : 'var(--c-surface)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <div style={{
          width: 28, height: 28, borderRadius: '50%', background: 'var(--c-primary)', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 700, flexShrink: 0,
        }}>{idx + 1}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 600, fontSize: 14 }}>{op.nombre}</div>
          {op.descripcion && <div style={{ fontSize: 12, color: 'var(--c-text-3)' }}>{op.descripcion}</div>}
        </div>
        {op.es_tercerizada
          ? <Badge value="Tercerizada" variant="amber" />
          : <span style={{ fontSize: 11, color: 'var(--c-text-3)' }}>
              Setup: {op.tiempo_setup_min} min · Ciclo: {Math.round(op.tiempo_ciclo_min * 60)} seg
            </span>}
      </div>
      <div style={{ display: 'flex', gap: 16, fontSize: 12, flexWrap: 'wrap' }}>
        {op.maq_nombre && <span style={{ color: 'var(--c-text-3)' }}>🔧 {op.maq_nombre}</span>}
        {op.proveedor_nombre && <span style={{ color: 'var(--c-amber)' }}>🏭 {op.proveedor_nombre}</span>}
        {op.materiales?.map(m => (
          <span key={m.codigo} className="counter-pill counter-pill-blue" style={{ fontSize: 11 }}>
            {m.codigo} ×{m.cantidad} {m.unidad}
          </span>
        ))}
        {op.productos_insumo?.map(p => (
          <span key={p.codigo} className="counter-pill counter-pill-blue" style={{ fontSize: 11 }}>
            📦 {p.codigo} ×{p.cantidad}
          </span>
        ))}
      </div>
    </div>
  )
}

export default function ProcesosPage() {
  const toast = useToast()
  const [cliFilter, setCliFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<Producto>({
    path: '/productos' + (cliFilter ? `?cliente_id=${cliFilter}` : ''),
    searchKeys: ['codigo', 'nombre'],
    errorMsg: 'Error cargando productos',
  })
  const [cats, setCats] = useState<Cat[]>([])
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [showModal, setShowModal] = useState(false)
  const [verProc, setVerProc] = useState<Producto | null>(null)
  const [loadingProc, setLoadingProc] = useState(false)
  const [editing, setEditing] = useState<Producto | null>(null)
  const { values, bind, reset } = useForm(EMPTY)

  useEffect(() => {
    Promise.all([
      api.get<Cat[]>('/categorias_producto'),
      api.get<Cliente[]>('/clientes'),
    ]).then(([c, cl]) => { setCats(c); setClientes(cl) }).catch(() => {})
  }, [])

  function openNew() { setEditing(null); reset(EMPTY); setShowModal(true) }
  function openEdit(p: Producto) {
    setEditing(p)
    reset({
      codigo: p.codigo, nombre: p.nombre, descripcion: p.descripcion || '',
      categoria_id: String(p.categoria_id ?? ''), cliente_id: String(p.cliente_id ?? ''),
      unidad: p.unidad, precio_venta: String(p.precio_venta),
      peso_kg: String(p.peso_kg), obs: '',
    })
    setShowModal(true)
  }

  async function openVerProc(p: Producto) {
    setVerProc({ ...p, operaciones: undefined })
    setLoadingProc(true)
    try { setVerProc(await api.get<Producto>(`/productos/${p.id}`)) }
    catch { toast('Error cargando proceso', 'error') }
    finally { setLoadingProc(false) }
  }

  async function save() {
    if (!values.codigo || !values.nombre) { toast('Código y nombre requeridos', 'warn'); return }
    const body = {
      ...values,
      categoria_id: values.categoria_id ? Number(values.categoria_id) : null,
      cliente_id: values.cliente_id ? Number(values.cliente_id) : null,
      precio_venta: Number(values.precio_venta),
      peso_kg: Number(values.peso_kg),
    }
    try {
      editing ? await api.put(`/productos/${editing.id}`, body) : await api.post('/productos', body)
      toast(editing ? 'Producto actualizado' : 'Producto creado')
      setShowModal(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Procesos / Productos"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar producto..."
        onReload={reload} primaryLabel="Nuevo producto" onPrimary={openNew}
        rightChildren={
          <select className="form-select" style={{ width: 180 }} value={cliFilter} onChange={e => setCliFilter(e.target.value)}>
            <option value="">Todos los clientes</option>
            {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin productos" desc="Registrá el primer producto terminado" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Código</th><th>Nombre</th><th>Cliente</th><th>Categoría</th>
                <th>Ciclo total</th><th>Peso</th><th>Precio venta</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.codigo}</td>
                  <td style={{ fontSize: 13 }}>{r.nombre}</td>
                  <td style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{r.cliente_nombre || '—'}</td>
                  <td>{r.categoria_nombre ? <Badge value={r.categoria_nombre} variant="gray" /> : '—'}</td>
                  <td style={{ fontSize: 12 }}>{r.tiempo_ciclo_total_min != null ? `${r.tiempo_ciclo_total_min} min` : '—'}</td>
                  <td style={{ fontSize: 12 }}>{r.peso_kg > 0 ? `${r.peso_kg} kg` : '—'}</td>
                  <td style={{ fontSize: 13, fontWeight: 600 }}>{fmtMoney(r.precio_venta)}</td>
                  <td><Badge value={r.activo ? 'Activo' : 'Inactivo'} /></td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-xs btn-primary" onClick={() => openVerProc(r)} title="Ver proceso"><Eye size={11} /></button>
                      <button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button>
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      {/* Edit modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)}
        title={editing ? `Editar: ${editing.codigo}` : 'Nuevo producto terminado'} size="lg"
        footer={<>
          <button className="btn" onClick={() => setShowModal(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Código" required><input className="form-input" {...bind('codigo')} placeholder="PROD-001" /></Field>
          <Field label="Categoría">
            <select className="form-select" {...bind('categoria_id')}>
              <option value="">— Sin categoría —</option>
              {cats.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
          </Field>
          <Field label="Nombre" required span2><input className="form-input" {...bind('nombre')} /></Field>
          <Field label="Cliente (dueño del producto)" span2>
            <select className="form-select" {...bind('cliente_id')}>
              <option value="">— Sin cliente —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select>
          </Field>
          <Field label="Unidad"><input className="form-input" {...bind('unidad')} /></Field>
          <Field label="Precio venta"><input className="form-input" type="number" min="0" step="0.01" {...bind('precio_venta')} /></Field>
          <Field label="Peso (kg)"><input className="form-input" type="number" min="0" step="0.001" {...bind('peso_kg')} /></Field>
          <Field label="Descripción" span2><textarea className="form-textarea" {...bind('descripcion')} /></Field>
        </div>
      </Modal>

      {/* View proceso modal */}
      <Modal open={!!verProc} onClose={() => setVerProc(null)}
        title={verProc ? `Proceso: ${verProc.codigo} — ${verProc.nombre}` : ''} size="xl"
        footer={<button className="btn" onClick={() => setVerProc(null)}>Cerrar</button>}
      >
        {loadingProc ? <PageLoading /> : verProc && (
          <>
            <div className="kv-grid kv-grid-3" style={{ marginBottom: 20 }}>
              {[
                { label: 'Cliente', value: verProc.cliente_nombre || '—' },
                { label: 'Precio venta', value: fmtMoney(verProc.precio_venta) },
                { label: 'Ciclo total', value: verProc.tiempo_ciclo_total_min != null ? `${verProc.tiempo_ciclo_total_min} min` : '—' },
              ].map(({ label, value }) => (
                <div key={label} className="kv-cell">
                  <div className="kv-label">{label}</div>
                  <div className="kv-value">{value}</div>
                </div>
              ))}
            </div>

            {!verProc.operaciones?.length
              ? <EmptyState title="Sin operaciones" desc="Este producto no tiene operaciones cargadas aún" />
              : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {verProc.operaciones.map((op, idx) => <OpRow key={op.id} op={op} idx={idx} />)}
                </div>
              )}
          </>
        )}
      </Modal>
    </div>
  )
}
