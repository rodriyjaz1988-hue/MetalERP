import { useState } from 'react'
import { Plus, Trash2 } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, PageLoading, Toolbar, Card, Field } from '../components/ui'

interface Cat { id: number; nombre: string; descripcion?: string | null }

function CategoriaSection({ title, endpoint }: { title: string; endpoint: string }) {
  const toast = useToast()
  const { loading, reload, rows } = useResource<Cat>({ path: endpoint, errorMsg: `Error cargando ${title}` })
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Cat | null>(null)
  const { values, bind, reset } = useForm({ nombre: '', descripcion: '' })

  function openNew() { setEditing(null); reset({ nombre: '', descripcion: '' }); setOpen(true) }
  function openEdit(c: Cat) { setEditing(c); reset({ nombre: c.nombre, descripcion: c.descripcion || '' }); setOpen(true) }

  async function save() {
    if (!values.nombre) { toast('Nombre requerido', 'warn'); return }
    try {
      editing
        ? await api.put(`${endpoint}/${editing.id}`, values)
        : await api.post(endpoint, values)
      toast('Guardado'); setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function del(c: Cat) {
    if (!window.confirm(`¿Eliminar "${c.nombre}"?`)) return
    try { await api.delete(`${endpoint}/${c.id}`); toast('Eliminado'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <Card title={title} action={
      <button className="btn btn-sm btn-primary" onClick={openNew}><Plus size={12} /> Nuevo</button>
    }>
      {loading ? <PageLoading /> : rows.length === 0 ? (
        <p style={{ color: 'var(--c-text-3)', fontSize: 13 }}>Sin categorías. Creá la primera.</p>
      ) : (
        <table>
          <tbody>{rows.map(r => (
            <tr key={r.id}>
              <td style={{ fontSize: 13, fontWeight: 600 }}>{r.nombre}</td>
              <td style={{ fontSize: 12, color: 'var(--c-text-3)' }}>{r.descripcion || '—'}</td>
              <td style={{ textAlign: 'right' }}>
                <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                  <button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button>
                  <button className="btn btn-xs btn-danger" onClick={() => del(r)}><Trash2 size={10} /></button>
                </div>
              </td>
            </tr>
          ))}</tbody>
        </table>
      )}

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar: ${editing.nombre}` : 'Nueva categoría'}
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Nombre" required span2>
            <input className="form-input" {...bind('nombre')} autoFocus />
          </Field>
          <Field label="Descripción" span2>
            <input className="form-input" {...bind('descripcion')} />
          </Field>
        </div>
      </Modal>
    </Card>
  )
}

export default function ConfiguracionPage() {
  return (
    <div className="page">
      <Toolbar title="Configuración del sistema" />
      <div className="kv-grid kv-grid-2">
        <CategoriaSection title="Categorías de productos" endpoint="/categorias_producto" />
        <CategoriaSection title="Categorías de máquinas" endpoint="/categorias_maquina" />
      </div>
    </div>
  )
}
