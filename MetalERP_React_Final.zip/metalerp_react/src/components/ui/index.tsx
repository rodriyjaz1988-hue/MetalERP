import type { ReactNode } from 'react'
import { X } from 'lucide-react'

// ── Modal ─────────────────────────────────────────────────────────────────────
interface ModalProps {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  footer?: ReactNode
  size?: 'sm' | 'md' | 'lg' | 'xl'
}

const MODAL_WIDTHS = { sm: 420, md: 580, lg: 760, xl: 960 }

export function Modal({ open, onClose, title, children, footer, size = 'md' }: ModalProps) {
  if (!open) return null
  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: MODAL_WIDTHS[size] }}>
        <div className="modal-header">
          <span className="modal-title">{title}</span>
          <button className="modal-close" onClick={onClose}><X size={16}/></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  )
}

// ── Badge ─────────────────────────────────────────────────────────────────────
type BadgeVariant = 'green' | 'amber' | 'red' | 'blue' | 'gray' | 'purple' | 'teal'

const ESTADO_MAP: Record<string, BadgeVariant> = {
  Pendiente: 'amber', 'En proceso': 'blue', Completada: 'green', Cancelada: 'gray',
  Aprobado: 'green', Rechazado: 'red', Ingresado: 'amber', Agotado: 'gray',
  Recibida: 'blue', Confirmada: 'teal', Activo: 'green', Inactivo: 'gray',
  Operativa: 'green', 'En mantenimiento': 'amber', 'Fuera de servicio': 'red',
  Alta: 'red', Normal: 'blue', Crítica: 'red', Borrador: 'gray',
  Enviado: 'blue', Facturado: 'teal', Abierto: 'red', Cerrado: 'gray',
  'Remito emitido': 'blue', Recibido: 'teal',
}

export function Badge({ value, variant }: { value: string; variant?: BadgeVariant }) {
  const v = variant ?? ESTADO_MAP[value] ?? 'gray'
  return <span className={`badge badge-${v}`}>{value}</span>
}

// ── Spinner / Loading ─────────────────────────────────────────────────────────
export function PageLoading({ text = 'Cargando...' }: { text?: string }) {
  return (
    <div className="page-loading">
      <span className="spinner" />
      <span>{text}</span>
    </div>
  )
}

// ── Empty state ───────────────────────────────────────────────────────────────
export function EmptyState({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="empty-state">
      <h3>{title}</h3>
      {desc && <p>{desc}</p>}
      {action && <div style={{ marginTop: 12 }}>{action}</div>}
    </div>
  )
}

// ── Confirm button (inline) ───────────────────────────────────────────────────
export function ConfirmBtn({
  onConfirm, children, danger = true, size = 'sm',
}: { onConfirm: () => void; children: ReactNode; danger?: boolean; size?: 'xs' | 'sm' }) {
  return (
    <button
      className={`btn btn-${size} ${danger ? 'btn-danger' : ''}`}
      onClick={e => { e.stopPropagation(); if (window.confirm('¿Confirmar esta acción?')) onConfirm() }}
    >
      {children}
    </button>
  )
}

// ── SearchInput ───────────────────────────────────────────────────────────────
export function SearchInput({
  value, onChange, placeholder = 'Buscar...',
}: { value: string; onChange: (v: string) => void; placeholder?: string }) {
  return (
    <input
      className="form-input"
      style={{ maxWidth: 260 }}
      placeholder={placeholder}
      value={value}
      onChange={e => onChange(e.target.value)}
    />
  )
}

// ── Helpers ───────────────────────────────────────────────────────────────────
export function fmtDate(s: string | null | undefined): string {
  if (!s) return '—'
  return s.slice(0, 10).split('-').reverse().join('/')
}

export function fmtMoney(n: number | null | undefined): string {
  if (n == null) return '—'
  return '$' + Math.round(n).toLocaleString('es-AR')
}
