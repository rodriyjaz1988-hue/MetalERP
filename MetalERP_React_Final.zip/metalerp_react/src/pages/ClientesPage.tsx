import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState } from '../components/ui'

interface Cliente {
  id: number; razon: string; cuit: string | null; iva: string | null
  rubro: string | null; localidad: string | null; direccion: string | null
  contacto: string | null; cargo: string | null; telefono: string | null
  email: string | null; categoria: string; plazo_pago: string | null; obs: string | null
}

const CATS = ['Regular','Premium','Ocasional','Potencial']
const IVA_CONDS = ['Responsable Inscripto','Monotributista','Exento','Consumidor Final']

const emptyForm = {
  razon:'', cuit:'', iva:'Responsable Inscripto', rubro:'', localidad:'', direccion:'',
  contacto:'', cargo:'', telefono:'', email:'', categoria:'Regular', plazo_pago:'', obs:''
}

export default function ClientesPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Cliente[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Cliente | null>(null)
  const [form, setForm] = useState({...emptyForm})

  const f = (k: keyof typeof emptyForm) => (e: React.ChangeEvent<HTMLInputElement|HTMLSelectElement|HTMLTextAreaElement>) =>
    setForm(prev => ({...prev, [k]: e.target.value}))

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Cliente[]>('/clientes')) }
    catch { toast('Error cargando clientes','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = () => { setEditing(null); setForm({...emptyForm}); setShowModal(true) }

  const openEdit = (c: Cliente) => {
    setEditing(c)
    setForm({ razon:c.razon, cuit:c.cuit||'', iva:c.iva||'Responsable Inscripto', rubro:c.rubro||'',
      localidad:c.localidad||'', direccion:c.direccion||'', contacto:c.contacto||'',
      cargo:c.cargo||'', telefono:c.telefono||'', email:c.email||'',
      categoria:c.categoria, plazo_pago:c.plazo_pago||'', obs:c.obs||'' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.razon) { toast('Razón social requerida','warn'); return }
    try {
      editing ? await api.put(`/clientes/${editing.id}`, form) : await api.post('/clientes', form)
      toast(editing ? 'Cliente actualizado' : 'Cliente registrado')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    return !q || r.razon.toLowerCase().includes(q) || (r.cuit||'').includes(q) || (r.contacto||'').toLowerCase().includes(q)
  })

  const catColor: Record<string,string> = { Premium:'teal', Regular:'blue', Ocasional:'gray', Potencial:'purple' }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Clientes</h2>
        <input className="form-input" style={{ width:240 }} placeholder="Buscar por razón, CUIT..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo cliente</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin clientes" desc="Registrá el primer cliente"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>Razón social</th><th>CUIT</th><th>Contacto</th>
              <th>Teléfono</th><th>Email</th><th>Categoría</th><th>Plazo pago</th><th></th>
            </tr></thead>
            <tbody>{filtered.map(r => (
              <tr key={r.id}>
                <td><b style={{fontSize:13}}>{r.razon}</b></td>
                <td style={{fontSize:12,fontFamily:'monospace'}}>{r.cuit||'—'}</td>
                <td style={{fontSize:12}}>
                  {r.contacto||'—'}
                  {r.cargo && <div style={{fontSize:10,color:'var(--c-text-3)'}}>{r.cargo}</div>}
                </td>
                <td style={{fontSize:12}}>{r.telefono||'—'}</td>
                <td style={{fontSize:12}}>{r.email||'—'}</td>
                <td><Badge value={r.categoria} variant={catColor[r.categoria] as any}/></td>
                <td style={{fontSize:12}}>{r.plazo_pago||'—'}</td>
                <td><button className="btn btn-xs" onClick={()=>openEdit(r)}>Editar</button></td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)}
        title={editing?`Editar: ${editing.razon}`:'Nuevo cliente'} size="lg"
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group col-span-2"><label className="form-label">Razón social *</label>
            <input className="form-input" value={form.razon} onChange={f('razon')} placeholder="Empresa SA"/></div>
          <div className="form-group"><label className="form-label">CUIT</label>
            <input className="form-input" value={form.cuit} onChange={f('cuit')} placeholder="20-12345678-9"/></div>
          <div className="form-group"><label className="form-label">Cond. IVA</label>
            <select className="form-select" value={form.iva} onChange={f('iva')}>
              {IVA_CONDS.map(c=><option key={c} value={c}>{c}</option>)}</select></div>
          <div className="form-group"><label className="form-label">Contacto</label>
            <input className="form-input" value={form.contacto} onChange={f('contacto')}/></div>
          <div className="form-group"><label className="form-label">Cargo</label>
            <input className="form-input" value={form.cargo} onChange={f('cargo')}/></div>
          <div className="form-group"><label className="form-label">Teléfono</label>
            <input className="form-input" value={form.telefono} onChange={f('telefono')}/></div>
          <div className="form-group"><label className="form-label">Email</label>
            <input className="form-input" type="email" value={form.email} onChange={f('email')}/></div>
          <div className="form-group"><label className="form-label">Categoría</label>
            <select className="form-select" value={form.categoria} onChange={f('categoria')}>
              {CATS.map(c=><option key={c} value={c}>{c}</option>)}</select></div>
          <div className="form-group"><label className="form-label">Plazo de pago</label>
            <input className="form-input" value={form.plazo_pago} onChange={f('plazo_pago')} placeholder="30 días, contado..."/></div>
          <div className="form-group col-span-2"><label className="form-label">Observaciones</label>
            <textarea className="form-textarea" value={form.obs} onChange={f('obs')}/></div>
        </div>
      </Modal>
    </div>
  )
}
