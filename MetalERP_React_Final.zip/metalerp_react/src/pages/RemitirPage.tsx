import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtDate } from '../components/ui'

interface Remito {
  id: number; numero: string; cliente_nombre: string
  fecha: string; estado: string; obs: string | null; tipo: string
}

interface Cliente { id: number; razon: string }
interface OC { id: number; numero: string; cliente_id: number }

export default function RemitirPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Remito[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [ocs, setOcs] = useState<OC[]>([])
  const [form, setForm] = useState({ cliente_id:'', orden_cliente_id:'', obs:'' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows((await api.get<Remito[]>('/remitos')).filter(r => r.tipo !== 'traslado_ott')) }
    catch { toast('Error cargando remitos','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = async () => {
    if (!clientes.length) {
      const [cli, oc] = await Promise.all([api.get<Cliente[]>('/clientes'), api.get<OC[]>('/ordenes_cliente')])
      setClientes(cli); setOcs(oc)
    }
    setForm({ cliente_id:'', orden_cliente_id:'', obs:'' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.cliente_id) { toast('Cliente requerido','warn'); return }
    try {
      await api.post('/remitos', {
        cliente_id: Number(form.cliente_id),
        orden_cliente_id: form.orden_cliente_id ? Number(form.orden_cliente_id) : null,
        obs: form.obs,
      })
      toast('Remito creado')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => !search || r.numero.toLowerCase().includes(search.toLowerCase()) || r.cliente_nombre.toLowerCase().includes(search.toLowerCase()))

  const ocsCli = ocs.filter(o => String(o.cliente_id) === form.cliente_id)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Remitir a cliente</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar remito..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo remito</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin remitos" desc="No hay remitos a clientes registrados"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>N° Remito</th><th>Cliente</th><th>Fecha</th><th>Estado</th><th>Observaciones</th>
            </tr></thead>
            <tbody>{filtered.map(r => (
              <tr key={r.id}>
                <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.numero}</b></td>
                <td style={{fontSize:13}}>{r.cliente_nombre}</td>
                <td style={{fontSize:12}}>{fmtDate(r.fecha)}</td>
                <td><Badge value={r.estado}/></td>
                <td style={{fontSize:12,color:'var(--c-text-3)',maxWidth:300,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{r.obs||'—'}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)} title="Nuevo remito a cliente"
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group col-span-2"><label className="form-label">Cliente *</label>
            <select className="form-select" value={form.cliente_id} onChange={e=>setForm(f=>({...f,cliente_id:e.target.value,orden_cliente_id:''}))}>
              <option value="">— Seleccionar cliente —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select></div>
          <div className="form-group col-span-2"><label className="form-label">OC vinculada (opcional)</label>
            <select className="form-select" value={form.orden_cliente_id} onChange={e=>setForm(f=>({...f,orden_cliente_id:e.target.value}))} disabled={!form.cliente_id}>
              <option value="">— Sin OC —</option>
              {ocsCli.map(o => <option key={o.id} value={o.id}>{o.numero}</option>)}
            </select></div>
          <div className="form-group col-span-2"><label className="form-label">Observaciones</label>
            <textarea className="form-textarea" value={form.obs} onChange={e=>setForm(f=>({...f,obs:e.target.value}))}/></div>
        </div>
      </Modal>
    </div>
  )
}
