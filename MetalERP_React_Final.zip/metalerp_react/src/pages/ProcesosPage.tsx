import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, Eye } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtMoney } from '../components/ui'

interface Cat { id: number; nombre: string }
interface Cliente { id: number; razon: string }
interface Op {
  id: number; orden: number; nombre: string; descripcion: string | null
  es_tercerizada: number; proveedor_nombre: string | null
  tiempo_setup_min: number; tiempo_ciclo_min: number
  maq_nombre: string | null; cat_maq_nombre: string | null
  materiales: { codigo: string; descripcion: string; cantidad: number; unidad: string }[]
  productos_insumo: { codigo: string; descripcion: string; cantidad: number; unidad: string }[]
}
interface Producto {
  id: number; codigo: string; nombre: string; descripcion: string | null
  categoria_id: number | null; categoria_nombre: string | null
  cliente_id: number | null; cliente_nombre: string | null
  unidad: string; precio_venta: number; peso_kg: number
  tiempo_ciclo_total_min: number | null; activo: number
  operaciones?: Op[]
}

const emptyForm = {
  codigo: '', nombre: '', descripcion: '', categoria_id: '', cliente_id: '',
  unidad: 'unid', precio_venta: '0', peso_kg: '0', obs: ''
}

export default function ProcesosPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Producto[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [cliFilter, setCliFilter] = useState('')
  const [cats, setCats] = useState<Cat[]>([])
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [showModal, setShowModal] = useState(false)
  const [verProc, setVerProc] = useState<Producto | null>(null)
  const [loadingProc, setLoadingProc] = useState(false)
  const [editing, setEditing] = useState<Producto | null>(null)
  const [form, setForm] = useState({ ...emptyForm })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [p, c, cl] = await Promise.all([
        api.get<Producto[]>('/productos' + (cliFilter ? `?cliente_id=${cliFilter}` : '')),
        api.get<Cat[]>('/categorias_producto'),
        api.get<Cliente[]>('/clientes'),
      ])
      setRows(p); setCats(c); setClientes(cl)
    } catch { toast('Error cargando productos', 'error') }
    finally { setLoading(false) }
  }, [cliFilter])

  useEffect(() => { load() }, [load])

  const openNew = () => {
    setEditing(null); setForm({ ...emptyForm }); setShowModal(true)
  }

  const openEdit = (p: Producto) => {
    setEditing(p)
    setForm({
      codigo: p.codigo, nombre: p.nombre, descripcion: p.descripcion || '',
      categoria_id: String(p.categoria_id ?? ''), cliente_id: String(p.cliente_id ?? ''),
      unidad: p.unidad, precio_venta: String(p.precio_venta),
      peso_kg: String(p.peso_kg), obs: ''
    })
    setShowModal(true)
  }

  const openVerProc = async (p: Producto) => {
    setVerProc({ ...p, operaciones: undefined })
    setLoadingProc(true)
    try {
      const det = await api.get<Producto>(`/productos/${p.id}`)
      setVerProc(det)
    } catch { toast('Error cargando proceso', 'error') }
    finally { setLoadingProc(false) }
  }

  const save = async () => {
    if (!form.codigo || !form.nombre) { toast('Código y nombre requeridos', 'warn'); return }
    const body = {
      ...form,
      categoria_id: form.categoria_id ? Number(form.categoria_id) : null,
      cliente_id: form.cliente_id ? Number(form.cliente_id) : null,
      precio_venta: Number(form.precio_venta),
      peso_kg: Number(form.peso_kg),
    }
    try {
      editing ? await api.put(`/productos/${editing.id}`, body) : await api.post('/productos', body)
      toast(editing ? 'Producto actualizado' : 'Producto creado')
      setShowModal(false); load()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    return !q || r.codigo.toLowerCase().includes(q) || r.nombre.toLowerCase().includes(q)
  })

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, flex: 1 }}>Procesos / Productos</h2>
        <input className="form-input" style={{ width: 220 }} placeholder="Buscar producto..." value={search} onChange={e => setSearch(e.target.value)} />
        <select className="form-select" style={{ width: 180 }} value={cliFilter} onChange={e => setCliFilter(e.target.value)}>
          <option value="">Todos los clientes</option>
          {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14} /></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14} /> Nuevo producto</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {loading ? <PageLoading /> : filtered.length === 0 ? (
          <EmptyState title="Sin productos" desc="Registrá el primer producto terminado" />
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th>Código</th><th>Nombre</th><th>Cliente</th><th>Categoría</th>
                <th>Ciclo total</th><th>Peso</th><th>Precio venta</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>
                {filtered.map(r => (
                  <tr key={r.id}>
                    <td><b style={{ fontFamily: 'monospace', fontSize: 12 }}>{r.codigo}</b></td>
                    <td style={{ fontSize: 13 }}>{r.nombre}</td>
                    <td style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{r.cliente_nombre || '—'}</td>
                    <td>{r.categoria_nombre ? <Badge value={r.categoria_nombre} variant="gray" /> : '—'}</td>
                    <td style={{ fontSize: 12 }}>{r.tiempo_ciclo_total_min != null ? `${r.tiempo_ciclo_total_min} min` : '—'}</td>
                    <td style={{ fontSize: 12 }}>{r.peso_kg > 0 ? `${r.peso_kg} kg` : '—'}</td>
                    <td style={{ fontSize: 13, fontWeight: 600 }}>{fmtMoney(r.precio_venta)}</td>
                    <td><Badge value={r.activo ? 'Activo' : 'Inactivo'} variant={r.activo ? 'green' : 'gray'} /></td>
                    <td>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button className="btn btn-xs btn-primary" onClick={() => openVerProc(r)} title="Ver proceso"><Eye size={11} /></button>
                        <button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Edit/New modal */}
      <Modal open={showModal} onClose={() => setShowModal(false)}
        title={editing ? `Editar: ${editing.codigo}` : 'Nuevo producto terminado'} size="lg"
        footer={<><button className="btn" onClick={() => setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group"><label className="form-label">Código *</label>
            <input className="form-input" value={form.codigo} onChange={e => setForm(f => ({ ...f, codigo: e.target.value }))} placeholder="PROD-001" /></div>
          <div className="form-group"><label className="form-label">Categoría</label>
            <select className="form-select" value={form.categoria_id} onChange={e => setForm(f => ({ ...f, categoria_id: e.target.value }))}>
              <option value="">— Sin categoría —</option>
              {cats.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select></div>
          <div className="form-group col-span-2"><label className="form-label">Nombre *</label>
            <input className="form-input" value={form.nombre} onChange={e => setForm(f => ({ ...f, nombre: e.target.value }))} /></div>
          <div className="form-group col-span-2"><label className="form-label">Cliente (dueño del producto)</label>
            <select className="form-select" value={form.cliente_id} onChange={e => setForm(f => ({ ...f, cliente_id: e.target.value }))}>
              <option value="">— Sin cliente —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select></div>
          <div className="form-group"><label className="form-label">Unidad</label>
            <input className="form-input" value={form.unidad} onChange={e => setForm(f => ({ ...f, unidad: e.target.value }))} /></div>
          <div className="form-group"><label className="form-label">Precio venta</label>
            <input className="form-input" type="number" min="0" step="0.01" value={form.precio_venta} onChange={e => setForm(f => ({ ...f, precio_venta: e.target.value }))} /></div>
          <div className="form-group"><label className="form-label">Peso (kg)</label>
            <input className="form-input" type="number" min="0" step="0.001" value={form.peso_kg} onChange={e => setForm(f => ({ ...f, peso_kg: e.target.value }))} /></div>
          <div className="form-group col-span-2"><label className="form-label">Descripción</label>
            <textarea className="form-textarea" value={form.descripcion} onChange={e => setForm(f => ({ ...f, descripcion: e.target.value }))} /></div>
        </div>
      </Modal>

      {/* Ver proceso modal */}
      <Modal open={!!verProc} onClose={() => setVerProc(null)}
        title={verProc ? `Proceso: ${verProc.codigo} — ${verProc.nombre}` : ''} size="xl"
        footer={<button className="btn" onClick={() => setVerProc(null)}>Cerrar</button>}
      >
        {loadingProc ? <PageLoading /> : verProc && (
          <div>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 12, marginBottom: 20 }}>
              {[
                ['Cliente', verProc.cliente_nombre || '—'],
                ['Precio venta', fmtMoney(verProc.precio_venta)],
                ['Ciclo total', verProc.tiempo_ciclo_total_min != null ? `${verProc.tiempo_ciclo_total_min} min` : '—'],
              ].map(([l, v]) => (
                <div key={l} style={{ background: 'var(--c-bg)', borderRadius: 8, padding: '10px 14px' }}>
                  <div style={{ fontSize: 11, color: 'var(--c-text-3)', marginBottom: 2 }}>{l}</div>
                  <div style={{ fontSize: 14, fontWeight: 600 }}>{v}</div>
                </div>
              ))}
            </div>

            {!verProc.operaciones?.length ? (
              <EmptyState title="Sin operaciones" desc="Este producto no tiene operaciones cargadas aún" />
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {verProc.operaciones.map((op, idx) => (
                  <div key={op.id} style={{ border: '1px solid var(--c-border)', borderRadius: 10, padding: 14, background: op.es_tercerizada ? '#FFF7ED' : 'var(--c-surface)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
                      <div style={{ width: 28, height: 28, borderRadius: '50%', background: 'var(--c-primary)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700, flexShrink: 0 }}>{idx + 1}</div>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, fontSize: 14 }}>{op.nombre}</div>
                        {op.descripcion && <div style={{ fontSize: 12, color: 'var(--c-text-3)' }}>{op.descripcion}</div>}
                      </div>
                      {op.es_tercerizada ? (
                        <Badge value="Tercerizada" variant="amber" />
                      ) : (
                        <span style={{ fontSize: 11, color: 'var(--c-text-3)' }}>
                          Setup: {op.tiempo_setup_min} min · Ciclo: {Math.round(op.tiempo_ciclo_min * 60)} seg
                        </span>
                      )}
                    </div>
                    <div style={{ display: 'flex', gap: 16, fontSize: 12, flexWrap: 'wrap' }}>
                      {op.maq_nombre && <span style={{ color: 'var(--c-text-3)' }}>🔧 {op.maq_nombre}</span>}
                      {op.proveedor_nombre && <span style={{ color: 'var(--c-amber)' }}>🏭 {op.proveedor_nombre}</span>}
                      {op.materiales?.map(m => (
                        <span key={m.codigo} style={{ background: 'var(--c-blue-bg)', color: 'var(--c-blue)', padding: '1px 7px', borderRadius: 12, fontSize: 11 }}>
                          {m.codigo} ×{m.cantidad} {m.unidad}
                        </span>
                      ))}
                      {op.productos_insumo?.map(p => (
                        <span key={p.codigo} style={{ background: 'var(--c-primary-lt)', color: 'var(--c-primary)', padding: '1px 7px', borderRadius: 12, fontSize: 11 }}>
                          📦 {p.codigo} ×{p.cantidad}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  )
}
