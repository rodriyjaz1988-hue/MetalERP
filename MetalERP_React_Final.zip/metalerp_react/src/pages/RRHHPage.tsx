import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState } from '../components/ui'

interface Emp {
  id: number; legajo: string; nombre: string; apellido: string | null
  puesto: string | null; tipo: string; estado: string
  telefono: string | null; email: string | null
}

const TIPOS = ['Operario','Supervisor','Administrativo','Gerencial']

export default function RRHHPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Emp[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Emp | null>(null)
  const [form, setForm] = useState({ legajo:'', nombre:'', apellido:'', puesto:'', tipo:'Operario', telefono:'', email:'', estado:'Activo' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Emp[]>('/empleados')) }
    catch { toast('Error cargando empleados','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = () => {
    setEditing(null)
    setForm({ legajo:'', nombre:'', apellido:'', puesto:'', tipo:'Operario', telefono:'', email:'', estado:'Activo' })
    setShowModal(true)
  }

  const openEdit = (e: Emp) => {
    setEditing(e)
    setForm({ legajo:e.legajo, nombre:e.nombre, apellido:e.apellido||'', puesto:e.puesto||'', tipo:e.tipo, telefono:e.telefono||'', email:e.email||'', estado:e.estado })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.nombre) { toast('Nombre requerido','warn'); return }
    try {
      editing ? await api.put(`/empleados/${editing.id}`, form) : await api.post('/empleados', form)
      toast(editing?'Empleado actualizado':'Empleado registrado')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => !search ||
    r.nombre.toLowerCase().includes(search.toLowerCase()) ||
    (r.apellido||'').toLowerCase().includes(search.toLowerCase()) ||
    r.legajo.toLowerCase().includes(search.toLowerCase()))

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Recursos humanos</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar empleado..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo empleado</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin empleados"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>Legajo</th><th>Nombre</th><th>Puesto</th><th>Tipo</th>
              <th>Teléfono</th><th>Email</th><th>Estado</th><th></th>
            </tr></thead>
            <tbody>{filtered.map(r => (
              <tr key={r.id}>
                <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.legajo}</b></td>
                <td style={{fontSize:13}}>{r.nombre} {r.apellido||''}</td>
                <td style={{fontSize:12}}>{r.puesto||'—'}</td>
                <td><Badge value={r.tipo} variant="purple"/></td>
                <td style={{fontSize:12}}>{r.telefono||'—'}</td>
                <td style={{fontSize:12}}>{r.email||'—'}</td>
                <td><Badge value={r.estado}/></td>
                <td><button className="btn btn-xs" onClick={()=>openEdit(r)}>Editar</button></td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)} title={editing?`Editar: ${editing.nombre}`:'Nuevo empleado'}
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group"><label className="form-label">Legajo</label>
            <input className="form-input" value={form.legajo} onChange={e=>setForm(f=>({...f,legajo:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Tipo</label>
            <select className="form-select" value={form.tipo} onChange={e=>setForm(f=>({...f,tipo:e.target.value}))}>
              {TIPOS.map(t=><option key={t} value={t}>{t}</option>)}</select></div>
          <div className="form-group"><label className="form-label">Nombre *</label>
            <input className="form-input" value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Apellido</label>
            <input className="form-input" value={form.apellido} onChange={e=>setForm(f=>({...f,apellido:e.target.value}))}/></div>
          <div className="form-group col-span-2"><label className="form-label">Puesto</label>
            <input className="form-input" value={form.puesto} onChange={e=>setForm(f=>({...f,puesto:e.target.value}))} placeholder="Tornero, soldador..."/></div>
          <div className="form-group"><label className="form-label">Teléfono</label>
            <input className="form-input" value={form.telefono} onChange={e=>setForm(f=>({...f,telefono:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Email</label>
            <input className="form-input" type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))}/></div>
        </div>
      </Modal>
    </div>
  )
}
