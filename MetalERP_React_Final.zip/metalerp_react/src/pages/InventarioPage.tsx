import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, AlertTriangle } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, PageLoading, EmptyState, fmtMoney } from '../components/ui'

interface Material {
  id: number; codigo: string; descripcion: string; categoria: string
  unidad: string; stock: number; stock_min: number; precio_unit: number
  proveedor_id: number | null; activo: number
}

const CATS = ['Material','Herramienta','Consumible','Producto terminado','Semielaborado']

export default function InventarioPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Material[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [catFilter, setCatFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Material | null>(null)
  const [form, setForm] = useState({ codigo:'', descripcion:'', categoria:'Material', unidad:'kg', stock:'0', stock_min:'0', precio_unit:'0', obs:'' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Material[]>('/materiales')) }
    catch { toast('Error cargando materiales', 'error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = () => {
    setEditing(null)
    setForm({ codigo:'', descripcion:'', categoria:'Material', unidad:'kg', stock:'0', stock_min:'0', precio_unit:'0', obs:'' })
    setShowModal(true)
  }

  const openEdit = (m: Material) => {
    setEditing(m)
    setForm({ codigo:m.codigo, descripcion:m.descripcion, categoria:m.categoria, unidad:m.unidad, stock:String(m.stock), stock_min:String(m.stock_min), precio_unit:String(m.precio_unit), obs:'' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.codigo || !form.descripcion) { toast('Código y descripción requeridos','warn'); return }
    const body = { ...form, stock:Number(form.stock), stock_min:Number(form.stock_min), precio_unit:Number(form.precio_unit) }
    try {
      editing ? await api.put(`/materiales/${editing.id}`, body) : await api.post('/materiales', body)
      toast(editing ? 'Material actualizado' : 'Material creado')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    const matchQ = !q || r.codigo.toLowerCase().includes(q) || r.descripcion.toLowerCase().includes(q)
    const matchC = !catFilter || r.categoria === catFilter
    return matchQ && matchC
  })

  const criticos = filtered.filter(r => r.stock <= r.stock_min && r.stock_min > 0).length

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Inventario de materiales</h2>
        {criticos > 0 && (
          <div style={{ display:'flex', alignItems:'center', gap:6, background:'var(--c-red-bg)', color:'var(--c-red)', padding:'5px 12px', borderRadius:8, fontSize:13, fontWeight:600 }}>
            <AlertTriangle size={14}/> {criticos} bajo stock mínimo
          </div>
        )}
        <input className="form-input" style={{ width:220 }} placeholder="Buscar material..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <select className="form-select" style={{ width:170 }} value={catFilter} onChange={e=>setCatFilter(e.target.value)}>
          <option value="">Todas las categorías</option>
          {CATS.map(c => <option key={c} value={c}>{c}</option>)}
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo material</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin materiales" desc="Agregá materiales al inventario"/>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th>Código</th><th>Descripción</th><th>Categoría</th>
                <th>Stock</th><th>Stock mín.</th><th>Unidad</th><th>Precio unit.</th><th></th>
              </tr></thead>
              <tbody>
                {filtered.map(r => {
                  const critico = r.stock <= r.stock_min && r.stock_min > 0
                  return (
                    <tr key={r.id}>
                      <td><b style={{ fontFamily:'monospace', fontSize:12 }}>{r.codigo}</b></td>
                      <td style={{ fontSize:13 }}>{r.descripcion}</td>
                      <td><span className="badge badge-gray" style={{ fontSize:10 }}>{r.categoria}</span></td>
                      <td style={{ fontWeight:critico?700:400, color:critico?'var(--c-red)':undefined }}>
                        {r.stock} {critico && <AlertTriangle size={11} style={{ marginLeft:4, verticalAlign:'middle' }}/>}
                      </td>
                      <td style={{ color:'var(--c-text-3)', fontSize:12 }}>{r.stock_min}</td>
                      <td style={{ fontSize:12 }}>{r.unidad}</td>
                      <td style={{ fontSize:12 }}>{fmtMoney(r.precio_unit)}</td>
                      <td><button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button></td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      <Modal open={showModal} onClose={() => setShowModal(false)}
        title={editing ? `Editar: ${editing.codigo}` : 'Nuevo material'}
        footer={<><button className="btn" onClick={() => setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group"><label className="form-label">Código *</label>
            <input className="form-input" value={form.codigo} onChange={e=>setForm(f=>({...f,codigo:e.target.value}))} placeholder="MAT-001"/></div>
          <div className="form-group"><label className="form-label">Categoría</label>
            <select className="form-select" value={form.categoria} onChange={e=>setForm(f=>({...f,categoria:e.target.value}))}>
              {CATS.map(c=><option key={c} value={c}>{c}</option>)}</select></div>
          <div className="form-group col-span-2"><label className="form-label">Descripción *</label>
            <input className="form-input" value={form.descripcion} onChange={e=>setForm(f=>({...f,descripcion:e.target.value}))} placeholder="Descripción del material"/></div>
          <div className="form-group"><label className="form-label">Stock actual</label>
            <input className="form-input" type="number" value={form.stock} onChange={e=>setForm(f=>({...f,stock:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Stock mínimo</label>
            <input className="form-input" type="number" value={form.stock_min} onChange={e=>setForm(f=>({...f,stock_min:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Unidad</label>
            <input className="form-input" value={form.unidad} onChange={e=>setForm(f=>({...f,unidad:e.target.value}))} placeholder="kg, m, unid..."/></div>
          <div className="form-group"><label className="form-label">Precio unitario</label>
            <input className="form-input" type="number" value={form.precio_unit} onChange={e=>setForm(f=>({...f,precio_unit:e.target.value}))}/></div>
        </div>
      </Modal>
    </div>
  )
}
