import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtMoney } from '../components/ui'

interface SC {
  id: number; numero: string; tipo: string; descripcion: string
  material_id: number | null; mat_nombre: string | null; mat_unidad: string | null
  cantidad: number; unidad: string; urgencia: string; estado: string
  ot_numero: string | null; obs: string | null; creado: string
}
interface Cot {
  id: number; solicitud_id: number; proveedor_nombre: string
  precio_unit: number; plazo_entrega_dias: number | null
  condicion_pago: string | null; seleccionada: number
}

const URGENCIAS = ['Normal', 'Alta', 'Crítica']
export default function SolicitudesPage() {
  const toast = useToast()
  const [rows, setRows] = useState<SC[]>([])
  const [cots, setCots] = useState<Record<number, Cot[]>>({})
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [showCotModal, setShowCotModal] = useState<SC | null>(null)
  const [mats, setMats] = useState<any[]>([])
  const [provs, setProvs] = useState<any[]>([])
  const [form, setForm] = useState({ tipo: 'Productiva', descripcion: '', material_id: '', cantidad: '', unidad: 'kg', urgencia: 'Normal', obs: '' })
  const [cotForm, setCotForm] = useState({ proveedor_id: '', precio_unit: '', plazo_entrega_dias: '3', condicion_pago: '', obs: '' })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [sc, cotsAll] = await Promise.all([
        api.get<SC[]>('/solicitudes_compra'),
        api.get<Cot[]>('/cotizaciones_compra'),
      ])
      setRows(sc)
      const bySC: Record<number, Cot[]> = {}
      cotsAll.forEach(c => { if (!bySC[c.solicitud_id]) bySC[c.solicitud_id] = []; bySC[c.solicitud_id].push(c) })
      setCots(bySC)
    } catch { toast('Error cargando solicitudes', 'error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const toggle = (id: number) => setExpanded(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })

  const openNew = async () => {
    if (!mats.length) setMats(await api.get<any[]>('/materiales'))
    setForm({ tipo: 'Productiva', descripcion: '', material_id: '', cantidad: '', unidad: 'kg', urgencia: 'Normal', obs: '' })
    setShowModal(true)
  }

  const openCot = async (sc: SC) => {
    if (!provs.length) setProvs(await api.get<any[]>('/proveedores'))
    setCotForm({ proveedor_id: '', precio_unit: '', plazo_entrega_dias: '3', condicion_pago: '', obs: '' })
    setShowCotModal(sc)
  }

  const saveSC = async () => {
    if (!form.descripcion || !form.cantidad) { toast('Descripción y cantidad requeridas', 'warn'); return }
    const body = { ...form, cantidad: Number(form.cantidad), material_id: form.material_id ? Number(form.material_id) : null }
    try { await api.post('/solicitudes_compra', body); toast('Solicitud creada'); setShowModal(false); load() }
    catch (e: any) { toast(e.message, 'error') }
  }

  const saveCot = async () => {
    if (!showCotModal || !cotForm.proveedor_id || !cotForm.precio_unit) { toast('Proveedor y precio requeridos', 'warn'); return }
    const body = { solicitud_id: showCotModal.id, ...cotForm, precio_unit: Number(cotForm.precio_unit), plazo_entrega_dias: Number(cotForm.plazo_entrega_dias) }
    try { await api.post('/cotizaciones_compra', body); toast('Cotización cargada'); setShowCotModal(null); load() }
    catch (e: any) { toast(e.message, 'error') }
  }

  const selCot = async (id: number) => {
    try { await api.post(`/cotizaciones_compra/${id}/seleccionar`, {}); toast('Cotización seleccionada'); load() }
    catch (e: any) { toast(e.message, 'error') }
  }

  const filtered = rows.filter(r => !search || r.numero.toLowerCase().includes(search.toLowerCase()) || r.descripcion.toLowerCase().includes(search.toLowerCase()))

  const urgBadge: Record<string, 'red' | 'amber' | 'blue'> = { Crítica: 'red', Alta: 'amber', Normal: 'blue' }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, flex: 1 }}>Solicitudes de compra</h2>
        <input className="form-input" style={{ width: 220 }} placeholder="Buscar SC..." value={search} onChange={e => setSearch(e.target.value)} />
        <button className="btn" onClick={load}><RefreshCw size={14} /></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14} /> Nueva SC</button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {loading ? <PageLoading /> : filtered.length === 0 ? (
          <EmptyState title="Sin solicitudes" desc="Creá la primera solicitud de compra" />
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th style={{ width: 36 }}></th>
              <th>N°</th><th>Tipo</th><th>Descripción / Material</th>
              <th>Cantidad</th><th>Urgencia</th><th>Estado</th><th>Mejor precio</th><th></th>
            </tr></thead>
            <tbody>
              {filtered.map(r => {
                const rcots = cots[r.id] || []
                const minCot = rcots.length ? rcots.reduce((a, b) => a.precio_unit < b.precio_unit ? a : b) : null
                const isExp = expanded.has(r.id)
                return (
                  <>
                    <tr key={r.id}>
                      <td>
                        <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--c-text-3)' }} onClick={() => toggle(r.id)}>
                          {isExp ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                        </button>
                      </td>
                      <td><b style={{ fontFamily: 'monospace', fontSize: 12 }}>{r.numero}</b></td>
                      <td><Badge value={r.tipo} variant={r.tipo === 'Productiva' ? 'blue' : 'purple'} /></td>
                      <td style={{ fontSize: 12 }}>
                        {r.descripcion}
                        {r.mat_nombre && <div style={{ fontSize: 10, color: 'var(--c-text-3)' }}>{r.mat_nombre}</div>}
                      </td>
                      <td style={{ fontSize: 12 }}>{r.cantidad} {r.mat_unidad || r.unidad}</td>
                      <td><Badge value={r.urgencia} variant={urgBadge[r.urgencia]} /></td>
                      <td><Badge value={r.estado} /></td>
                      <td style={{ fontSize: 12 }}>
                        {minCot
                          ? <><b style={{ color: 'var(--c-green)' }}>{fmtMoney(minCot.precio_unit)}</b> <span style={{ color: 'var(--c-text-3)' }}>{minCot.proveedor_nombre}</span></>
                          : <span style={{ color: 'var(--c-text-3)' }}>—</span>}
                      </td>
                      <td><button className="btn btn-xs btn-primary" onClick={() => openCot(r)}>+ Cot.</button></td>
                    </tr>
                    {isExp && (
                      <tr key={`${r.id}-cots`}>
                        <td colSpan={9} style={{ padding: 0 }}>
                          <div style={{ padding: '8px 12px 12px 48px', background: 'var(--c-bg)', borderBottom: '1px solid var(--c-border)' }}>
                            {!rcots.length
                              ? <p style={{ fontSize: 12, color: 'var(--c-text-3)' }}>Sin cotizaciones. Usá "+ Cot." para agregar.</p>
                              : (() => {
                                  const minP = Math.min(...rcots.map(c => c.precio_unit))
                                  return (
                                    <table style={{ fontSize: 11 }}>
                                      <thead><tr><th>Proveedor</th><th>Precio unit.</th><th>Plazo</th><th>Condición</th><th>Total</th><th></th></tr></thead>
                                      <tbody>{rcots.map(c => (
                                        <tr key={c.id} style={{ background: c.precio_unit === minP ? '#EAF3DE' : undefined }}>
                                          <td>{c.proveedor_nombre}</td>
                                          <td style={{ fontWeight: c.precio_unit === minP ? 700 : 400 }}>
                                            {fmtMoney(c.precio_unit)}
                                            {c.precio_unit === minP && <Badge value="✓ Mejor" variant="green" />}
                                          </td>
                                          <td>{c.plazo_entrega_dias || '—'}d</td>
                                          <td>{c.condicion_pago || '—'}</td>
                                          <td>{fmtMoney(c.precio_unit * r.cantidad)}</td>
                                          <td>{c.seleccionada
                                            ? <Badge value="✓ Seleccionada" variant="green" />
                                            : <button className="btn btn-xs btn-primary" onClick={() => selCot(c.id)}>Seleccionar</button>}
                                          </td>
                                        </tr>
                                      ))}</tbody>
                                    </table>
                                  )
                                })()
                            }
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                )
              })}
            </tbody>
          </table></div>
        )}
      </div>

      {/* Nueva SC */}
      <Modal open={showModal} onClose={() => setShowModal(false)} title="Nueva solicitud de compra"
        footer={<><button className="btn" onClick={() => setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={saveSC}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group"><label className="form-label">Tipo</label>
            <select className="form-select" value={form.tipo} onChange={e => setForm(f => ({ ...f, tipo: e.target.value }))}>
              <option>Productiva</option><option>Indirecta</option><option>Servicio</option></select></div>
          <div className="form-group"><label className="form-label">Urgencia</label>
            <select className="form-select" value={form.urgencia} onChange={e => setForm(f => ({ ...f, urgencia: e.target.value }))}>
              {URGENCIAS.map(u => <option key={u} value={u}>{u}</option>)}</select></div>
          {form.tipo === 'Productiva' && (
            <div className="form-group col-span-2"><label className="form-label">Material</label>
              <select className="form-select" value={form.material_id} onChange={e => {
                const m = mats.find((x: any) => String(x.id) === e.target.value)
                setForm(f => ({ ...f, material_id: e.target.value, descripcion: m?.descripcion || f.descripcion, unidad: m?.unidad || f.unidad }))
              }}>
                <option value="">— Seleccionar material —</option>
                {mats.map((m: any) => <option key={m.id} value={m.id}>{m.codigo} — {m.descripcion}</option>)}
              </select></div>
          )}
          <div className="form-group col-span-2"><label className="form-label">Descripción *</label>
            <input className="form-input" value={form.descripcion} onChange={e => setForm(f => ({ ...f, descripcion: e.target.value }))} /></div>
          <div className="form-group"><label className="form-label">Cantidad *</label>
            <input className="form-input" type="number" min="0.01" step="0.01" value={form.cantidad} onChange={e => setForm(f => ({ ...f, cantidad: e.target.value }))} /></div>
          <div className="form-group"><label className="form-label">Unidad</label>
            <input className="form-input" value={form.unidad} onChange={e => setForm(f => ({ ...f, unidad: e.target.value }))} /></div>
        </div>
      </Modal>

      {/* Nueva cotización */}
      <Modal open={!!showCotModal} onClose={() => setShowCotModal(null)} title={`Cotización para: ${showCotModal?.numero}`}
        footer={<><button className="btn" onClick={() => setShowCotModal(null)}>Cancelar</button><button className="btn btn-primary" onClick={saveCot}>Guardar cotización</button></>}
      >
        <div className="form-grid">
          <div className="form-group col-span-2"><label className="form-label">Proveedor *</label>
            <select className="form-select" value={cotForm.proveedor_id} onChange={e => setCotForm(f => ({ ...f, proveedor_id: e.target.value }))}>
              <option value="">— Seleccionar proveedor —</option>
              {provs.map((p: any) => <option key={p.id} value={p.id}>{p.razon}</option>)}
            </select></div>
          <div className="form-group"><label className="form-label">Precio unitario *</label>
            <input className="form-input" type="number" min="0" step="0.01" value={cotForm.precio_unit} onChange={e => setCotForm(f => ({ ...f, precio_unit: e.target.value }))} /></div>
          <div className="form-group"><label className="form-label">Plazo (días)</label>
            <input className="form-input" type="number" min="0" value={cotForm.plazo_entrega_dias} onChange={e => setCotForm(f => ({ ...f, plazo_entrega_dias: e.target.value }))} /></div>
          <div className="form-group col-span-2"><label className="form-label">Condición de pago</label>
            <input className="form-input" value={cotForm.condicion_pago} onChange={e => setCotForm(f => ({ ...f, condicion_pago: e.target.value }))} placeholder="Contado, 30 días..." /></div>
        </div>
      </Modal>
    </div>
  )
}
