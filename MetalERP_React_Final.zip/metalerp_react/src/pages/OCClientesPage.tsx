import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Badge, PageLoading, EmptyState, fmtDate, fmtMoney } from '../components/ui'

interface OCItem {
  id: number; producto_codigo: string; producto_nombre: string
  cantidad: number; precio_unit: number; fecha_deseada: string | null
  unidad: string; ot_id: number | null
}

interface OC {
  id: number; numero: string; cliente_nombre: string; cliente_id: number
  fecha: string | null; fecha_entrega: string | null; estado: string; obs: string | null
  items: OCItem[]
}

const ESTADOS = ['Recibida','Confirmada','En proceso','Completada','Cancelada']

export default function OCClientesPage() {
  const toast = useToast()
  const [rows, setRows] = useState<OC[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [estFilter, setEstFilter] = useState('')
  const [expanded, setExpanded] = useState<Set<number>>(new Set())

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<OC[]>(`/ordenes_cliente${estFilter?`?estado=${estFilter}`:''}`))}
    catch { toast('Error cargando pedidos','error') }
    finally { setLoading(false) }
  }, [estFilter])

  useEffect(() => { load() }, [load])

  const toggle = (id: number) => setExpanded(prev => {
    const next = new Set(prev)
    next.has(id) ? next.delete(id) : next.add(id)
    return next
  })

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    return !q || r.numero.toLowerCase().includes(q) || r.cliente_nombre.toLowerCase().includes(q)
  })

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Pedidos de clientes</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar OC, cliente..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <select className="form-select" style={{ width:160 }} value={estFilter} onChange={e=>setEstFilter(e.target.value)}>
          <option value="">Todos los estados</option>
          {ESTADOS.map(e=><option key={e} value={e}>{e}</option>)}
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={() => toast('Usá la versión anterior para crear OCs','info')}><Plus size={14}/> Nueva OC</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin pedidos" desc="No hay órdenes de clientes registradas"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th style={{width:36}}></th>
              <th>N° OC</th><th>Cliente</th><th>Artículos</th>
              <th>Fecha</th><th>F. entrega</th><th>Estado</th><th>Avance</th>
            </tr></thead>
            <tbody>
              {filtered.map(r => {
                const isExp = expanded.has(r.id)
                const totalItems = r.items.length
                const conOT = r.items.filter(i => i.ot_id).length
                const avPct = totalItems > 0 ? Math.round(conOT/totalItems*100) : 0
                const avColor = avPct===100?'var(--c-green)':avPct>0?'var(--c-amber)':'var(--c-red)'
                return (
                  <>
                    <tr key={r.id} style={{ cursor:'pointer' }} onClick={() => toggle(r.id)}>
                      <td style={{ textAlign:'center' }}>
                        {isExp ? <ChevronDown size={13}/> : <ChevronRight size={13}/>}
                      </td>
                      <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.numero}</b></td>
                      <td style={{fontSize:13}}>{r.cliente_nombre}</td>
                      <td style={{fontSize:11,color:'var(--c-text-3)',maxWidth:180,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                        {r.items.map(i=>`${i.producto_codigo} ×${i.cantidad}`).join(' · ')}
                      </td>
                      <td style={{fontSize:12}}>{fmtDate(r.fecha)}</td>
                      <td style={{fontSize:12}}>{fmtDate(r.fecha_entrega)}</td>
                      <td><Badge value={r.estado}/></td>
                      <td>
                        <div style={{display:'flex',alignItems:'center',gap:6,minWidth:80}}>
                          <div className="progress-bar" style={{flex:1,height:6}}>
                            <div className="progress-fill" style={{width:`${avPct}%`,background:avColor}}/>
                          </div>
                          <span style={{fontSize:11,fontWeight:600,color:avColor}}>{avPct}%</span>
                        </div>
                      </td>
                    </tr>
                    {isExp && (
                      <tr key={`${r.id}-det`}>
                        <td colSpan={8} style={{padding:0}}>
                          <div style={{padding:'8px 12px 12px 48px',background:'var(--c-bg)',borderBottom:'1px solid var(--c-border)'}}>
                            <table style={{fontSize:11}}>
                              <thead><tr>
                                <th>Código</th><th>Producto</th><th>Cantidad</th>
                                <th>Precio unit.</th><th>F. deseada</th><th>OT</th><th>Estado</th>
                              </tr></thead>
                              <tbody>{r.items.map(i => (
                                <tr key={i.id}>
                                  <td><b>{i.producto_codigo}</b></td>
                                  <td>{i.producto_nombre}</td>
                                  <td>{i.cantidad} {i.unidad||'unid'}</td>
                                  <td>{fmtMoney(i.precio_unit)}</td>
                                  <td>{fmtDate(i.fecha_deseada)}</td>
                                  <td style={{color:i.ot_id?'var(--c-blue)':'var(--c-text-3)'}}>
                                    {i.ot_id ? `OT vinculada` : '—'}
                                  </td>
                                  <td>
                                    <Badge value={i.ot_id?'Explotada':'Pendiente'} variant={i.ot_id?'green':'amber'}/>
                                  </td>
                                </tr>
                              ))}</tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                )
              })}
            </tbody>
          </table></div>
        )}
      </div>
    </div>
  )
}
