import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, Search } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtDate, fmtMoney } from '../components/ui'

interface OT {
  id: number; numero: string; descripcion: string
  producto_id: number | null; producto_nombre: string | null; producto_codigo: string | null
  cliente_id: number | null; cliente_nombre: string | null
  cantidad: number; estado: string; prioridad: number
  fecha_inicio: string | null; fecha_entrega: string | null
  costo_mat: number; costo_mo: number
}

interface Producto { id: number; codigo: string; nombre: string }
interface Cliente  { id: number; razon: string }

const ESTADOS = ['Pendiente','En proceso','Completada','Cancelada']
const PRIORIDADES = [1,2,3,4,5]

export default function OrdenesPage() {
  const toast = useToast()
  const [rows, setRows]     = useState<OT[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [estFilter, setEstFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<OT | null>(null)
  const [prods, setProds]   = useState<Producto[]>([])
  const [clientes, setClientes] = useState<Cliente[]>([])

  const [form, setForm] = useState({
    descripcion: '', producto_id: '', cliente_id: '', cantidad: '1',
    prioridad: '3', estado: 'Pendiente', fecha_inicio: '', fecha_entrega: '', obs: ''
  })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await api.get<OT[]>('/ordenes' + (estFilter ? `?estado=${estFilter}` : ''))
      setRows(data)
    } catch { toast('Error cargando OTs', 'error') }
    finally { setLoading(false) }
  }, [estFilter])

  useEffect(() => { load() }, [load])

  const openNew = async () => {
    setEditing(null)
    setForm({ descripcion:'', producto_id:'', cliente_id:'', cantidad:'1', prioridad:'3', estado:'Pendiente', fecha_inicio:'', fecha_entrega:'', obs:'' })
    if (!prods.length) {
      const [p,c] = await Promise.all([api.get<Producto[]>('/productos'), api.get<Cliente[]>('/clientes')])
      setProds(p); setClientes(c)
    }
    setShowModal(true)
  }

  const openEdit = async (ot: OT) => {
    setEditing(ot)
    setForm({
      descripcion: ot.descripcion, producto_id: String(ot.producto_id ?? ''),
      cliente_id: String(ot.cliente_id ?? ''), cantidad: String(ot.cantidad),
      prioridad: String(ot.prioridad), estado: ot.estado,
      fecha_inicio: ot.fecha_inicio?.slice(0,10) ?? '',
      fecha_entrega: ot.fecha_entrega?.slice(0,10) ?? '', obs: ''
    })
    if (!prods.length) {
      const [p,c] = await Promise.all([api.get<Producto[]>('/productos'), api.get<Cliente[]>('/clientes')])
      setProds(p); setClientes(c)
    }
    setShowModal(true)
  }

  const save = async () => {
    const body = {
      descripcion: form.descripcion, producto_id: form.producto_id || null,
      cliente_id: form.cliente_id || null, cantidad: Number(form.cantidad),
      prioridad: Number(form.prioridad), estado: form.estado,
      fecha_inicio: form.fecha_inicio || null, fecha_entrega: form.fecha_entrega || null,
    }
    try {
      if (editing) {
        await api.put(`/ordenes/${editing.id}`, body)
        toast('OT actualizada')
      } else {
        await api.post('/ordenes', body)
        toast('OT creada')
      }
      setShowModal(false); load()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    return !q || r.numero.toLowerCase().includes(q) ||
      (r.descripcion||'').toLowerCase().includes(q) ||
      (r.producto_nombre||'').toLowerCase().includes(q)
  })

  const prioColor = (p: number) =>
    p >= 4 ? 'var(--c-red)' : p === 3 ? 'var(--c-amber)' : 'var(--c-text-3)'

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      {/* Toolbar */}
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Órdenes de trabajo</h2>
        <div style={{ position:'relative' }}>
          <Search size={14} style={{ position:'absolute', left:9, top:'50%', transform:'translateY(-50%)', color:'var(--c-text-3)', pointerEvents:'none' }}/>
          <input className="form-input" style={{ paddingLeft:30, width:220 }} placeholder="Buscar OT..." value={search} onChange={e=>setSearch(e.target.value)}/>
        </div>
        <select className="form-select" style={{ width:160 }} value={estFilter} onChange={e=>setEstFilter(e.target.value)}>
          <option value="">Todos los estados</option>
          {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nueva OT</button>
      </div>

      {/* Table */}
      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin órdenes" desc="Creá la primera OT con el botón Nueva OT"/>
        ) : (
          <div className="table-wrap">
            <table>
              <thead><tr>
                <th>N° OT</th><th>Descripción</th><th>Producto</th><th>Cliente</th>
                <th>Cant.</th><th>Prioridad</th><th>Estado</th>
                <th>F. inicio</th><th>F. entrega</th><th>Costo</th><th></th>
              </tr></thead>
              <tbody>
                {filtered.map(r => (
                  <tr key={r.id}>
                    <td><span style={{ fontWeight:700, fontFamily:'monospace', fontSize:12 }}>{r.numero}</span></td>
                    <td style={{ maxWidth:180, overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap', fontSize:13 }}>{r.descripcion}</td>
                    <td style={{ fontSize:12 }}>{r.producto_codigo ? <><b>{r.producto_codigo}</b> {r.producto_nombre}</> : '—'}</td>
                    <td style={{ fontSize:12 }}>{r.cliente_nombre || '—'}</td>
                    <td style={{ textAlign:'center' }}>{r.cantidad}</td>
                    <td style={{ textAlign:'center' }}>
                      <span style={{ fontWeight:700, color:prioColor(r.prioridad), fontSize:16 }}>
                        {'★'.repeat(r.prioridad)}
                      </span>
                    </td>
                    <td><Badge value={r.estado}/></td>
                    <td style={{ fontSize:12 }}>{fmtDate(r.fecha_inicio)}</td>
                    <td style={{ fontSize:12 }}>{fmtDate(r.fecha_entrega)}</td>
                    <td style={{ fontSize:12 }}>{fmtMoney((r.costo_mat||0)+(r.costo_mo||0))}</td>
                    <td>
                      <button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Modal */}
      <Modal
        open={showModal} onClose={() => setShowModal(false)}
        title={editing ? `Editar OT ${editing.numero}` : 'Nueva orden de trabajo'}
        size="lg"
        footer={
          <>
            <button className="btn" onClick={() => setShowModal(false)}>Cancelar</button>
            <button className="btn btn-primary" onClick={save}>Guardar</button>
          </>
        }
      >
        <div className="form-grid">
          <div className="form-group col-span-2">
            <label className="form-label">Descripción *</label>
            <input className="form-input" value={form.descripcion} onChange={e => setForm(f=>({...f,descripcion:e.target.value}))} placeholder="Ej: Fabricación de brida DN150"/>
          </div>
          <div className="form-group">
            <label className="form-label">Producto</label>
            <select className="form-select" value={form.producto_id} onChange={e => setForm(f=>({...f,producto_id:e.target.value}))}>
              <option value="">— Sin producto —</option>
              {prods.map(p => <option key={p.id} value={p.id}>{p.codigo} — {p.nombre}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Cliente</label>
            <select className="form-select" value={form.cliente_id} onChange={e => setForm(f=>({...f,cliente_id:e.target.value}))}>
              <option value="">— Sin cliente —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Cantidad *</label>
            <input className="form-input" type="number" min="1" step="1" value={form.cantidad} onChange={e => setForm(f=>({...f,cantidad:e.target.value}))}/>
          </div>
          <div className="form-group">
            <label className="form-label">Estado</label>
            <select className="form-select" value={form.estado} onChange={e => setForm(f=>({...f,estado:e.target.value}))}>
              {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Prioridad (1=baja, 5=crítica)</label>
            <select className="form-select" value={form.prioridad} onChange={e => setForm(f=>({...f,prioridad:e.target.value}))}>
              {PRIORIDADES.map(n => <option key={n} value={n}>{'★'.repeat(n)} — {n}</option>)}
            </select>
          </div>
          <div className="form-group">
            <label className="form-label">Fecha inicio</label>
            <input className="form-input" type="date" value={form.fecha_inicio} onChange={e => setForm(f=>({...f,fecha_inicio:e.target.value}))}/>
          </div>
          <div className="form-group">
            <label className="form-label">Fecha entrega</label>
            <input className="form-input" type="date" value={form.fecha_entrega} onChange={e => setForm(f=>({...f,fecha_entrega:e.target.value}))}/>
          </div>
        </div>
      </Modal>
    </div>
  )
}
