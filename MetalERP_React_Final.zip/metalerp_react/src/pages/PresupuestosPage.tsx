import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtDate, fmtMoney } from '../components/ui'

interface Pres {
  id: number; numero: string; cliente_nombre: string
  fecha: string; estado: string; total: number; obs: string | null
}

interface Cliente { id: number; razon: string }

const ESTADOS = ['Borrador','Enviado','Aprobado','Rechazado','Facturado']

export default function PresupuestosPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Pres[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [estFilter, setEstFilter] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [form, setForm] = useState({ cliente_id:'', estado:'Borrador', total:'0', obs:'' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Pres[]>('/presupuestos')) }
    catch { toast('Error cargando presupuestos','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = async () => {
    if (!clientes.length) setClientes(await api.get<Cliente[]>('/clientes'))
    setForm({ cliente_id:'', estado:'Borrador', total:'0', obs:'' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.cliente_id) { toast('Cliente requerido','warn'); return }
    try {
      await api.post('/presupuestos', {
        cliente_id: Number(form.cliente_id),
        estado: form.estado, total: Number(form.total), obs: form.obs,
      })
      toast('Presupuesto creado')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    const matchQ = !q || r.numero.toLowerCase().includes(q) || r.cliente_nombre.toLowerCase().includes(q)
    const matchE = !estFilter || r.estado === estFilter
    return matchQ && matchE
  })

  const totalPipeline = filtered.filter(r => ['Borrador','Enviado','Aprobado'].includes(r.estado))
    .reduce((s,r) => s + (r.total || 0), 0)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Presupuestos</h2>
        {totalPipeline > 0 && (
          <div style={{ background:'var(--c-primary-lt)', color:'var(--c-primary)', padding:'5px 12px', borderRadius:8, fontSize:13, fontWeight:600 }}>
            Pipeline: {fmtMoney(totalPipeline)}
          </div>
        )}
        <input className="form-input" style={{ width:220 }} placeholder="Buscar..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <select className="form-select" style={{ width:140 }} value={estFilter} onChange={e=>setEstFilter(e.target.value)}>
          <option value="">Todos los estados</option>
          {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo presupuesto</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin presupuestos" desc="Creá el primer presupuesto"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>N°</th><th>Cliente</th><th>Fecha</th><th>Estado</th><th>Total</th><th>Observaciones</th>
            </tr></thead>
            <tbody>{filtered.map(r => (
              <tr key={r.id}>
                <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.numero}</b></td>
                <td style={{fontSize:13}}>{r.cliente_nombre}</td>
                <td style={{fontSize:12}}>{fmtDate(r.fecha)}</td>
                <td><Badge value={r.estado}/></td>
                <td style={{fontSize:13,fontWeight:600}}>{fmtMoney(r.total)}</td>
                <td style={{fontSize:12,color:'var(--c-text-3)',maxWidth:240,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{r.obs||'—'}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)} title="Nuevo presupuesto"
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group col-span-2"><label className="form-label">Cliente *</label>
            <select className="form-select" value={form.cliente_id} onChange={e=>setForm(f=>({...f,cliente_id:e.target.value}))}>
              <option value="">— Seleccionar —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select></div>
          <div className="form-group"><label className="form-label">Estado</label>
            <select className="form-select" value={form.estado} onChange={e=>setForm(f=>({...f,estado:e.target.value}))}>
              {ESTADOS.map(e=><option key={e} value={e}>{e}</option>)}</select></div>
          <div className="form-group"><label className="form-label">Total estimado</label>
            <input className="form-input" type="number" min="0" step="0.01" value={form.total} onChange={e=>setForm(f=>({...f,total:e.target.value}))}/></div>
          <div className="form-group col-span-2"><label className="form-label">Observaciones</label>
            <textarea className="form-textarea" value={form.obs} onChange={e=>setForm(f=>({...f,obs:e.target.value}))}/></div>
        </div>
      </Modal>
    </div>
  )
}
