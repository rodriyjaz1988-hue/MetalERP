import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtDate } from '../components/ui'

interface Lote {
  id: number; numero: string; material_id: number
  mat_codigo: string; mat_descripcion: string; mat_unidad: string
  cantidad_original: number; cantidad_disponible: number; cantidad_activa: number
  estado: string; proveedor_id: number | null; proveedor_nombre: string | null
  referencia_proveedor: string | null; certificado: string | null; fecha_ingreso: string
}

interface Material { id: number; codigo: string; descripcion: string; unidad: string }

const ESTADOS = ['Ingresado','Aprobado','Rechazado','Agotado']

export default function LotesPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Lote[]>([])
  const [loading, setLoading] = useState(true)
  const [estFilter, setEstFilter] = useState('')
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [mats, setMats] = useState<Material[]>([])
  const [form, setForm] = useState({ material_id:'', cantidad:'', referencia_proveedor:'', certificado:'', obs:'' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Lote[]>(`/lotes${estFilter?`?estado=${estFilter}`:''}`))}
    catch { toast('Error cargando lotes','error') }
    finally { setLoading(false) }
  }, [estFilter])

  useEffect(() => { load() }, [load])

  const openNew = async () => {
    if (!mats.length) setMats(await api.get<Material[]>('/materiales?categoria=Material'))
    setForm({ material_id:'', cantidad:'', referencia_proveedor:'', certificado:'', obs:'' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.material_id || !form.cantidad) { toast('Material y cantidad requeridos','warn'); return }
    try {
      await api.post('/lotes', { material_id:Number(form.material_id), cantidad:Number(form.cantidad), referencia_proveedor:form.referencia_proveedor||null, certificado:form.certificado||null })
      toast('Lote creado'); setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    return !q || r.numero.toLowerCase().includes(q) ||
      r.mat_codigo.toLowerCase().includes(q) || r.mat_descripcion.toLowerCase().includes(q)
  })

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Lotes</h2>
        <input className="form-input" style={{ width:200 }} placeholder="Buscar lote..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <select className="form-select" style={{ width:160 }} value={estFilter} onChange={e=>setEstFilter(e.target.value)}>
          <option value="">Todos los estados</option>
          {ESTADOS.map(e=><option key={e} value={e}>{e}</option>)}
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo lote</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin lotes" desc="Ingresá el primer lote de materia prima"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>N° Lote</th><th>Material</th><th>Original</th><th>Disponible</th>
              <th>Aprobado</th><th>Sin aprobar</th><th>Proveedor</th><th>Certificado</th><th>Ingreso</th><th>Estado</th>
            </tr></thead>
            <tbody>{filtered.map(r => {
              const sinAprobar = r.cantidad_disponible - r.cantidad_activa
              return (
                <tr key={r.id}>
                  <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.numero}</b></td>
                  <td style={{fontSize:12}}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                  <td style={{fontSize:12}}>{r.cantidad_original} {r.mat_unidad}</td>
                  <td style={{fontSize:12,fontWeight:600}}>{r.cantidad_disponible}</td>
                  <td style={{fontSize:12,color:'var(--c-green)',fontWeight:600}}>{r.cantidad_activa}</td>
                  <td style={{fontSize:12,color:sinAprobar>0?'var(--c-amber)':'var(--c-text-3)'}}>{sinAprobar.toFixed(2)}</td>
                  <td style={{fontSize:12}}>{r.proveedor_nombre||r.referencia_proveedor||'—'}</td>
                  <td style={{fontSize:12}}>{r.certificado||'—'}</td>
                  <td style={{fontSize:12}}>{fmtDate(r.fecha_ingreso)}</td>
                  <td><Badge value={r.estado}/></td>
                </tr>
              )
            })}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)} title="Nuevo ingreso de lote"
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group col-span-2"><label className="form-label">Material *</label>
            <select className="form-select" value={form.material_id} onChange={e=>setForm(f=>({...f,material_id:e.target.value}))}>
              <option value="">— Seleccionar —</option>
              {mats.map(m=><option key={m.id} value={m.id}>{m.codigo} — {m.descripcion}</option>)}
            </select></div>
          <div className="form-group"><label className="form-label">Cantidad *</label>
            <input className="form-input" type="number" min="0.01" step="0.01" value={form.cantidad} onChange={e=>setForm(f=>({...f,cantidad:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Referencia proveedor</label>
            <input className="form-input" value={form.referencia_proveedor} onChange={e=>setForm(f=>({...f,referencia_proveedor:e.target.value}))}/></div>
          <div className="form-group col-span-2"><label className="form-label">Certificado</label>
            <input className="form-input" value={form.certificado} onChange={e=>setForm(f=>({...f,certificado:e.target.value}))} placeholder="N° de certificado de calidad"/></div>
        </div>
      </Modal>
    </div>
  )
}
