import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, Trash2 } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, PageLoading } from '../components/ui'

interface Cat { id: number; nombre: string; descripcion?: string | null }

interface SectionProps {
  title: string
  endpoint: string
}

function CategoriaSection({ title, endpoint }: SectionProps) {
  const toast = useToast()
  const [rows, setRows] = useState<Cat[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Cat | null>(null)
  const [form, setForm] = useState({ nombre:'', descripcion:'' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Cat[]>(endpoint)) }
    catch { toast(`Error cargando ${title}`,'error') }
    finally { setLoading(false) }
  }, [endpoint])

  useEffect(() => { load() }, [load])

  const openNew = () => { setEditing(null); setForm({nombre:'',descripcion:''}); setShowModal(true) }
  const openEdit = (c: Cat) => { setEditing(c); setForm({nombre:c.nombre,descripcion:c.descripcion||''}); setShowModal(true) }
  const save = async () => {
    if (!form.nombre) { toast('Nombre requerido','warn'); return }
    try {
      editing ? await api.put(`${endpoint}/${editing.id}`, form) : await api.post(endpoint, form)
      toast('Guardado'); setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }
  const del = async (c: Cat) => {
    if (!window.confirm(`¿Eliminar "${c.nombre}"?`)) return
    try { await api.delete(`${endpoint}/${c.id}`); toast('Eliminado'); load() }
    catch (e:any) { toast(e.message,'error') }
  }

  return (
    <div className="card">
      <div className="card-header">
        <span className="card-title">{title}</span>
        <button className="btn btn-sm btn-primary" onClick={openNew}><Plus size={12}/> Nuevo</button>
      </div>
      {loading ? <PageLoading/> : rows.length === 0 ? (
        <p style={{ color:'var(--c-text-3)', fontSize:13 }}>Sin categorías. Creá la primera.</p>
      ) : (
        <table>
          <tbody>{rows.map(r => (
            <tr key={r.id}>
              <td style={{ fontSize:13, fontWeight:600 }}>{r.nombre}</td>
              <td style={{ fontSize:12, color:'var(--c-text-3)' }}>{r.descripcion||'—'}</td>
              <td style={{ textAlign:'right' }}>
                <div style={{ display:'flex', gap:4, justifyContent:'flex-end' }}>
                  <button className="btn btn-xs" onClick={()=>openEdit(r)}>Editar</button>
                  <button className="btn btn-xs btn-danger" onClick={()=>del(r)}><Trash2 size={10}/></button>
                </div>
              </td>
            </tr>
          ))}</tbody>
        </table>
      )}

      <Modal open={showModal} onClose={()=>setShowModal(false)} title={editing?`Editar: ${editing.nombre}`:'Nueva categoría'}
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group col-span-2"><label className="form-label">Nombre *</label>
            <input className="form-input" value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))} autoFocus/></div>
          <div className="form-group col-span-2"><label className="form-label">Descripción</label>
            <input className="form-input" value={form.descripcion} onChange={e=>setForm(f=>({...f,descripcion:e.target.value}))}/></div>
        </div>
      </Modal>
    </div>
  )
}

export default function ConfiguracionPage() {
  const toast = useToast()
  const refresh = () => toast('Configuración recargada')

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10 }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Configuración del sistema</h2>
        <button className="btn" onClick={refresh}><RefreshCw size={14}/></button>
      </div>

      <div className="grid-2">
        <CategoriaSection title="Categorías de productos" endpoint="/categorias_producto"/>
        <CategoriaSection title="Categorías de máquinas" endpoint="/categorias_maquina"/>
      </div>
    </div>
  )
}
