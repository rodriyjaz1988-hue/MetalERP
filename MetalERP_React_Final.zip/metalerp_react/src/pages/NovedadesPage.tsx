import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtDate } from '../components/ui'

interface Novedad {
  id: number; ot_id: number; ot_numero: string
  operacion_id: number | null; op_nombre: string | null
  empleado_id: number | null; empleado_nombre: string | null
  tipo: string; descripcion: string
  cantidad_producida: number; tiempo_real_min: number
  fecha: string
}

interface OT { id: number; numero: string; descripcion: string }
interface Empleado { id: number; nombre: string }

const TIPOS = ['Producción','Pausa','Parada','Defecto','Observación']

export default function NovedadesPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Novedad[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [ots, setOts] = useState<OT[]>([])
  const [emps, setEmps] = useState<Empleado[]>([])
  const [ops, setOps] = useState<any[]>([])
  const [form, setForm] = useState({ ot_id:'', operacion_id:'', empleado_id:'', tipo:'Producción', descripcion:'', cantidad_producida:'0', tiempo_real_min:'0' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Novedad[]>('/novedades')) }
    catch { toast('Error cargando novedades','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = async () => {
    if (!ots.length) {
      const [o, e] = await Promise.all([api.get<OT[]>('/ordenes?estado=En proceso'), api.get<Empleado[]>('/empleados')])
      setOts(o); setEmps(e)
    }
    setForm({ ot_id:'', operacion_id:'', empleado_id:'', tipo:'Producción', descripcion:'', cantidad_producida:'0', tiempo_real_min:'0' })
    setOps([])
    setShowModal(true)
  }

  const loadOps = async (otId: string) => {
    setForm(f => ({...f, ot_id:otId, operacion_id:''}))
    if (otId) setOps(await api.get<any[]>(`/ordenes/${otId}/operaciones`))
    else setOps([])
  }

  const save = async () => {
    if (!form.ot_id || !form.descripcion) { toast('OT y descripción requeridas','warn'); return }
    const body = {
      ot_id: Number(form.ot_id),
      operacion_id: form.operacion_id ? Number(form.operacion_id) : null,
      empleado_id: form.empleado_id ? Number(form.empleado_id) : null,
      tipo: form.tipo, descripcion: form.descripcion,
      cantidad_producida: Number(form.cantidad_producida),
      tiempo_real_min: Number(form.tiempo_real_min),
    }
    try { await api.post('/novedades', body); toast('Novedad registrada'); setShowModal(false); load() }
    catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => !search || r.ot_numero.toLowerCase().includes(search.toLowerCase()) || (r.descripcion||'').toLowerCase().includes(search.toLowerCase()))

  const tipoColor: Record<string,'green'|'amber'|'red'|'blue'|'gray'> = {
    Producción:'green', Pausa:'amber', Parada:'red', Defecto:'red', Observación:'blue'
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Novedades por OT</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar novedad..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nueva novedad</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin novedades" desc="Registrá la primera novedad de producción"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>Fecha</th><th>OT</th><th>Operación</th><th>Empleado</th>
              <th>Tipo</th><th>Descripción</th><th>Cant.</th><th>Tiempo</th>
            </tr></thead>
            <tbody>{filtered.map(r => (
              <tr key={r.id}>
                <td style={{fontSize:12}}>{fmtDate(r.fecha)}</td>
                <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.ot_numero}</b></td>
                <td style={{fontSize:12}}>{r.op_nombre||'—'}</td>
                <td style={{fontSize:12}}>{r.empleado_nombre||'—'}</td>
                <td><Badge value={r.tipo} variant={tipoColor[r.tipo]}/></td>
                <td style={{fontSize:12,maxWidth:240,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{r.descripcion}</td>
                <td style={{fontSize:12,textAlign:'right'}}>{r.cantidad_producida||'—'}</td>
                <td style={{fontSize:12,textAlign:'right'}}>{r.tiempo_real_min ? `${r.tiempo_real_min}min` : '—'}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)} title="Nueva novedad"
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group"><label className="form-label">OT *</label>
            <select className="form-select" value={form.ot_id} onChange={e=>loadOps(e.target.value)}>
              <option value="">— Seleccionar OT —</option>
              {ots.map(o => <option key={o.id} value={o.id}>{o.numero} — {o.descripcion}</option>)}
            </select></div>
          <div className="form-group"><label className="form-label">Operación</label>
            <select className="form-select" value={form.operacion_id} onChange={e=>setForm(f=>({...f,operacion_id:e.target.value}))}>
              <option value="">— Sin operación —</option>
              {ops.map((op:any) => <option key={op.id} value={op.id}>{op.orden}. {op.nombre}</option>)}
            </select></div>
          <div className="form-group"><label className="form-label">Empleado</label>
            <select className="form-select" value={form.empleado_id} onChange={e=>setForm(f=>({...f,empleado_id:e.target.value}))}>
              <option value="">— Sin empleado —</option>
              {emps.map(e => <option key={e.id} value={e.id}>{e.nombre}</option>)}
            </select></div>
          <div className="form-group"><label className="form-label">Tipo</label>
            <select className="form-select" value={form.tipo} onChange={e=>setForm(f=>({...f,tipo:e.target.value}))}>
              {TIPOS.map(t=><option key={t} value={t}>{t}</option>)}</select></div>
          <div className="form-group col-span-2"><label className="form-label">Descripción *</label>
            <textarea className="form-textarea" value={form.descripcion} onChange={e=>setForm(f=>({...f,descripcion:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Cantidad producida</label>
            <input className="form-input" type="number" min="0" step="0.01" value={form.cantidad_producida} onChange={e=>setForm(f=>({...f,cantidad_producida:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Tiempo real (min)</label>
            <input className="form-input" type="number" min="0" value={form.tiempo_real_min} onChange={e=>setForm(f=>({...f,tiempo_real_min:e.target.value}))}/></div>
        </div>
      </Modal>
    </div>
  )
}
