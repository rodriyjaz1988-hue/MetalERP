import { useEffect, useState, useCallback } from 'react'
import { RefreshCw, ChevronRight } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Badge, PageLoading, EmptyState, fmtDate } from '../components/ui'

interface OT {
  id: number; numero: string; descripcion: string
  producto_codigo: string | null; producto_nombre: string | null
  cliente_nombre: string | null; cantidad: number
  estado: string; prioridad: number; fecha_entrega: string | null
  costo_mat: number; costo_mo: number
}

interface OpOT {
  id: number; orden: number; nombre: string
  estado: string; tiempo_setup_min: number; tiempo_ciclo_min: number
  empleado_nombre: string | null; maquina_nombre: string | null
  fecha_inicio: string | null; fecha_fin: string | null
}

interface MatOT {
  id: number; codigo: string; descripcion: string
  cantidad_requerida: number; cantidad_asignada: number; unidad: string
}

const ESTADOS_OP = ['Pendiente','En proceso','Pausada','Completada']

export default function CtrlProdPage() {
  const toast = useToast()
  const [ots, setOts] = useState<OT[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [estFilter, setEstFilter] = useState('En proceso')
  const [selected, setSelected] = useState<OT | null>(null)
  const [ops, setOps] = useState<OpOT[]>([])
  const [mats, setMats] = useState<MatOT[]>([])
  const [loadingDet, setLoadingDet] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try { setOts(await api.get<OT[]>(`/ordenes${estFilter?`?estado=${estFilter}`:''}`)) }
    catch { toast('Error cargando OTs','error') }
    finally { setLoading(false) }
  }, [estFilter])

  useEffect(() => { load() }, [load])

  const selectOT = async (ot: OT) => {
    setSelected(ot); setLoadingDet(true)
    try {
      const [opsData, matsData] = await Promise.all([
        api.get<OpOT[]>(`/ordenes/${ot.id}/operaciones`),
        api.get<MatOT[]>(`/ordenes/${ot.id}/materiales`),
      ])
      setOps(opsData); setMats(matsData)
    } catch { toast('Error cargando detalle','error') }
    finally { setLoadingDet(false) }
  }

  const cambiarEstadoOp = async (op: OpOT, nuevo: string) => {
    if (!selected) return
    try {
      await api.put(`/ordenes/${selected.id}/operaciones/${op.id}`, { estado: nuevo })
      toast(`Operación ${nuevo.toLowerCase()}`)
      selectOT(selected)
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = ots.filter(o => {
    const q = search.toLowerCase()
    return !q || o.numero.toLowerCase().includes(q) ||
      (o.descripcion||'').toLowerCase().includes(q) ||
      (o.producto_nombre||'').toLowerCase().includes(q)
  })

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Control de producción</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar OT..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <select className="form-select" style={{ width:160 }} value={estFilter} onChange={e=>setEstFilter(e.target.value)}>
          <option value="">Todos los estados</option>
          <option value="Pendiente">Pendiente</option>
          <option value="En proceso">En proceso</option>
          <option value="Completada">Completada</option>
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
      </div>

      <div style={{ display:'grid', gridTemplateColumns: selected ? '380px 1fr' : '1fr', gap:16, minHeight:400 }}>
        {/* OT list */}
        <div className="card" style={{ padding:0, maxHeight:600, overflowY:'auto' }}>
          {loading ? <PageLoading/> : filtered.length === 0 ? (
            <EmptyState title="Sin OTs" desc="No hay órdenes con este filtro"/>
          ) : (
            <div>
              {filtered.map(o => (
                <div key={o.id}
                  className={selected?.id === o.id ? '' : ''}
                  onClick={() => selectOT(o)}
                  style={{
                    padding:'12px 14px', borderBottom:'1px solid var(--c-border)',
                    cursor:'pointer',
                    background: selected?.id === o.id ? 'var(--c-primary)' : undefined,
                    color: selected?.id === o.id ? '#fff' : undefined,
                  }}
                >
                  <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:4 }}>
                    <b style={{ fontSize:13, fontFamily:'monospace' }}>{o.numero}</b>
                    <ChevronRight size={14} style={{ opacity: selected?.id === o.id ? 1 : .3 }}/>
                  </div>
                  <div style={{ fontSize:12, marginBottom:4 }}>{o.producto_nombre || o.descripcion}</div>
                  <div style={{ display:'flex', gap:6, alignItems:'center', fontSize:11, opacity: selected?.id === o.id ? .9 : .7 }}>
                    <span>{o.cantidad} unid · {o.cliente_nombre || 'sin cliente'}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Selected OT detail */}
        {selected && (
          <div className="card">
            {loadingDet ? <PageLoading/> : (
              <>
                {/* Header */}
                <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:14, paddingBottom:12, borderBottom:'1px solid var(--c-border)' }}>
                  <div>
                    <div style={{ fontSize:16, fontWeight:700 }}>{selected.numero}</div>
                    <div style={{ fontSize:13, color:'var(--c-text-2)' }}>{selected.producto_codigo} — {selected.producto_nombre}</div>
                  </div>
                  <Badge value={selected.estado}/>
                </div>

                <div className="grid-3" style={{ marginBottom:16, gap:12 }}>
                  {[
                    ['Cliente', selected.cliente_nombre || '—'],
                    ['Cantidad', `${selected.cantidad} unid`],
                    ['Entrega', fmtDate(selected.fecha_entrega)],
                  ].map(([l,v]) => (
                    <div key={l} style={{ background:'var(--c-bg)', padding:'8px 12px', borderRadius:8 }}>
                      <div style={{ fontSize:11, color:'var(--c-text-3)' }}>{l}</div>
                      <div style={{ fontSize:13, fontWeight:600 }}>{v}</div>
                    </div>
                  ))}
                </div>

                {/* Operations */}
                <div>
                  <div style={{ fontSize:12, fontWeight:600, color:'var(--c-text-3)', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:8 }}>Operaciones</div>
                  {ops.length === 0 ? <EmptyState title="Sin operaciones"/> : (
                    <table>
                      <thead><tr><th>#</th><th>Operación</th><th>Recurso</th><th>Estado</th><th></th></tr></thead>
                      <tbody>{ops.map(op => (
                        <tr key={op.id}>
                          <td style={{textAlign:'center',fontSize:12}}>{op.orden}</td>
                          <td style={{fontSize:13}}><b>{op.nombre}</b>
                            <div style={{fontSize:10,color:'var(--c-text-3)'}}>
                              Setup: {op.tiempo_setup_min}min · Ciclo: {Math.round(op.tiempo_ciclo_min*60)}seg
                            </div>
                          </td>
                          <td style={{fontSize:11}}>
                            {op.maquina_nombre && <div>🔧 {op.maquina_nombre}</div>}
                            {op.empleado_nombre && <div>👤 {op.empleado_nombre}</div>}
                            {!op.maquina_nombre && !op.empleado_nombre && '—'}
                          </td>
                          <td><Badge value={op.estado}/></td>
                          <td>
                            <select className="form-select" style={{ fontSize:11, padding:'3px 6px', width:130 }}
                              value={op.estado}
                              onChange={e => cambiarEstadoOp(op, e.target.value)}>
                              {ESTADOS_OP.map(s => <option key={s} value={s}>{s}</option>)}
                            </select>
                          </td>
                        </tr>
                      ))}</tbody>
                    </table>
                  )}
                </div>

                {/* Materials */}
                {mats.length > 0 && (
                  <div style={{ marginTop:16 }}>
                    <div style={{ fontSize:12, fontWeight:600, color:'var(--c-text-3)', textTransform:'uppercase', letterSpacing:'.4px', marginBottom:8 }}>Materiales</div>
                    <table>
                      <thead><tr><th>Material</th><th>Requerido</th><th>Asignado</th><th>Cobertura</th></tr></thead>
                      <tbody>{mats.map(m => {
                        const cov = m.cantidad_requerida > 0 ? Math.round(m.cantidad_asignada/m.cantidad_requerida*100) : 0
                        return (
                          <tr key={m.id}>
                            <td style={{fontSize:12}}><b>{m.codigo}</b> {m.descripcion}</td>
                            <td style={{fontSize:12}}>{m.cantidad_requerida} {m.unidad}</td>
                            <td style={{fontSize:12}}>{m.cantidad_asignada}</td>
                            <td>
                              <div style={{display:'flex',alignItems:'center',gap:6,minWidth:100}}>
                                <div className="progress-bar" style={{flex:1,height:6}}>
                                  <div className="progress-fill" style={{width:`${Math.min(cov,100)}%`,background: cov>=100?'var(--c-green)':'var(--c-amber)'}}/>
                                </div>
                                <span style={{fontSize:11,fontWeight:600}}>{cov}%</span>
                              </div>
                            </td>
                          </tr>
                        )
                      })}</tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  )
}
