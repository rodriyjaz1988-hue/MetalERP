import { useEffect, useState, useCallback } from 'react'
import { RefreshCw, Eye, Truck, PackageCheck } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtDate, fmtMoney } from '../components/ui'

interface OTT {
  id: number; numero: string; ot_numero: string | null
  op_nombre: string | null; op_orden: number | null
  producto_codigo: string | null; producto_nombre: string | null
  proveedor_nombre: string | null; precio_acordado: number
  es_ultimo_nivel: number; estado: string
  remito_numero: string | null; fecha_envio: string | null
  fecha_retorno_est: string | null; fecha_retorno_real: string | null; obs: string | null
}

const ESTADO_COLORS: Record<string, 'amber' | 'blue' | 'teal' | 'green' | 'gray' | 'red'> = {
  Pendiente: 'amber', 'Remito emitido': 'blue', 'En proceso': 'blue',
  Recibido: 'teal', Completado: 'green', Cancelado: 'gray'
}

export default function OTTPage() {
  const toast = useToast()
  const [rows, setRows] = useState<OTT[]>([])
  const [loading, setLoading] = useState(true)
  const [estFilter, setEstFilter] = useState('')
  const [detalle, setDetalle] = useState<OTT | null>(null)
  const [showRetorno, setShowRetorno] = useState<OTT | null>(null)
  const [retQty, setRetQty] = useState('')
  const [retObs, setRetObs] = useState('')
  const [saving, setSaving] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<OTT[]>('/ott' + (estFilter ? `?estado=${estFilter}` : ''))) }
    catch { toast('Error cargando OTTs', 'error') }
    finally { setLoading(false) }
  }, [estFilter])

  useEffect(() => { load() }, [load])

  const emitirRemito = async (id: number) => {
    if (!window.confirm('¿Emitir remito de traslado para esta OTT?')) return
    try {
      const r = await api.post<any>(`/ott/${id}/emitir_remito`, {})
      toast(`Remito ${r.remito_numero} emitido`); load()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const confirmarRetorno = async () => {
    if (!showRetorno) return
    const qty = parseFloat(retQty)
    if (!qty || qty <= 0) { toast('Ingresá la cantidad recibida', 'warn'); return }
    setSaving(true)
    try {
      const r = await api.post<any>(`/ott/${showRetorno.id}/registrar_retorno`, { cantidad: qty, obs: retObs })
      toast(`${r.mensaje} — Lote ${r.lote_numero}`)
      setShowRetorno(null); load()
    } catch (e: any) { toast(e.message, 'error') }
    finally { setSaving(false) }
  }

  const completar = async (id: number) => {
    try { await api.post(`/ott/${id}/completar`, {}); toast('OTT completada'); load() }
    catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, flex: 1 }}>OTT — Órdenes de Trabajo de Terceros</h2>
        <select className="form-select" style={{ width: 180 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
          <option value="">Todos los estados</option>
          {Object.keys(ESTADO_COLORS).map(e => <option key={e} value={e}>{e}</option>)}
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14} /></button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {loading ? <PageLoading /> : rows.length === 0 ? (
          <EmptyState title="Sin OTTs" desc="Las OTTs se generan automáticamente desde el MRP cuando una operación está marcada como tercerizada" />
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>N°</th><th>OT origen</th><th>Operación</th><th>Producto</th>
              <th>Proveedor</th><th>Precio</th><th>Nivel</th>
              <th>F. envío</th><th>F. retorno est.</th><th>Estado</th><th></th>
            </tr></thead>
            <tbody>{rows.map(r => (
              <tr key={r.id}>
                <td><b style={{ fontFamily: 'monospace', fontSize: 12 }}>{r.numero}</b></td>
                <td style={{ fontSize: 12 }}>{r.ot_numero || '—'}</td>
                <td style={{ fontSize: 12 }}>{r.op_nombre || '—'}</td>
                <td style={{ fontSize: 11 }}>{r.producto_codigo || '—'}</td>
                <td style={{ fontSize: 12 }}>{r.proveedor_nombre || <span style={{ color: 'var(--c-red)', fontSize: 11 }}>Sin asignar</span>}</td>
                <td style={{ fontSize: 12 }}>{fmtMoney(r.precio_acordado)}</td>
                <td>
                  {r.es_ultimo_nivel
                    ? <Badge value="PT → cliente" variant="green" />
                    : <Badge value="Semielaborado" variant="amber" />}
                </td>
                <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_envio)}</td>
                <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_retorno_est)}</td>
                <td><Badge value={r.estado} variant={ESTADO_COLORS[r.estado]} /></td>
                <td>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button className="btn btn-xs" onClick={() => setDetalle(r)} title="Ver detalle"><Eye size={11} /></button>
                    {r.estado === 'Pendiente' && (
                      <button className="btn btn-xs btn-primary" onClick={() => emitirRemito(r.id)} title="Emitir remito de traslado">
                        <Truck size={11} />
                      </button>
                    )}
                    {(r.estado === 'Remito emitido' || r.estado === 'En proceso') && (
                      <button className="btn btn-xs btn-primary" onClick={() => { setShowRetorno(r); setRetQty(''); setRetObs('') }} title="Registrar retorno">
                        <PackageCheck size={11} />
                      </button>
                    )}
                    {r.estado === 'Recibido' && (
                      <button className="btn btn-xs" onClick={() => completar(r.id)}>Completar</button>
                    )}
                  </div>
                </td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      {/* Detalle modal */}
      <Modal open={!!detalle} onClose={() => setDetalle(null)} title={detalle?.numero || 'Detalle OTT'}
        footer={<button className="btn" onClick={() => setDetalle(null)}>Cerrar</button>}
      >
        {detalle && (
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12, fontSize: 13 }}>
            {[
              ['OT origen', detalle.ot_numero || '—'],
              ['Operación', `${detalle.op_orden || ''}. ${detalle.op_nombre || '—'}`],
              ['Producto', `${detalle.producto_codigo || '—'} — ${detalle.producto_nombre || '—'}`],
              ['Proveedor', detalle.proveedor_nombre || 'Sin asignar'],
              ['Precio acordado', fmtMoney(detalle.precio_acordado)],
              ['Nivel', detalle.es_ultimo_nivel ? 'Último (PT → cliente)' : 'Intermedio (semielaborado → OT)'],
              ['Estado', detalle.estado],
              ['Remito traslado', detalle.remito_numero || '—'],
              ['Fecha envío', fmtDate(detalle.fecha_envio)],
              ['Retorno estimado', fmtDate(detalle.fecha_retorno_est)],
              ['Retorno real', fmtDate(detalle.fecha_retorno_real)],
            ].map(([l, v]) => (
              <div key={l} style={{ background: 'var(--c-bg)', borderRadius: 8, padding: '8px 12px' }}>
                <div style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{l}</div>
                <div style={{ fontWeight: 600 }}>{v}</div>
              </div>
            ))}
            {detalle.obs && (
              <div style={{ gridColumn: 'span 2', background: 'var(--c-bg)', borderRadius: 8, padding: '8px 12px' }}>
                <div style={{ fontSize: 11, color: 'var(--c-text-3)' }}>Observaciones</div>
                <div>{detalle.obs}</div>
              </div>
            )}
          </div>
        )}
      </Modal>

      {/* Retorno modal */}
      <Modal open={!!showRetorno} onClose={() => setShowRetorno(null)} title="Registrar retorno de piezas"
        footer={
          <>
            <button className="btn" onClick={() => setShowRetorno(null)}>Cancelar</button>
            <button className="btn btn-primary" onClick={confirmarRetorno} disabled={saving}>
              {saving ? 'Guardando...' : 'Confirmar retorno'}
            </button>
          </>
        }
      >
        {showRetorno && (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            <div style={{ padding: 12, borderRadius: 8, background: showRetorno.es_ultimo_nivel ? 'var(--c-green-bg)' : 'var(--c-amber-bg)', fontSize: 13 }}>
              {showRetorno.es_ultimo_nivel
                ? '✓ Último nivel: el lote quedará disponible para Remitir a cliente.'
                : '→ Paso intermedio: el lote quedará como semielaborado asignable a una OT.'}
            </div>
            <div className="form-group">
              <label className="form-label">Cantidad recibida *</label>
              <input className="form-input" type="number" min="0.01" step="0.01" value={retQty} onChange={e => setRetQty(e.target.value)} autoFocus />
            </div>
            <div className="form-group">
              <label className="form-label">Observaciones</label>
              <textarea className="form-textarea" value={retObs} onChange={e => setRetObs(e.target.value)} placeholder="Estado de las piezas, certificados, etc." />
            </div>
          </div>
        )}
      </Modal>
    </div>
  )
}
