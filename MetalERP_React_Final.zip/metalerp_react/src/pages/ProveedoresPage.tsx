import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, ChevronDown, ChevronRight } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState, fmtMoney } from '../components/ui'

interface MatVinc { id: number; codigo: string; descripcion: string; precio_unit: number; plazo_dias: number; es_principal: number }
interface OTTActiva { id: number; numero: string; producto_codigo: string | null; estado: string; precio_acordado: number }
interface Prov {
  id: number; razon: string; cuit: string | null; contacto: string | null
  telefono: string | null; email: string | null; plazo_dias: number
  calificacion: number; estado: string; rubro: string | null
  mat_vinculados: MatVinc[]
}

export default function ProveedoresPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Prov[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [matsByProv, setMatsByProv] = useState<Record<number, MatVinc[]>>({})
  const [ottsByProv, setOttsByProv] = useState<Record<number, OTTActiva[]>>({})
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Prov | null>(null)
  const [form, setForm] = useState({ razon:'', cuit:'', contacto:'', telefono:'', email:'', plazo_dias:'30', calificacion:'4', estado:'Activo', rubro:'' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Prov[]>('/proveedores')) }
    catch { toast('Error cargando proveedores','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const toggle = async (id: number) => {
    const next = new Set(expanded)
    if (next.has(id)) { next.delete(id); setExpanded(next); return }
    next.add(id); setExpanded(next)
    if (!matsByProv[id]) {
      const [mats, otts] = await Promise.all([
        api.get<MatVinc[]>(`/proveedores/${id}/materiales`),
        api.get<OTTActiva[]>(`/ott?proveedor_id=${id}`)
      ])
      setMatsByProv(p => ({...p, [id]: mats}))
      setOttsByProv(p => ({...p, [id]: otts.filter((o:any) => !['Completado','Cancelado'].includes(o.estado))}))
    }
  }

  const openNew = () => {
    setEditing(null)
    setForm({ razon:'', cuit:'', contacto:'', telefono:'', email:'', plazo_dias:'30', calificacion:'4', estado:'Activo', rubro:'' })
    setShowModal(true)
  }

  const openEdit = (p: Prov) => {
    setEditing(p)
    setForm({ razon:p.razon, cuit:p.cuit||'', contacto:p.contacto||'', telefono:p.telefono||'', email:p.email||'', plazo_dias:String(p.plazo_dias), calificacion:String(p.calificacion), estado:p.estado, rubro:p.rubro||'' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.razon) { toast('Razón social requerida','warn'); return }
    const body = { ...form, plazo_dias:Number(form.plazo_dias), calificacion:Number(form.calificacion) }
    try {
      editing ? await api.put(`/proveedores/${editing.id}`, body) : await api.post('/proveedores', body)
      toast(editing?'Proveedor actualizado':'Proveedor registrado')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    return !q || r.razon.toLowerCase().includes(q) || (r.contacto||'').toLowerCase().includes(q)
  })

  const stars = (n: number) => '★'.repeat(n) + '☆'.repeat(5-n)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Proveedores</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar proveedor..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo proveedor</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin proveedores" desc="Registrá el primer proveedor"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th style={{width:36}}></th>
              <th>Razón social</th><th>Contacto</th><th>Teléfono</th>
              <th>Plazo</th><th>Calificación</th><th>Estado</th><th>Lista de precios</th><th></th>
            </tr></thead>
            <tbody>
              {filtered.map(r => {
                const isExp = expanded.has(r.id)
                const mats = matsByProv[r.id]
                const otts = ottsByProv[r.id]
                return (
                  <>
                    <tr key={r.id}>
                      <td><button style={{background:'none',border:'none',cursor:'pointer',color:'var(--c-text-3)'}} onClick={()=>toggle(r.id)}>
                        {isExp?<ChevronDown size={13}/>:<ChevronRight size={13}/>}
                      </button></td>
                      <td><b style={{fontSize:13}}>{r.razon}</b></td>
                      <td style={{fontSize:12}}>{r.contacto||'—'}</td>
                      <td style={{fontSize:12}}>{r.telefono||'—'}</td>
                      <td style={{fontSize:12}}>{r.plazo_dias}d</td>
                      <td style={{fontSize:13,color:'#EF9F27'}}>{stars(r.calificacion)}</td>
                      <td><Badge value={r.estado}/></td>
                      <td style={{fontSize:12,color:'var(--c-text-3)'}}>
                        {r.mat_vinculados?.length ? `${r.mat_vinculados.length} artículo${r.mat_vinculados.length!==1?'s':''}` : 'Sin artículos'}
                      </td>
                      <td><button className="btn btn-xs" onClick={()=>openEdit(r)}>Editar</button></td>
                    </tr>
                    {isExp && (
                      <tr key={`${r.id}-det`}>
                        <td colSpan={9} style={{padding:0}}>
                          <div style={{padding:'10px 12px 12px 48px',background:'var(--c-bg)',borderBottom:'1px solid var(--c-border)'}}>
                            {!mats ? <span style={{fontSize:12,color:'var(--c-text-3)'}}>Cargando...</span> : (
                              <>
                                {mats.length === 0
                                  ? <p style={{fontSize:12,color:'var(--c-text-3)'}}>Sin artículos en lista de precios.</p>
                                  : <><div style={{fontSize:11,fontWeight:600,color:'var(--c-text-3)',marginBottom:6}}>LISTA DE PRECIOS</div>
                                    <table style={{fontSize:11}}>
                                      <thead><tr><th>Código</th><th>Descripción</th><th>Precio unit.</th><th>Plazo</th><th>Principal</th></tr></thead>
                                      <tbody>{mats.map(m => (
                                        <tr key={m.id}>
                                          <td><b>{m.codigo}</b></td><td>{m.descripcion}</td>
                                          <td><b>{fmtMoney(m.precio_unit)}</b></td>
                                          <td>{m.plazo_dias||'—'}d</td>
                                          <td>{m.es_principal?<Badge value="✓ Principal" variant="green"/>:''}</td>
                                        </tr>
                                      ))}</tbody>
                                    </table></>
                                }
                                {otts && otts.length > 0 && (
                                  <><div style={{fontSize:11,fontWeight:600,color:'var(--c-text-3)',margin:'10px 0 6px'}}>OTTs ACTIVAS</div>
                                  <table style={{fontSize:11}}>
                                    <thead><tr><th>N°</th><th>Producto</th><th>Estado</th><th>Precio</th></tr></thead>
                                    <tbody>{otts.map(o => (
                                      <tr key={o.id}><td><b>{o.numero}</b></td><td>{o.producto_codigo||'—'}</td>
                                        <td><Badge value={o.estado}/></td><td>{fmtMoney(o.precio_acordado)}</td></tr>
                                    ))}</tbody>
                                  </table></>
                                )}
                              </>
                            )}
                          </div>
                        </td>
                      </tr>
                    )}
                  </>
                )
              })}
            </tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)}
        title={editing?`Editar: ${editing.razon}`:'Nuevo proveedor'}
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group col-span-2"><label className="form-label">Razón social *</label>
            <input className="form-input" value={form.razon} onChange={e=>setForm(f=>({...f,razon:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">CUIT</label>
            <input className="form-input" value={form.cuit} onChange={e=>setForm(f=>({...f,cuit:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Rubro</label>
            <input className="form-input" value={form.rubro} onChange={e=>setForm(f=>({...f,rubro:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Contacto</label>
            <input className="form-input" value={form.contacto} onChange={e=>setForm(f=>({...f,contacto:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Teléfono</label>
            <input className="form-input" value={form.telefono} onChange={e=>setForm(f=>({...f,telefono:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Email</label>
            <input className="form-input" type="email" value={form.email} onChange={e=>setForm(f=>({...f,email:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Plazo (días)</label>
            <input className="form-input" type="number" min="0" value={form.plazo_dias} onChange={e=>setForm(f=>({...f,plazo_dias:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Calificación (1-5)</label>
            <input className="form-input" type="number" min="1" max="5" value={form.calificacion} onChange={e=>setForm(f=>({...f,calificacion:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Estado</label>
            <select className="form-select" value={form.estado} onChange={e=>setForm(f=>({...f,estado:e.target.value}))}>
              <option>Activo</option><option>Inactivo</option><option>Suspendido</option></select></div>
        </div>
      </Modal>
    </div>
  )
}
