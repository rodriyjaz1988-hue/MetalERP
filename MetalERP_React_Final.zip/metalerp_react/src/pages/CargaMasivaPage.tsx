import { ExternalLink, Upload } from 'lucide-react'

export default function CargaMasivaPage() {
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <h2 style={{ fontSize:18, fontWeight:700 }}>Carga masiva desde Excel</h2>

      <div className="card" style={{ padding:24, textAlign:'center' }}>
        <div style={{
          width:56, height:56, borderRadius:14, background:'var(--c-primary-lt)',
          display:'inline-flex', alignItems:'center', justifyContent:'center',
          color:'var(--c-primary)', margin:'0 auto 16px'
        }}>
          <Upload size={24}/>
        </div>
        <h3 style={{ fontSize:16, fontWeight:600, marginBottom:8 }}>Carga masiva</h3>
        <p style={{ fontSize:13, color:'var(--c-text-3)', maxWidth:480, margin:'0 auto 18px' }}>
          La carga masiva desde Excel (con plantillas descargables, soporte multi-archivo, validación de FKs y conversión automática) 
          requiere XLSX en el navegador y manejo de archivos. Está disponible en la versión anterior.
        </p>
        <a
          href="/"
          className="btn btn-primary"
          style={{ textDecoration:'none', display:'inline-flex', gap:6 }}
        >
          <ExternalLink size={14}/> Abrir versión anterior
        </a>
        <p style={{ fontSize:11, color:'var(--c-text-3)', marginTop:16 }}>
          Desde el menú, ir a Sistema → Carga masiva
        </p>
      </div>
    </div>
  )
}
