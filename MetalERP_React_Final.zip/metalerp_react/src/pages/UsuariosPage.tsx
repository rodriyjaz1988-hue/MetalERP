import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw, Trash2 } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState } from '../components/ui'

interface Usuario {
  id: number; username: string; nombre: string
  rol: string; activo: number; creado: string
}

const ROLES = ['admin','operario','vendedor','almacen']

export default function UsuariosPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Usuario[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [form, setForm] = useState({ username:'', password:'', nombre:'', rol:'operario' })

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Usuario[]>('/usuarios')) }
    catch { toast('Error cargando usuarios','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = () => {
    setForm({ username:'', password:'', nombre:'', rol:'operario' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.username || !form.password || !form.nombre) { toast('Todos los campos requeridos','warn'); return }
    try {
      await api.post('/usuarios', form)
      toast('Usuario creado')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const delUser = async (u: Usuario) => {
    if (!window.confirm(`¿Eliminar al usuario ${u.username}? Esta acción es definitiva.`)) return
    try { await api.delete(`/usuarios/${u.id}`); toast('Usuario eliminado'); load() }
    catch (e:any) { toast(e.message,'error') }
  }

  const rolColor: Record<string,'red'|'blue'|'green'|'amber'> = {
    admin:'red', operario:'blue', vendedor:'green', almacen:'amber'
  }

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Usuarios del sistema</h2>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nuevo usuario</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : rows.length === 0 ? (
          <EmptyState title="Sin usuarios"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>Usuario</th><th>Nombre</th><th>Rol</th><th>Estado</th><th></th>
            </tr></thead>
            <tbody>{rows.map(r => (
              <tr key={r.id}>
                <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.username}</b></td>
                <td style={{fontSize:13}}>{r.nombre}</td>
                <td><Badge value={r.rol} variant={rolColor[r.rol]||'gray'}/></td>
                <td><Badge value={r.activo?'Activo':'Inactivo'} variant={r.activo?'green':'gray'}/></td>
                <td>
                  <button className="btn btn-xs btn-danger" onClick={()=>delUser(r)} title="Eliminar usuario">
                    <Trash2 size={11}/>
                  </button>
                </td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)} title="Nuevo usuario"
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Crear usuario</button></>}
      >
        <div className="form-grid">
          <div className="form-group"><label className="form-label">Usuario *</label>
            <input className="form-input" value={form.username} onChange={e=>setForm(f=>({...f,username:e.target.value}))} placeholder="jperez"/></div>
          <div className="form-group"><label className="form-label">Rol</label>
            <select className="form-select" value={form.rol} onChange={e=>setForm(f=>({...f,rol:e.target.value}))}>
              {ROLES.map(r=><option key={r} value={r}>{r}</option>)}</select></div>
          <div className="form-group col-span-2"><label className="form-label">Nombre completo *</label>
            <input className="form-input" value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))}/></div>
          <div className="form-group col-span-2"><label className="form-label">Contraseña *</label>
            <input className="form-input" type="password" value={form.password} onChange={e=>setForm(f=>({...f,password:e.target.value}))}/></div>
        </div>
      </Modal>
    </div>
  )
}
