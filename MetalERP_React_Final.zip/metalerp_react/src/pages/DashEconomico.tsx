import { useEffect, useState } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { PageLoading, fmtMoney } from '../components/ui'

export default function DashEconomico() {
  const toast = useToast()
  const [dash, setDash] = useState<any>(null)
  const [cliData, setCliData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([api.dashEconomico(), api.dashFacCliente()])
      .then(([d, c]) => { setDash(d); setCliData(c) })
      .catch(() => toast('Error cargando dashboard', 'error'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <PageLoading/>
  if (!dash) return null

  const stats = [
    { label: 'Facturación del mes',    value: fmtMoney(dash.facturacion_mes), sub: 'presupuestos facturados' },
    { label: 'Valor pedidos activos',  value: fmtMoney(dash.valor_pedidos),   sub: 'en producción' },
    { label: 'Compras pendientes',     value: String(dash.compras_pendientes), sub: `${fmtMoney(dash.monto_compras_pend)} en OCs` },
    { label: 'Pedidos de clientes',    value: String(dash.pedidos_activos),   sub: 'activos' },
  ]

  const COLORS = ['#2C5F8A','#A32D2D','#1B5E20','#E65100','#6A1B9A','#00695C','#F57F17','#4527A0']
  const meses = cliData ? Array.from({length:12},(_,i)=>`${cliData.anio}-${String(i+1).padStart(2,'0')}`) : []
  const clientes: string[] = cliData ? [...new Set([
    ...(cliData.facturado||[]).map((r:any)=>r.cliente),
    ...(cliData.pedidos||[]).map((r:any)=>r.cliente),
  ])].slice(0,8) as string[] : []

  const byKey: Record<string,(typeof cliData.facturado[0])> = {}
  if (cliData) {
    ;(cliData.facturado||[]).forEach((r:any) => { byKey[`${r.mes}|${r.cliente}`] = {fact:r.total,ped:0} })
    ;(cliData.pedidos||[]).forEach((r:any) => {
      const k = `${r.mes}|${r.cliente}`
      if (byKey[k]) byKey[k].ped = r.total
      else byKey[k] = {fact:0, ped:r.total}
    })
  }

  const maxVal = meses.reduce((mx, m) => {
    const s = clientes.reduce((a,c) => a+(byKey[`${m}|${c}`]?.fact||0)+(byKey[`${m}|${c}`]?.ped||0), 0)
    return Math.max(mx, s)
  }, 1)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:20 }}>
      <h2 style={{ fontSize:18, fontWeight:700 }}>Dashboard Económico / Financiero</h2>

      {/* Stats */}
      <div className="grid-4">
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div className="stat-label">{s.label}</div>
            <div className="stat-value" style={{ fontSize:22 }}>{s.value}</div>
            <div className="stat-sub">{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Facturación por cliente/mes */}
      {cliData && clientes.length > 0 && (
        <div className="card">
          <div className="card-header">
            <span className="card-title">Facturación por cliente — {cliData.anio}</span>
          </div>
          {/* Legend */}
          <div style={{ display:'flex', gap:12, flexWrap:'wrap', marginBottom:12 }}>
            {clientes.map((c,i) => (
              <span key={c} style={{ display:'flex', alignItems:'center', gap:4, fontSize:11 }}>
                <span style={{ width:10, height:10, borderRadius:2, background:COLORS[i%COLORS.length], display:'inline-block'}}/>
                {c}
              </span>
            ))}
          </div>
          {/* Chart */}
          <div style={{ display:'flex', gap:3, alignItems:'flex-end', height:130, overflowX:'auto', paddingBottom:28, position:'relative' }}>
            {meses.map(m => {
              const isPast = m < cliData.mes_actual
              const isCur = m === cliData.mes_actual
              return (
                <div key={m} style={{ flex:1, minWidth:28, display:'flex', flexDirection:'column', justifyContent:'flex-end', alignItems:'center', position:'relative' }}>
                  {clientes.map((c,ci) => {
                    const v = (byKey[`${m}|${c}`]?.fact||0)+(byKey[`${m}|${c}`]?.ped||0)
                    if (!v) return null
                    const h = Math.round((v/maxVal)*110)
                    return (
                      <div key={c} title={`${c}: ${fmtMoney(v)}`} style={{
                        width:'100%', height:h,
                        background: isPast ? COLORS[ci%COLORS.length] : 'transparent',
                        border: isPast ? 'none' : `2px dashed ${COLORS[ci%COLORS.length]}`,
                        boxSizing:'border-box',
                      }}/>
                    )
                  })}
                  <span style={{ position:'absolute', bottom:-20, fontSize:9, color:isCur?'var(--c-primary)':'var(--c-text-3)', fontWeight:isCur?700:400, whiteSpace:'nowrap' }}>
                    {m.slice(5)}{isCur?' ◀':''}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      )}

      <div className="grid-2">
        {/* Top clientes */}
        <div className="card">
          <div className="card-header"><span className="card-title">Top clientes</span></div>
          {!dash.top_clientes?.length
            ? <p style={{color:'var(--c-text-3)',fontSize:13}}>Sin datos</p>
            : <table><thead><tr><th>Cliente</th><th>Total</th></tr></thead><tbody>
                {dash.top_clientes.map((c:any) => (
                  <tr key={c.cliente}><td style={{fontSize:13}}>{c.cliente}</td><td style={{fontSize:13}}><b>{fmtMoney(c.total)}</b></td></tr>
                ))}
              </tbody></table>
          }
        </div>
        {/* Empleados ratio */}
        <div className="card">
          <div className="card-header"><span className="card-title">Ratio empleados</span></div>
          {!cliData?.empleados?.length
            ? <p style={{color:'var(--c-text-3)',fontSize:13}}>Sin empleados registrados</p>
            : (() => {
                const total = cliData.empleados.reduce((s:number,e:any)=>s+e.cantidad,0)
                return <table><thead><tr><th>Tipo</th><th>Cantidad</th><th>%</th></tr></thead><tbody>
                  {cliData.empleados.map((e:any) => {
                    const pct = Math.round(e.cantidad/total*100)
                    return (
                      <tr key={e.tipo}>
                        <td style={{fontSize:13}}>{e.tipo}</td>
                        <td style={{fontSize:13}}><b>{e.cantidad}</b></td>
                        <td style={{minWidth:100}}>
                          <div style={{display:'flex',alignItems:'center',gap:6}}>
                            <div className="progress-bar" style={{flex:1}}>
                              <div className="progress-fill" style={{width:`${pct}%`}}/>
                            </div>
                            <span style={{fontSize:11}}>{pct}%</span>
                          </div>
                        </td>
                      </tr>
                    )
                  })}
                </tbody></table>
              })()
          }
        </div>
      </div>
    </div>
  )
}
