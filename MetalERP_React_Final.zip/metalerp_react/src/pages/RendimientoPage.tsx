import { useEffect, useState, useCallback } from 'react'
import { RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { PageLoading, EmptyState } from '../components/ui'

interface RendOp {
  empleado_id: number; empleado_nombre: string; tipo: string
  total_novedades: number; avg_rend: number
  total_producido: number; total_horas: number
}

export default function RendimientoPage() {
  const toast = useToast()
  const [rows, setRows] = useState<RendOp[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<RendOp[]>('/rendimiento_operarios')) }
    catch { toast('Error cargando rendimiento','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const sorted = [...rows].sort((a,b) => b.avg_rend - a.avg_rend)

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Rendimiento de operarios</h2>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : sorted.length === 0 ? (
          <EmptyState title="Sin datos de rendimiento" desc="Aún no hay novedades de producción con cantidad y tiempo registrados"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>#</th><th>Empleado</th><th>Tipo</th>
              <th style={{minWidth:200}}>Rendimiento promedio</th>
              <th>Novedades</th><th>Total producido</th><th>Horas trabajadas</th>
            </tr></thead>
            <tbody>{sorted.map((r,i) => {
              const pct = Math.min(r.avg_rend||0,100)
              const color = pct>=90?'var(--c-green)':pct>=70?'var(--c-primary)':pct>=50?'var(--c-amber)':'var(--c-red)'
              return (
                <tr key={r.empleado_id}>
                  <td style={{fontSize:13,textAlign:'center',color:'var(--c-text-3)'}}>{i+1}</td>
                  <td style={{fontSize:13,fontWeight:600}}>{r.empleado_nombre}</td>
                  <td style={{fontSize:12,color:'var(--c-text-3)'}}>{r.tipo}</td>
                  <td>
                    <div style={{display:'flex',alignItems:'center',gap:8}}>
                      <div className="progress-bar" style={{flex:1}}>
                        <div className="progress-fill" style={{width:`${pct}%`,background:color}}/>
                      </div>
                      <span style={{fontSize:12,fontWeight:600,color,minWidth:40}}>{pct}%</span>
                    </div>
                  </td>
                  <td style={{fontSize:12,textAlign:'center'}}>{r.total_novedades}</td>
                  <td style={{fontSize:12,textAlign:'right'}}>{r.total_producido}</td>
                  <td style={{fontSize:12,textAlign:'right'}}>{r.total_horas?`${r.total_horas} hs`:'—'}</td>
                </tr>
              )
            })}</tbody>
          </table></div>
        )}
      </div>
    </div>
  )
}
