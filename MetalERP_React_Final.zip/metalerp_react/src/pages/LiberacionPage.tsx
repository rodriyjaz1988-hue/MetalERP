import { useEffect, useState, useCallback } from 'react'
import { RefreshCw, CheckCircle, XCircle } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { PageLoading, EmptyState, fmtDate } from '../components/ui'

interface Lote {
  id: number; numero: string; material_id: number
  mat_codigo: string; mat_descripcion: string; mat_unidad: string
  cantidad_original: number; cantidad_disponible: number; cantidad_activa: number
  estado: string; proveedor_nombre: string | null
  referencia_proveedor: string | null; fecha_ingreso: string
}

export default function LiberacionPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Lote[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Lote[]>('/lotes?estado=Ingresado')) }
    catch { toast('Error cargando lotes', 'error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const liberar = async (lote: Lote) => {
    const cantStr = window.prompt(`Cantidad a aprobar (disponible: ${lote.cantidad_disponible} ${lote.mat_unidad})`, String(lote.cantidad_disponible))
    if (!cantStr) return
    const cant = parseFloat(cantStr)
    if (isNaN(cant) || cant <= 0) { toast('Cantidad inválida', 'warn'); return }
    try {
      await api.post(`/lotes/${lote.id}/liberar`, { cantidad: cant })
      toast(`Lote ${lote.numero} aprobado`)
      load()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const rechazar = async (lote: Lote) => {
    if (!window.confirm(`¿Rechazar el lote ${lote.numero}?`)) return
    try {
      await api.post(`/lotes/${lote.id}/rechazar`, {})
      toast(`Lote ${lote.numero} rechazado`)
      load()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    return !q || r.numero.toLowerCase().includes(q) || r.mat_codigo.toLowerCase().includes(q) || r.mat_descripcion.toLowerCase().includes(q)
  })

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, flexWrap: 'wrap' }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, flex: 1 }}>Liberación de lotes</h2>
        {filtered.length > 0 && (
          <div style={{ background: 'var(--c-amber-bg)', color: 'var(--c-amber)', padding: '5px 12px', borderRadius: 8, fontSize: 13, fontWeight: 600 }}>
            {filtered.length} lote{filtered.length !== 1 ? 's' : ''} pendiente{filtered.length !== 1 ? 's' : ''} de liberación
          </div>
        )}
        <input className="form-input" style={{ width: 200 }} placeholder="Buscar lote..." value={search} onChange={e => setSearch(e.target.value)} />
        <button className="btn" onClick={load}><RefreshCw size={14} /></button>
      </div>

      <div className="card" style={{ padding: 0 }}>
        {loading ? <PageLoading /> : filtered.length === 0 ? (
          <EmptyState title="Sin lotes pendientes" desc="Todos los lotes ingresados ya fueron liberados" />
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>N° Lote</th><th>Artículo</th><th>Total disp.</th>
              <th style={{ color: 'var(--c-green)' }}>✓ Aprobado</th>
              <th style={{ color: 'var(--c-text-3)' }}>⏳ Sin aprobar</th>
              <th>Proveedor / Ref.</th><th>Ingreso</th><th></th>
            </tr></thead>
            <tbody>{filtered.map(r => {
              const sinApr = r.cantidad_disponible - r.cantidad_activa
              return (
                <tr key={r.id}>
                  <td><b style={{ fontFamily: 'monospace', fontSize: 12 }}>{r.numero}</b></td>
                  <td style={{ fontSize: 12 }}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                  <td style={{ fontSize: 12 }}>{r.cantidad_disponible} {r.mat_unidad}</td>
                  <td style={{ fontSize: 12, color: 'var(--c-green)', fontWeight: 600 }}>{r.cantidad_activa}</td>
                  <td style={{ fontSize: 12, color: sinApr > 0 ? 'var(--c-amber)' : 'var(--c-text-3)', fontWeight: sinApr > 0 ? 600 : 400 }}>
                    {sinApr.toFixed(3)}
                  </td>
                  <td style={{ fontSize: 12 }}>{r.proveedor_nombre || r.referencia_proveedor || '—'}</td>
                  <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_ingreso)}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-xs btn-primary" style={{ background: 'var(--c-green)', borderColor: 'var(--c-green)' }} onClick={() => liberar(r)} title="Aprobar lote">
                        <CheckCircle size={11} /> Aprobar
                      </button>
                      <button className="btn btn-xs btn-danger" onClick={() => rechazar(r)} title="Rechazar lote">
                        <XCircle size={11} />
                      </button>
                    </div>
                  </td>
                </tr>
              )
            })}</tbody>
          </table></div>
        )}
      </div>
    </div>
  )
}
