import { useEffect, useState, useCallback } from 'react'
import { RefreshCw, ArrowDown, ArrowUp } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { PageLoading, EmptyState, fmtDate } from '../components/ui'

interface Mov {
  id: number; fecha: string; tipo: 'entrada' | 'salida' | 'ajuste'
  material_id: number; mat_codigo: string; mat_descripcion: string; mat_unidad: string
  lote_id: number | null; lote_numero: string | null
  cantidad: number; referencia: string | null; usuario_nombre: string | null
}

export default function MovimientosPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Mov[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [tipoFilter, setTipoFilter] = useState('')

  const load = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<Mov[]>('/movimientos')) }
    catch { toast('Error cargando movimientos','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const filtered = rows.filter(r => {
    const q = search.toLowerCase()
    const matchQ = !q || r.mat_codigo.toLowerCase().includes(q) ||
      r.mat_descripcion.toLowerCase().includes(q) ||
      (r.referencia||'').toLowerCase().includes(q)
    const matchT = !tipoFilter || r.tipo === tipoFilter
    return matchQ && matchT
  })

  const tipoColor: Record<string,'green'|'red'|'amber'> = { entrada:'green', salida:'red', ajuste:'amber' }
  const tipoIcon = (t: string) => t === 'entrada' ? <ArrowDown size={11}/> : t === 'salida' ? <ArrowUp size={11}/> : null

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Movimientos de inventario</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar material..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <select className="form-select" style={{ width:140 }} value={tipoFilter} onChange={e=>setTipoFilter(e.target.value)}>
          <option value="">Todos los tipos</option>
          <option value="entrada">Entradas</option>
          <option value="salida">Salidas</option>
          <option value="ajuste">Ajustes</option>
        </select>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin movimientos" desc="Aún no hay movimientos de inventario registrados"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>Fecha</th><th>Tipo</th><th>Material</th><th>Lote</th>
              <th>Cantidad</th><th>Referencia</th><th>Usuario</th>
            </tr></thead>
            <tbody>{filtered.map(r => (
              <tr key={r.id}>
                <td style={{fontSize:12}}>{fmtDate(r.fecha)}</td>
                <td>
                  <span className={`badge badge-${tipoColor[r.tipo]}`} style={{ display:'inline-flex', alignItems:'center', gap:3 }}>
                    {tipoIcon(r.tipo)} {r.tipo}
                  </span>
                </td>
                <td style={{fontSize:12}}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                <td style={{fontSize:12,fontFamily:'monospace'}}>{r.lote_numero||'—'}</td>
                <td style={{fontSize:13,fontWeight:600,color: tipoColor[r.tipo]==='green'?'var(--c-green)':tipoColor[r.tipo]==='red'?'var(--c-red)':undefined}}>
                  {r.tipo === 'entrada' ? '+' : r.tipo === 'salida' ? '−' : '±'}{Math.abs(r.cantidad)} {r.mat_unidad}
                </td>
                <td style={{fontSize:12}}>{r.referencia||'—'}</td>
                <td style={{fontSize:11,color:'var(--c-text-3)'}}>{r.usuario_nombre||'—'}</td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>
    </div>
  )
}
