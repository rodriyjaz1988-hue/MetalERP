import { useEffect, useState, useCallback } from 'react'
import { Plus, RefreshCw } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Modal, Badge, PageLoading, EmptyState } from '../components/ui'

interface Cat { id: number; nombre: string }
interface Maq {
  id: number; codigo: string; nombre: string
  categoria_id: number | null; categoria_nombre: string | null
  ubicacion: string | null; estado: string
}

const ESTADOS = ['Operativa','En mantenimiento','Fuera de servicio']

export default function MaquinasPage() {
  const toast = useToast()
  const [rows, setRows] = useState<Maq[]>([])
  const [cats, setCats] = useState<Cat[]>([])
  const [loading, setLoading] = useState(true)
  const [search, setSearch] = useState('')
  const [showModal, setShowModal] = useState(false)
  const [editing, setEditing] = useState<Maq | null>(null)
  const [form, setForm] = useState({ codigo:'', nombre:'', categoria_id:'', ubicacion:'', estado:'Operativa', obs:'' })

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [m, c] = await Promise.all([api.get<Maq[]>('/maquinas'), api.get<Cat[]>('/categorias_maquina')])
      setRows(m); setCats(c)
    } catch { toast('Error cargando máquinas','error') }
    finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const openNew = () => {
    setEditing(null)
    setForm({ codigo:'', nombre:'', categoria_id:'', ubicacion:'', estado:'Operativa', obs:'' })
    setShowModal(true)
  }

  const openEdit = (m: Maq) => {
    setEditing(m)
    setForm({ codigo:m.codigo, nombre:m.nombre, categoria_id:String(m.categoria_id??''), ubicacion:m.ubicacion||'', estado:m.estado, obs:'' })
    setShowModal(true)
  }

  const save = async () => {
    if (!form.codigo || !form.nombre) { toast('Código y nombre requeridos','warn'); return }
    const body = { ...form, categoria_id: form.categoria_id ? Number(form.categoria_id) : null }
    try {
      editing ? await api.put(`/maquinas/${editing.id}`, body) : await api.post('/maquinas', body)
      toast(editing?'Máquina actualizada':'Máquina creada')
      setShowModal(false); load()
    } catch (e:any) { toast(e.message,'error') }
  }

  const filtered = rows.filter(r => !search || r.codigo.toLowerCase().includes(search.toLowerCase()) || r.nombre.toLowerCase().includes(search.toLowerCase()))

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>
      <div style={{ display:'flex', alignItems:'center', gap:10, flexWrap:'wrap' }}>
        <h2 style={{ fontSize:18, fontWeight:700, flex:1 }}>Máquinas</h2>
        <input className="form-input" style={{ width:220 }} placeholder="Buscar máquina..." value={search} onChange={e=>setSearch(e.target.value)}/>
        <button className="btn" onClick={load}><RefreshCw size={14}/></button>
        <button className="btn btn-primary" onClick={openNew}><Plus size={14}/> Nueva máquina</button>
      </div>

      <div className="card" style={{ padding:0 }}>
        {loading ? <PageLoading/> : filtered.length === 0 ? (
          <EmptyState title="Sin máquinas"/>
        ) : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>Código</th><th>Nombre</th><th>Categoría</th><th>Ubicación</th><th>Estado</th><th></th>
            </tr></thead>
            <tbody>{filtered.map(r => (
              <tr key={r.id}>
                <td><b style={{fontFamily:'monospace',fontSize:12}}>{r.codigo}</b></td>
                <td style={{fontSize:13}}>{r.nombre}</td>
                <td style={{fontSize:12}}>{r.categoria_nombre||'—'}</td>
                <td style={{fontSize:12}}>{r.ubicacion||'—'}</td>
                <td><Badge value={r.estado}/></td>
                <td><button className="btn btn-xs" onClick={()=>openEdit(r)}>Editar</button></td>
              </tr>
            ))}</tbody>
          </table></div>
        )}
      </div>

      <Modal open={showModal} onClose={()=>setShowModal(false)} title={editing?`Editar ${editing.codigo}`:'Nueva máquina'}
        footer={<><button className="btn" onClick={()=>setShowModal(false)}>Cancelar</button><button className="btn btn-primary" onClick={save}>Guardar</button></>}
      >
        <div className="form-grid">
          <div className="form-group"><label className="form-label">Código *</label>
            <input className="form-input" value={form.codigo} onChange={e=>setForm(f=>({...f,codigo:e.target.value}))} placeholder="MAQ-001"/></div>
          <div className="form-group"><label className="form-label">Categoría</label>
            <select className="form-select" value={form.categoria_id} onChange={e=>setForm(f=>({...f,categoria_id:e.target.value}))}>
              <option value="">— Sin categoría —</option>
              {cats.map(c=><option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select></div>
          <div className="form-group col-span-2"><label className="form-label">Nombre *</label>
            <input className="form-input" value={form.nombre} onChange={e=>setForm(f=>({...f,nombre:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Ubicación</label>
            <input className="form-input" value={form.ubicacion} onChange={e=>setForm(f=>({...f,ubicacion:e.target.value}))}/></div>
          <div className="form-group"><label className="form-label">Estado</label>
            <select className="form-select" value={form.estado} onChange={e=>setForm(f=>({...f,estado:e.target.value}))}>
              {ESTADOS.map(e=><option key={e} value={e}>{e}</option>)}</select></div>
        </div>
      </Modal>
    </div>
  )
}
