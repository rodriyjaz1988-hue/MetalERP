import { useState, useCallback } from 'react'
import type { ChangeEvent } from 'react'

type FormElement = HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement

/**
 * Lightweight form-state hook. Each field gets a uniform `bind(name)` that returns
 * { value, onChange } props.
 *
 * Usage:
 *   const { values, bind, set, reset } = useForm({ nombre: '', activo: 1 })
 *   <input className="form-input" {...bind('nombre')} />
 */
export function useForm<T extends Record<string, any>>(initial: T) {
  const [values, setValues] = useState<T>(initial)

  const set = useCallback((patch: Partial<T>) => {
    setValues(prev => ({ ...prev, ...patch }))
  }, [])

  const bind = useCallback(<K extends keyof T>(key: K) => ({
    value: values[key] ?? '',
    onChange: (e: ChangeEvent<FormElement>) => {
      setValues(prev => ({ ...prev, [key]: e.target.value }))
    },
  }), [values])

  const reset = useCallback((to?: T) => {
    setValues(to ?? initial)
  }, [initial])

  return { values, set, bind, reset, setValues }
}
