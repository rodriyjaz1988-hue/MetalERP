import { useEffect, useState, useCallback, useMemo } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'

interface UseResourceOpts<T> {
  /** Endpoint path under /api, e.g. '/ordenes' */
  path: string
  /** Field names to match when searching (case-insensitive substring) */
  searchKeys?: (keyof T)[]
  /** Custom filter function applied AFTER search */
  filter?: (item: T) => boolean
  /** Error message override */
  errorMsg?: string
  /** Load immediately on mount (default true) */
  autoLoad?: boolean
}

/**
 * Standard CRUD list hook. Returns the list, loading state, search input handler,
 * a filtered view, and a reload function.
 *
 * Usage:
 *   const { rows, loading, search, setSearch, reload, filtered } =
 *     useResource<OT>({ path: '/ordenes', searchKeys: ['numero', 'descripcion'] })
 */
export function useResource<T>({
  path, searchKeys = [], filter, errorMsg, autoLoad = true,
}: UseResourceOpts<T>) {
  const toast = useToast()
  const [rows, setRows] = useState<T[]>([])
  const [loading, setLoading] = useState(autoLoad)
  const [search, setSearch] = useState('')

  const reload = useCallback(async () => {
    setLoading(true)
    try { setRows(await api.get<T[]>(path)) }
    catch (e: any) { toast(errorMsg || e.message || 'Error cargando datos', 'error') }
    finally { setLoading(false) }
  }, [path, errorMsg, toast])

  useEffect(() => { if (autoLoad) reload() }, [reload, autoLoad])

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase()
    let out = rows
    if (q && searchKeys.length) {
      out = out.filter(r =>
        searchKeys.some(k => {
          const v = r[k]
          return v != null && String(v).toLowerCase().includes(q)
        })
      )
    }
    if (filter) out = out.filter(filter)
    return out
  }, [rows, search, searchKeys, filter])

  return { rows, setRows, loading, search, setSearch, reload, filtered }
}
