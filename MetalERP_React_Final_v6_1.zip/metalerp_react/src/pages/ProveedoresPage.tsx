import { useState, useEffect, Fragment } from 'react'
import { ChevronDown, ChevronRight, Tag, Trash2 } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, fmtMoney } from '../components/ui'

interface MatVinc { id: number; codigo: string; descripcion: string; precio_unit: number; plazo_dias: number; es_principal: number }
interface OTTActiva { id: number; numero: string; producto_codigo: string | null; estado: string; precio_acordado: number }
interface Material { id: number; codigo: string; descripcion: string; unidad: string }
interface Prov {
  id: number; razon: string; cuit: string | null; contacto: string | null
  telefono: string | null; email: string | null; plazo_dias: number
  calificacion: number; estado: string; rubro: string | null
  mat_vinculados: MatVinc[]
}

const ESTADOS_OTT_INACTIVOS = new Set(['Completado', 'Cancelado'])

function stars(n: number) {
  return '★'.repeat(n) + '☆'.repeat(5 - n)
}

export default function ProveedoresPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<Prov>({
    path: '/proveedores',
    searchKeys: ['razon', 'contacto'],
    errorMsg: 'Error cargando proveedores',
  })
  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [matsByProv, setMatsByProv] = useState<Record<number, MatVinc[]>>({})
  const [ottsByProv, setOttsByProv] = useState<Record<number, OTTActiva[]>>({})
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Prov | null>(null)
  const { values, bind, reset } = useForm({
    razon: '', cuit: '', contacto: '', telefono: '', email: '',
    plazo_dias: '30', calificacion: '4', estado: 'Activo', rubro: '',
  })

  // Price-list modal
  const [priceProv, setPriceProv] = useState<Prov | null>(null)
  const [priceMats, setPriceMats] = useState<MatVinc[]>([])
  const [allMats, setAllMats] = useState<Material[]>([])
  const priceForm = useForm({ material_id: '', precio_unit: '', plazo_dias: '3', es_principal: false })

  useEffect(() => { api.get<Material[]>('/materiales').then(setAllMats).catch(() => {}) }, [])

  async function openPriceList(p: Prov) {
    setPriceProv(p)
    priceForm.reset({ material_id: '', precio_unit: '', plazo_dias: '3', es_principal: false })
    try { setPriceMats(await api.get<MatVinc[]>(`/proveedores/${p.id}/materiales`)) }
    catch { setPriceMats([]) }
  }

  async function addPrice() {
    if (!priceProv || !priceForm.values.material_id) { toast('Seleccioná un material', 'warn'); return }
    try {
      await api.post(`/proveedores/${priceProv.id}/materiales`, {
        material_id: Number(priceForm.values.material_id),
        precio_unit: Number(priceForm.values.precio_unit) || 0,
        plazo_dias: Number(priceForm.values.plazo_dias) || 3,
        es_principal: priceForm.values.es_principal,
      })
      setPriceMats(await api.get<MatVinc[]>(`/proveedores/${priceProv.id}/materiales`))
      priceForm.reset({ material_id: '', precio_unit: '', plazo_dias: '3', es_principal: false })
      toast('Artículo agregado a la lista')
      // refresh expanded view if open
      if (matsByProv[priceProv.id]) {
        setMatsByProv(prev => ({ ...prev, [priceProv.id]: [] }))
      }
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function removePrice(matId: number) {
    if (!priceProv) return
    try {
      await api.delete(`/proveedores/${priceProv.id}/materiales/${matId}`)
      setPriceMats(await api.get<MatVinc[]>(`/proveedores/${priceProv.id}/materiales`))
      toast('Artículo quitado')
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function toggle(id: number) {
    const next = new Set(expanded)
    if (next.has(id)) { next.delete(id); setExpanded(next); return }
    next.add(id); setExpanded(next)
    if (!matsByProv[id]) {
      const [mats, otts] = await Promise.all([
        api.get<MatVinc[]>(`/proveedores/${id}/materiales`),
        api.get<any[]>(`/ott?proveedor_id=${id}`),
      ])
      setMatsByProv(p => ({ ...p, [id]: mats }))
      setOttsByProv(p => ({ ...p, [id]: otts.filter(o => !ESTADOS_OTT_INACTIVOS.has(o.estado)) }))
    }
  }

  function openNew() {
    setEditing(null)
    reset({ razon: '', cuit: '', contacto: '', telefono: '', email: '', plazo_dias: '30', calificacion: '4', estado: 'Activo', rubro: '' })
    setOpen(true)
  }

  function openEdit(p: Prov) {
    setEditing(p)
    reset({
      razon: p.razon, cuit: p.cuit || '', contacto: p.contacto || '',
      telefono: p.telefono || '', email: p.email || '',
      plazo_dias: String(p.plazo_dias), calificacion: String(p.calificacion),
      estado: p.estado, rubro: p.rubro || '',
    })
    setOpen(true)
  }

  async function save() {
    if (!values.razon) { toast('Razón social requerida', 'warn'); return }
    const body = { ...values, plazo_dias: Number(values.plazo_dias), calificacion: Number(values.calificacion) }
    try {
      editing
        ? await api.put(`/proveedores/${editing.id}`, body)
        : await api.post('/proveedores', body)
      toast(editing ? 'Proveedor actualizado' : 'Proveedor registrado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Proveedores"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar proveedor..."
        onReload={reload} primaryLabel="Nuevo proveedor" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin proveedores" desc="Registrá el primer proveedor" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th style={{ width: 36 }}></th>
                <th>Razón social</th><th>Contacto</th><th>Teléfono</th>
                <th>Plazo</th><th>Calificación</th><th>Estado</th><th>Lista de precios</th><th></th>
              </tr></thead>
              <tbody>
                {filtered.map(r => {
                  const isExp = expanded.has(r.id)
                  const mats = matsByProv[r.id]
                  const otts = ottsByProv[r.id]
                  return (
                    <Fragment key={r.id}>
                      <tr>
                        <td>
                          <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--c-text-3)' }} onClick={() => toggle(r.id)}>
                            {isExp ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                          </button>
                        </td>
                        <td><b style={{ fontSize: 13 }}>{r.razon}</b></td>
                        <td style={{ fontSize: 12 }}>{r.contacto || '—'}</td>
                        <td style={{ fontSize: 12 }}>{r.telefono || '—'}</td>
                        <td style={{ fontSize: 12 }}>{r.plazo_dias}d</td>
                        <td style={{ fontSize: 13, color: 'var(--c-star)' }}>{stars(r.calificacion)}</td>
                        <td><Badge value={r.estado} /></td>
                        <td style={{ fontSize: 12, color: 'var(--c-text-3)' }}>
                          {r.mat_vinculados?.length
                            ? `${r.mat_vinculados.length} artículo${r.mat_vinculados.length !== 1 ? 's' : ''}`
                            : 'Sin artículos'}
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: 4 }}>
                            <button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button>
                            <button className="btn btn-xs" onClick={() => openPriceList(r)} title="Lista de precios">
                              <Tag size={11} />
                            </button>
                          </div>
                        </td>
                      </tr>
                      {isExp && (
                        <tr>
                          <td colSpan={9} style={{ padding: 0 }}>
                            <div style={{ padding: '10px 12px 12px 48px', background: 'var(--c-bg)', borderBottom: '1px solid var(--c-border)' }}>
                              {!mats ? <span style={{ fontSize: 12, color: 'var(--c-text-3)' }}>Cargando...</span> : (
                                <>
                                  {mats.length === 0
                                    ? <p style={{ fontSize: 12, color: 'var(--c-text-3)' }}>Sin artículos en lista de precios.</p>
                                    : (
                                      <>
                                        <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--c-text-3)', marginBottom: 6 }}>LISTA DE PRECIOS</div>
                                        <table style={{ fontSize: 11 }}>
                                          <thead><tr><th>Código</th><th>Descripción</th><th>Precio unit.</th><th>Plazo</th><th>Principal</th></tr></thead>
                                          <tbody>{mats.map(m => (
                                            <tr key={m.id}>
                                              <td><b>{m.codigo}</b></td>
                                              <td>{m.descripcion}</td>
                                              <td><b>{fmtMoney(m.precio_unit)}</b></td>
                                              <td>{m.plazo_dias || '—'}d</td>
                                              <td>{m.es_principal ? <Badge value="✓ Principal" variant="green" /> : ''}</td>
                                            </tr>
                                          ))}</tbody>
                                        </table>
                                      </>
                                    )
                                  }
                                  {otts && otts.length > 0 && (
                                    <>
                                      <div style={{ fontSize: 11, fontWeight: 600, color: 'var(--c-text-3)', margin: '10px 0 6px' }}>OTTs ACTIVAS</div>
                                      <table style={{ fontSize: 11 }}>
                                        <thead><tr><th>N°</th><th>Producto</th><th>Estado</th><th>Precio</th></tr></thead>
                                        <tbody>{otts.map(o => (
                                          <tr key={o.id}>
                                            <td><b>{o.numero}</b></td>
                                            <td>{o.producto_codigo || '—'}</td>
                                            <td><Badge value={o.estado} /></td>
                                            <td>{fmtMoney(o.precio_acordado)}</td>
                                          </tr>
                                        ))}</tbody>
                                      </table>
                                    </>
                                  )}
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  )
                })}
              </tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar: ${editing.razon}` : 'Nuevo proveedor'}
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Razón social" required span2><input className="form-input" {...bind('razon')} /></Field>
          <Field label="CUIT"><input className="form-input" {...bind('cuit')} /></Field>
          <Field label="Rubro"><input className="form-input" {...bind('rubro')} /></Field>
          <Field label="Contacto"><input className="form-input" {...bind('contacto')} /></Field>
          <Field label="Teléfono"><input className="form-input" {...bind('telefono')} /></Field>
          <Field label="Email"><input className="form-input" type="email" {...bind('email')} /></Field>
          <Field label="Plazo (días)"><input className="form-input" type="number" min="0" {...bind('plazo_dias')} /></Field>
          <Field label="Calificación (1-5)"><input className="form-input" type="number" min="1" max="5" {...bind('calificacion')} /></Field>
          <Field label="Estado">
            <select className="form-select" {...bind('estado')}>
              <option>Activo</option><option>Inactivo</option><option>Suspendido</option>
            </select>
          </Field>
        </div>
      </Modal>

      {/* Price list modal */}
      <Modal open={!!priceProv} onClose={() => setPriceProv(null)}
        title={priceProv ? `Lista de precios — ${priceProv.razon}` : ''} size="lg"
        footer={<button className="btn" onClick={() => setPriceProv(null)}>Cerrar</button>}
      >
        <div style={{ marginBottom: 16, padding: 12, background: 'var(--c-bg)', borderRadius: 8 }}>
          <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8 }}>Agregar artículo a la lista</div>
          <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
            <div style={{ flex: '2 1 200px' }}>
              <label className="form-label">Material</label>
              <select className="form-select" {...priceForm.bind('material_id')}>
                <option value="">— Seleccionar —</option>
                {allMats.filter(m => !priceMats.some(pm => pm.id === m.id)).map(m => (
                  <option key={m.id} value={m.id}>{m.codigo} — {m.descripcion}</option>
                ))}
              </select>
            </div>
            <div style={{ flex: '1 1 90px' }}>
              <label className="form-label">Precio</label>
              <input className="form-input" type="number" min="0" step="0.01" {...priceForm.bind('precio_unit')} />
            </div>
            <div style={{ flex: '1 1 70px' }}>
              <label className="form-label">Plazo (d)</label>
              <input className="form-input" type="number" min="0" {...priceForm.bind('plazo_dias')} />
            </div>
            <label style={{ display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, cursor: 'pointer', paddingBottom: 8 }}>
              <input type="checkbox" checked={priceForm.values.es_principal}
                onChange={e => priceForm.set({ es_principal: e.target.checked })} />
              Principal
            </label>
            <button className="btn btn-primary" onClick={addPrice} style={{ marginBottom: 0 }}>Agregar</button>
          </div>
        </div>

        {priceMats.length === 0
          ? <p style={{ fontSize: 12, color: 'var(--c-text-3)', fontStyle: 'italic' }}>Sin artículos en la lista de precios.</p>
          : (
            <table>
              <thead><tr>
                <th>Código</th><th>Descripción</th><th>Precio unit.</th><th>Plazo</th><th>Principal</th><th></th>
              </tr></thead>
              <tbody>{priceMats.map(m => (
                <tr key={m.id}>
                  <td className="cell-mono">{m.codigo}</td>
                  <td style={{ fontSize: 12 }}>{m.descripcion}</td>
                  <td><b>{fmtMoney(m.precio_unit)}</b></td>
                  <td>{m.plazo_dias || '—'}d</td>
                  <td>{m.es_principal ? <Badge value="✓ Principal" variant="green" /> : ''}</td>
                  <td>
                    <button className="btn btn-xs btn-danger" onClick={() => removePrice(m.id)}>
                      <Trash2 size={10} />
                    </button>
                  </td>
                </tr>
              ))}</tbody>
            </table>
          )}
      </Modal>
    </div>
  )
}
