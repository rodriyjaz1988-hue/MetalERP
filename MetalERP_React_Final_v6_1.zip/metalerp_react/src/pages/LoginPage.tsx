import { useState } from 'react'
import type { FormEvent } from 'react'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

export default function LoginPage() {
  const { login } = useAuth()
  const toast = useToast()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  async function handleSubmit(e: FormEvent) {
    e.preventDefault()
    if (!username || !password) { toast('Ingresá usuario y contraseña', 'warn'); return }
    setLoading(true)
    try { await login(username, password) }
    catch (err: any) { toast(err.message || 'Credenciales incorrectas', 'error') }
    finally { setLoading(false) }
  }

  return (
    <div className="login-bg">
      <div className="login-card">
        <div className="login-brand">
          <div className="login-logo">M</div>
          <div>
            <div className="login-title">MetalERP</div>
            <div className="login-subtitle">Sistema de gestión industrial</div>
          </div>
        </div>

        <h1 className="login-form-heading">Iniciar sesión</h1>
        <p className="login-form-sub">Ingresá tus credenciales para continuar</p>

        <form onSubmit={handleSubmit} className="login-form">
          <div className="form-group">
            <label className="form-label">Usuario</label>
            <input
              className="form-input"
              placeholder="admin"
              value={username}
              onChange={e => setUsername(e.target.value)}
              autoFocus
              autoComplete="username"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Contraseña</label>
            <input
              className="form-input"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </div>

          <button type="submit" className="btn btn-primary login-submit" disabled={loading}>
            {loading ? <><span className="spinner" style={{ width: 16, height: 16 }} /> Ingresando...</> : 'Ingresar'}
          </button>
        </form>

        <p className="login-footer">MetalERP v3 · Taller Metalúrgico</p>
      </div>
    </div>
  )
}
