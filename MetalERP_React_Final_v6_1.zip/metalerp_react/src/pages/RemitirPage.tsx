import { useState, useEffect } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, fmtDate } from '../components/ui'

interface Remito {
  id: number; numero: string; cliente_nombre: string
  fecha: string; estado: string; obs: string | null; tipo: string
}

interface Cliente { id: number; razon: string }
interface OC { id: number; numero: string; cliente_id: number }

export default function RemitirPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<Remito>({
    path: '/remitos',
    searchKeys: ['numero', 'cliente_nombre'],
    filter: r => r.tipo !== 'traslado_ott',  // Hide OTT internal remitos
    errorMsg: 'Error cargando remitos',
  })
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [ocs, setOcs] = useState<OC[]>([])
  const [open, setOpen] = useState(false)
  const { values, bind, reset } = useForm({ cliente_id: '', orden_cliente_id: '', obs: '' })

  useEffect(() => {
    Promise.all([api.get<Cliente[]>('/clientes'), api.get<OC[]>('/ordenes_cliente')])
      .then(([c, o]) => { setClientes(c); setOcs(o) })
      .catch(() => {})
  }, [])

  function openNew() {
    reset({ cliente_id: '', orden_cliente_id: '', obs: '' })
    setOpen(true)
  }

  async function save() {
    if (!values.cliente_id) { toast('Cliente requerido', 'warn'); return }
    try {
      await api.post('/remitos', {
        cliente_id: Number(values.cliente_id),
        orden_cliente_id: values.orden_cliente_id ? Number(values.orden_cliente_id) : null,
        obs: values.obs,
      })
      toast('Remito creado'); setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const ocsCli = ocs.filter(o => String(o.cliente_id) === values.cliente_id)

  return (
    <div className="page">
      <Toolbar
        title="Remitir a cliente"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar remito..."
        onReload={reload} primaryLabel="Nuevo remito" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin remitos" desc="No hay remitos a clientes registrados" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>N° Remito</th><th>Cliente</th><th>Fecha</th><th>Estado</th><th>Observaciones</th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.numero}</td>
                  <td style={{ fontSize: 13 }}>{r.cliente_nombre}</td>
                  <td style={{ fontSize: 12 }}>{fmtDate(r.fecha)}</td>
                  <td><Badge value={r.estado} /></td>
                  <td className="cell-tight" style={{ maxWidth: 300 }}>{r.obs || '—'}</td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Nuevo remito a cliente"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Cliente" required span2>
            <select className="form-select" {...bind('cliente_id')}>
              <option value="">— Seleccionar cliente —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select>
          </Field>
          <Field label="OC vinculada (opcional)" span2>
            <select className="form-select" {...bind('orden_cliente_id')} disabled={!values.cliente_id}>
              <option value="">— Sin OC —</option>
              {ocsCli.map(o => <option key={o.id} value={o.id}>{o.numero}</option>)}
            </select>
          </Field>
          <Field label="Observaciones" span2><textarea className="form-textarea" {...bind('obs')} /></Field>
        </div>
      </Modal>
    </div>
  )
}
