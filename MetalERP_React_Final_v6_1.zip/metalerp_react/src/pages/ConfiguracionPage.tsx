import { useState, useEffect } from 'react'
import { Plus, Trash2, Save } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, PageLoading, Toolbar, Card, Field } from '../components/ui'

interface Cat { id: number; nombre: string; descripcion?: string | null }
type ConfigMap = Record<string, { valor: string; descripcion: string | null }>

// Campos de configuración de empresa / PDF, en orden de presentación
const CONFIG_FIELDS: { key: string; label: string; type?: 'text' | 'checkbox' | 'textarea' }[] = [
  { key: 'empresa_nombre',       label: 'Nombre del taller / empresa' },
  { key: 'empresa_subtitulo',    label: 'Subtítulo o rubro' },
  { key: 'empresa_direccion',    label: 'Dirección' },
  { key: 'empresa_telefono',     label: 'Teléfono / WhatsApp' },
  { key: 'empresa_email',        label: 'Email' },
  { key: 'pdf_color_hex',        label: 'Color principal PDF (hex sin #)' },
  { key: 'pdf_mostrar_costos',   label: 'Mostrar costos en PDF', type: 'checkbox' },
  { key: 'pdf_mostrar_precios',  label: 'Mostrar precio de venta en PDF', type: 'checkbox' },
  { key: 'pdf_nota_pie',         label: 'Nota al pie del PDF de OT', type: 'textarea' },
]

function EmpresaConfigSection() {
  const toast = useToast()
  const [config, setConfig] = useState<ConfigMap>({})
  const [values, setValues] = useState<Record<string, string>>({})
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)

  useEffect(() => {
    api.get<ConfigMap>('/config')
      .then(c => {
        setConfig(c)
        const v: Record<string, string> = {}
        Object.entries(c).forEach(([k, { valor }]) => { v[k] = valor })
        setValues(v)
      })
      .catch(() => toast('Error cargando configuración', 'error'))
      .finally(() => setLoading(false))
  }, [])

  function setField(key: string, val: string) {
    setValues(prev => ({ ...prev, [key]: val }))
  }

  async function save() {
    setSaving(true)
    try {
      await api.post('/config', values)
      toast('Configuración guardada')
    } catch (e: any) { toast(e.message, 'error') }
    finally { setSaving(false) }
  }

  if (loading) return <Card title="Datos de la empresa y PDF"><PageLoading /></Card>

  // Solo mostrar campos que existen en la config del backend
  const available = CONFIG_FIELDS.filter(f => f.key in config)

  return (
    <Card title="Datos de la empresa y PDF" action={
      <button className="btn btn-sm btn-primary" onClick={save} disabled={saving}>
        <Save size={12} /> {saving ? 'Guardando...' : 'Guardar'}
      </button>
    }>
      <div className="form-grid">
        {available.map(f => {
          if (f.type === 'checkbox') {
            return (
              <div key={f.key} className="form-group col-span-2">
                <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', fontSize: 13 }}>
                  <input type="checkbox" checked={values[f.key] === '1'}
                    onChange={e => setField(f.key, e.target.checked ? '1' : '0')}
                    style={{ width: 16, height: 16 }} />
                  {f.label}
                </label>
              </div>
            )
          }
          if (f.type === 'textarea') {
            return (
              <Field key={f.key} label={f.label} span2>
                <textarea className="form-textarea" value={values[f.key] || ''}
                  onChange={e => setField(f.key, e.target.value)} />
              </Field>
            )
          }
          return (
            <Field key={f.key} label={f.label} span2={f.key === 'empresa_direccion'}>
              <input className="form-input" value={values[f.key] || ''}
                onChange={e => setField(f.key, e.target.value)} />
            </Field>
          )
        })}
      </div>
    </Card>
  )
}

function CategoriaSection({ title, endpoint }: { title: string; endpoint: string }) {
  const toast = useToast()
  const { loading, reload, rows } = useResource<Cat>({ path: endpoint, errorMsg: `Error cargando ${title}` })
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Cat | null>(null)
  const { values, bind, reset } = useForm({ nombre: '', descripcion: '' })

  function openNew() { setEditing(null); reset({ nombre: '', descripcion: '' }); setOpen(true) }
  function openEdit(c: Cat) { setEditing(c); reset({ nombre: c.nombre, descripcion: c.descripcion || '' }); setOpen(true) }

  async function save() {
    if (!values.nombre) { toast('Nombre requerido', 'warn'); return }
    try {
      editing
        ? await api.put(`${endpoint}/${editing.id}`, values)
        : await api.post(endpoint, values)
      toast('Guardado'); setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function del(c: Cat) {
    if (!window.confirm(`¿Eliminar "${c.nombre}"?`)) return
    try { await api.delete(`${endpoint}/${c.id}`); toast('Eliminado'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <Card title={title} action={
      <button className="btn btn-sm btn-primary" onClick={openNew}><Plus size={12} /> Nuevo</button>
    }>
      {loading ? <PageLoading /> : rows.length === 0 ? (
        <p style={{ color: 'var(--c-text-3)', fontSize: 13 }}>Sin categorías. Creá la primera.</p>
      ) : (
        <table>
          <tbody>{rows.map(r => (
            <tr key={r.id}>
              <td style={{ fontSize: 13, fontWeight: 600 }}>{r.nombre}</td>
              <td style={{ fontSize: 12, color: 'var(--c-text-3)' }}>{r.descripcion || '—'}</td>
              <td style={{ textAlign: 'right' }}>
                <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                  <button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button>
                  <button className="btn btn-xs btn-danger" onClick={() => del(r)}><Trash2 size={10} /></button>
                </div>
              </td>
            </tr>
          ))}</tbody>
        </table>
      )}

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar: ${editing.nombre}` : 'Nueva categoría'}
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Nombre" required span2>
            <input className="form-input" {...bind('nombre')} autoFocus />
          </Field>
          <Field label="Descripción" span2>
            <input className="form-input" {...bind('descripcion')} />
          </Field>
        </div>
      </Modal>
    </Card>
  )
}

export default function ConfiguracionPage() {
  return (
    <div className="page">
      <Toolbar title="Configuración del sistema" />
      <EmpresaConfigSection />
      <div className="kv-grid kv-grid-2">
        <CategoriaSection title="Categorías de productos" endpoint="/categorias_producto" />
        <CategoriaSection title="Categorías de máquinas" endpoint="/categorias_maquina" />
      </div>
    </div>
  )
}
