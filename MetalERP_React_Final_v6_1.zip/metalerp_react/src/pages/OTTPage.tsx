import { useState, useEffect } from 'react'
import { Eye, Truck, PackageCheck, Pencil } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import {
  Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field,
  fmtDate, fmtMoney,
} from '../components/ui'

interface OTT {
  id: number; numero: string; ot_numero: string | null
  op_nombre: string | null; op_orden: number | null
  producto_codigo: string | null; producto_nombre: string | null
  proveedor_id: number | null
  proveedor_nombre: string | null; precio_acordado: number
  es_ultimo_nivel: number; estado: string
  remito_numero: string | null; fecha_envio: string | null
  fecha_retorno_est: string | null; fecha_retorno_real: string | null; obs: string | null
}

interface Proveedor { id: number; razon: string }

const ESTADOS = ['Pendiente', 'Remito emitido', 'En proceso', 'Recibido', 'Completado', 'Cancelado']

interface DetailItem { label: string; value: string }

function DetailGrid({ items, obs }: { items: DetailItem[]; obs?: string | null }) {
  return (
    <div className="kv-grid kv-grid-2">
      {items.map(({ label, value }) => (
        <div key={label} className="kv-cell">
          <div className="kv-label">{label}</div>
          <div className="kv-value">{value}</div>
        </div>
      ))}
      {obs && (
        <div className="kv-cell" style={{ gridColumn: 'span 2' }}>
          <div className="kv-label">Observaciones</div>
          <div className="kv-value">{obs}</div>
        </div>
      )}
    </div>
  )
}

export default function OTTPage() {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<OTT>({
    path: estFilter ? `/ott?estado=${estFilter}` : '/ott',
    searchKeys: ['numero', 'ot_numero', 'producto_codigo', 'proveedor_nombre'],
    errorMsg: 'Error cargando OTTs',
  })
  const [detalle, setDetalle] = useState<OTT | null>(null)
  const [editOTT, setEditOTT] = useState<OTT | null>(null)
  const [showRetorno, setShowRetorno] = useState<OTT | null>(null)
  const [saving, setSaving] = useState(false)
  const [provs, setProvs] = useState<Proveedor[]>([])
  const retForm = useForm({ cantidad: '', obs: '' })
  const editForm = useForm({
    proveedor_id: '', precio_acordado: '0',
    fecha_envio: '', fecha_retorno_est: '', estado: 'Pendiente', obs: '',
  })

  useEffect(() => {
    api.get<Proveedor[]>('/proveedores').then(setProvs).catch(() => {})
  }, [])

  function openEdit(o: OTT) {
    editForm.reset({
      proveedor_id: String(o.proveedor_id ?? ''),
      precio_acordado: String(o.precio_acordado),
      fecha_envio: o.fecha_envio?.slice(0, 10) ?? '',
      fecha_retorno_est: o.fecha_retorno_est?.slice(0, 10) ?? '',
      estado: o.estado,
      obs: o.obs || '',
    })
    setEditOTT(o)
  }

  async function saveEdit() {
    if (!editOTT) return
    try {
      await api.put(`/ott/${editOTT.id}`, {
        proveedor_id: editForm.values.proveedor_id ? Number(editForm.values.proveedor_id) : null,
        precio_acordado: Number(editForm.values.precio_acordado) || 0,
        fecha_envio: editForm.values.fecha_envio || null,
        fecha_retorno_est: editForm.values.fecha_retorno_est || null,
        estado: editForm.values.estado,
        obs: editForm.values.obs,
      })
      toast('OTT actualizada'); setEditOTT(null); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }


  async function emitirRemito(id: number) {
    if (!window.confirm('¿Emitir remito de traslado para esta OTT?')) return
    try {
      const r = await api.post<{ remito_numero: string }>(`/ott/${id}/emitir_remito`, {})
      toast(`Remito ${r.remito_numero} emitido`); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function confirmarRetorno() {
    if (!showRetorno) return
    const qty = parseFloat(retForm.values.cantidad)
    if (!qty || qty <= 0) { toast('Ingresá la cantidad recibida', 'warn'); return }
    setSaving(true)
    try {
      const r = await api.post<{ mensaje: string; lote_numero: string }>(
        `/ott/${showRetorno.id}/registrar_retorno`,
        { cantidad: qty, obs: retForm.values.obs },
      )
      toast(`${r.mensaje} — Lote ${r.lote_numero}`)
      setShowRetorno(null); reload()
    } catch (e: any) { toast(e.message, 'error') }
    finally { setSaving(false) }
  }

  async function completar(id: number) {
    try { await api.post(`/ott/${id}/completar`, {}); toast('OTT completada'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  function openRetorno(o: OTT) {
    retForm.reset({ cantidad: '', obs: '' })
    setShowRetorno(o)
  }

  return (
    <div className="page">
      <Toolbar
        title="OTT — Órdenes de Trabajo de Terceros"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar OTT..."
        onReload={reload}
        rightChildren={
          <select className="form-select" style={{ width: 180 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
            <option value="">Todos los estados</option>
            {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin OTTs" desc="Las OTTs se generan automáticamente desde el MRP cuando una operación está marcada como tercerizada" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>N°</th><th>OT origen</th><th>Operación</th><th>Producto</th>
                <th>Proveedor</th><th>Precio</th><th>Nivel</th>
                <th>F. envío</th><th>F. retorno est.</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.numero}</td>
                  <td style={{ fontSize: 12 }}>{r.ot_numero || '—'}</td>
                  <td style={{ fontSize: 12 }}>{r.op_nombre || '—'}</td>
                  <td style={{ fontSize: 11 }}>{r.producto_codigo || '—'}</td>
                  <td style={{ fontSize: 12 }}>
                    {r.proveedor_nombre || <span style={{ color: 'var(--c-red)', fontSize: 11 }}>Sin asignar</span>}
                  </td>
                  <td style={{ fontSize: 12 }}>{fmtMoney(r.precio_acordado)}</td>
                  <td>
                    {r.es_ultimo_nivel
                      ? <Badge value="PT → cliente" variant="green" />
                      : <Badge value="Semielaborado" variant="amber" />}
                  </td>
                  <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_envio)}</td>
                  <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_retorno_est)}</td>
                  <td><Badge value={r.estado} /></td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-xs" onClick={() => setDetalle(r)} title="Ver detalle"><Eye size={11} /></button>
                      <button className="btn btn-xs" onClick={() => openEdit(r)} title="Editar OTT"><Pencil size={11} /></button>
                      {r.estado === 'Pendiente' && (
                        <button className="btn btn-xs btn-primary" onClick={() => emitirRemito(r.id)} title="Emitir remito de traslado">
                          <Truck size={11} />
                        </button>
                      )}
                      {(r.estado === 'Remito emitido' || r.estado === 'En proceso') && (
                        <button className="btn btn-xs btn-primary" onClick={() => openRetorno(r)} title="Registrar retorno">
                          <PackageCheck size={11} />
                        </button>
                      )}
                      {r.estado === 'Recibido' && (
                        <button className="btn btn-xs" onClick={() => completar(r.id)}>Completar</button>
                      )}
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={!!detalle} onClose={() => setDetalle(null)} title={detalle?.numero || 'Detalle OTT'}
        footer={<button className="btn" onClick={() => setDetalle(null)}>Cerrar</button>}
      >
        {detalle && (
          <DetailGrid
            obs={detalle.obs}
            items={[
              { label: 'OT origen', value: detalle.ot_numero || '—' },
              { label: 'Operación', value: `${detalle.op_orden || ''}. ${detalle.op_nombre || '—'}` },
              { label: 'Producto', value: `${detalle.producto_codigo || '—'} — ${detalle.producto_nombre || '—'}` },
              { label: 'Proveedor', value: detalle.proveedor_nombre || 'Sin asignar' },
              { label: 'Precio acordado', value: fmtMoney(detalle.precio_acordado) },
              { label: 'Nivel', value: detalle.es_ultimo_nivel ? 'Último (PT → cliente)' : 'Intermedio (semielaborado → OT)' },
              { label: 'Estado', value: detalle.estado },
              { label: 'Remito traslado', value: detalle.remito_numero || '—' },
              { label: 'Fecha envío', value: fmtDate(detalle.fecha_envio) },
              { label: 'Retorno estimado', value: fmtDate(detalle.fecha_retorno_est) },
              { label: 'Retorno real', value: fmtDate(detalle.fecha_retorno_real) },
            ]}
          />
        )}
      </Modal>

      <Modal open={!!showRetorno} onClose={() => setShowRetorno(null)} title="Registrar retorno de piezas"
        footer={<>
          <button className="btn" onClick={() => setShowRetorno(null)}>Cancelar</button>
          <button className="btn btn-primary" onClick={confirmarRetorno} disabled={saving}>
            {saving ? 'Guardando...' : 'Confirmar retorno'}
          </button>
        </>}
      >
        {showRetorno && (
          <>
            <div className={`alert-banner ${showRetorno.es_ultimo_nivel ? 'alert-success' : 'alert-warn'}`} style={{ marginBottom: 14 }}>
              {showRetorno.es_ultimo_nivel
                ? '✓ Último nivel: el lote quedará disponible para Remitir a cliente.'
                : '→ Paso intermedio: el lote quedará como semielaborado asignable a una OT.'}
            </div>
            <div className="form-grid">
              <Field label="Cantidad recibida" required span2>
                <input className="form-input" type="number" min="0.01" step="0.01" autoFocus {...retForm.bind('cantidad')} />
              </Field>
              <Field label="Observaciones" span2>
                <textarea className="form-textarea" {...retForm.bind('obs')} placeholder="Estado de las piezas, certificados, etc." />
              </Field>
            </div>
          </>
        )}
      </Modal>

      {/* Edit OTT modal */}
      <Modal open={!!editOTT} onClose={() => setEditOTT(null)}
        title={editOTT ? `Editar OTT: ${editOTT.numero}` : ''}
        footer={<>
          <button className="btn" onClick={() => setEditOTT(null)}>Cancelar</button>
          <button className="btn btn-primary" onClick={saveEdit}>Guardar cambios</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Proveedor" span2>
            <select className="form-select" {...editForm.bind('proveedor_id')}>
              <option value="">— Sin asignar —</option>
              {provs.map(p => <option key={p.id} value={p.id}>{p.razon}</option>)}
            </select>
          </Field>
          <Field label="Precio acordado">
            <input className="form-input" type="number" min="0" step="0.01" {...editForm.bind('precio_acordado')} />
          </Field>
          <Field label="Estado">
            <select className="form-select" {...editForm.bind('estado')}>
              {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </Field>
          <Field label="Fecha envío">
            <input className="form-input" type="date" {...editForm.bind('fecha_envio')} />
          </Field>
          <Field label="Fecha retorno estimada">
            <input className="form-input" type="date" {...editForm.bind('fecha_retorno_est')} />
          </Field>
          <Field label="Observaciones" span2>
            <textarea className="form-textarea" {...editForm.bind('obs')} />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
