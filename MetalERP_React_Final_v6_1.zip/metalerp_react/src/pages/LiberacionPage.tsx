import { CheckCircle, XCircle } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { PageLoading, EmptyState, Toolbar, Card, fmtDate } from '../components/ui'

interface Lote {
  id: number; numero: string; mat_codigo: string; mat_descripcion: string; mat_unidad: string
  cantidad_original: number; cantidad_disponible: number; cantidad_activa: number
  estado: string; proveedor_nombre: string | null
  referencia_proveedor: string | null; fecha_ingreso: string
}

export default function LiberacionPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<Lote>({
    path: '/lotes?estado=Ingresado',
    searchKeys: ['numero', 'mat_codigo', 'mat_descripcion'],
    errorMsg: 'Error cargando lotes',
  })

  async function liberar(lote: Lote) {
    const cantStr = window.prompt(`Cantidad a aprobar (disponible: ${lote.cantidad_disponible} ${lote.mat_unidad})`, String(lote.cantidad_disponible))
    if (!cantStr) return
    const cant = parseFloat(cantStr)
    if (isNaN(cant) || cant <= 0) { toast('Cantidad inválida', 'warn'); return }
    try {
      await api.put(`/lotes/${lote.id}`, { estado: 'Aprobado', cantidad_liberar: cant })
      toast(`Lote ${lote.numero} aprobado`); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function rechazar(lote: Lote) {
    if (!window.confirm(`¿Rechazar el lote ${lote.numero}?`)) return
    try {
      await api.put(`/lotes/${lote.id}`, { estado: 'Rechazado' })
      toast(`Lote ${lote.numero} rechazado`); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Liberación de lotes"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar lote..."
        onReload={reload}
        badge={filtered.length > 0
          ? <span className="counter-pill counter-pill-amber">
              {filtered.length} lote{filtered.length !== 1 ? 's' : ''} pendiente{filtered.length !== 1 ? 's' : ''}
            </span>
          : undefined
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin lotes pendientes" desc="Todos los lotes ingresados ya fueron liberados" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>N° Lote</th><th>Artículo</th><th>Total disp.</th>
                <th style={{ color: 'var(--c-green)' }}>✓ Aprobado</th>
                <th style={{ color: 'var(--c-text-3)' }}>⏳ Sin aprobar</th>
                <th>Proveedor / Ref.</th><th>Ingreso</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const sinApr = r.cantidad_disponible - r.cantidad_activa
                return (
                  <tr key={r.id}>
                    <td className="cell-mono">{r.numero}</td>
                    <td style={{ fontSize: 12 }}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                    <td style={{ fontSize: 12 }}>{r.cantidad_disponible} {r.mat_unidad}</td>
                    <td style={{ fontSize: 12, color: 'var(--c-green)', fontWeight: 600 }}>{r.cantidad_activa}</td>
                    <td style={{ fontSize: 12, color: sinApr > 0 ? 'var(--c-amber)' : 'var(--c-text-3)', fontWeight: sinApr > 0 ? 600 : 400 }}>
                      {sinApr.toFixed(3)}
                    </td>
                    <td style={{ fontSize: 12 }}>{r.proveedor_nombre || r.referencia_proveedor || '—'}</td>
                    <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_ingreso)}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button className="btn btn-xs btn-primary" style={{ background: 'var(--c-green)', borderColor: 'var(--c-green)' }} onClick={() => liberar(r)}>
                          <CheckCircle size={11} /> Aprobar
                        </button>
                        <button className="btn btn-xs btn-danger" onClick={() => rechazar(r)}>
                          <XCircle size={11} />
                        </button>
                      </div>
                    </td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>
    </div>
  )
}
