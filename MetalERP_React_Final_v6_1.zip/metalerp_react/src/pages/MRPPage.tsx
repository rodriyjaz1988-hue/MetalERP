import { useEffect, useState, useCallback } from 'react'
import { RefreshCw, Zap } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Badge, PageLoading, EmptyState, Card, fmtDate } from '../components/ui'

interface OCPend {
  id: number; numero: string; cliente_nombre: string
  fecha_entrega: string | null; estado: string
  items: { producto_codigo: string; producto_nombre: string; cantidad: number }[]
}

interface ConsolidarRes {
  ots?: { numero: string }[]
  solicitudes_compra?: any[]
}

export default function MRPPage() {
  const toast = useToast()
  const [ocs, setOcs] = useState<OCPend[]>([])
  const [loading, setLoading] = useState(true)
  const [selected, setSelected] = useState<Set<number>>(new Set())
  const [consolidando, setConsolidando] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const data = await api.get<{ oc_cliente_pendientes: OCPend[] }>('/mrp')
      setOcs(data.oc_cliente_pendientes || [])
    } catch { toast('Error cargando MRP', 'error') }
    finally { setLoading(false) }
  }, [toast])

  useEffect(() => { load() }, [load])

  const toggleAll = () => setSelected(prev =>
    prev.size === ocs.length ? new Set() : new Set(ocs.map(oc => oc.id))
  )
  const toggle = (id: number) => setSelected(prev => {
    const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n
  })

  async function consolidar() {
    if (!selected.size) { toast('Seleccioná al menos una OC', 'warn'); return }
    if (!window.confirm(`¿Consolidar y generar OTs para ${selected.size} pedido${selected.size !== 1 ? 's' : ''}?`)) return
    setConsolidando(true)
    try {
      const r = await api.post<ConsolidarRes>('/mrp/consolidar', { oc_ids: [...selected] })
      let msg = `OTs generadas: ${r.ots?.map(o => o.numero).join(', ') || '0'}`
      if (r.solicitudes_compra?.length) {
        msg += ` · ${r.solicitudes_compra.length} SC de compra generada${r.solicitudes_compra.length !== 1 ? 's' : ''}`
      }
      toast(msg)
      setSelected(new Set()); load()
    } catch (e: any) { toast(e.message, 'error') }
    finally { setConsolidando(false) }
  }

  return (
    <div className="page">
      <div className="toolbar">
        <h2 className="page-title" style={{ flex: 1 }}>Planificación MRP</h2>
        <button className="btn" onClick={load}><RefreshCw size={14} /></button>
        <button className="btn btn-primary" onClick={consolidar} disabled={!selected.size || consolidando}>
          <Zap size={14} />
          {consolidando ? 'Consolidando...' : `Consolidar y generar OTs${selected.size ? ` (${selected.size})` : ''}`}
        </button>
      </div>

      {loading ? <PageLoading /> : (
        <>
          <div className="alert-banner alert-info">
            <b>Cómo funciona:</b> Seleccioná los pedidos de clientes que querés planificar.
            El MRP genera OTs, OTTs para operaciones tercerizadas,
            y SCs de compra para materiales faltantes.
          </div>

          <Card padded={false}>
            {ocs.length === 0
              ? <EmptyState title="Sin pedidos pendientes" desc="No hay OCs con renglones sin OT asignada" />
              : (
                <div className="table-wrap"><table>
                  <thead><tr>
                    <th style={{ width: 40 }}>
                      <input type="checkbox" checked={selected.size === ocs.length && ocs.length > 0} onChange={toggleAll} />
                    </th>
                    <th>N° OC</th><th>Cliente</th><th>Artículos pendientes</th>
                    <th>F. entrega</th><th>Estado</th>
                  </tr></thead>
                  <tbody>{ocs.map(r => (
                    <tr key={r.id}
                      style={{ cursor: 'pointer', background: selected.has(r.id) ? 'var(--c-primary-lt)' : undefined }}
                      onClick={() => toggle(r.id)}
                    >
                      <td onClick={e => e.stopPropagation()}>
                        <input type="checkbox" checked={selected.has(r.id)} onChange={() => toggle(r.id)} />
                      </td>
                      <td className="cell-mono">{r.numero}</td>
                      <td style={{ fontSize: 13 }}>{r.cliente_nombre}</td>
                      <td className="cell-tight" style={{ color: 'var(--c-text-3)', maxWidth: 260 }}>
                        {r.items.map(i => `${i.producto_codigo} ×${i.cantidad}`).join(' · ')}
                      </td>
                      <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_entrega)}</td>
                      <td><Badge value={r.estado} /></td>
                    </tr>
                  ))}</tbody>
                </table></div>
              )}
          </Card>
        </>
      )}
    </div>
  )
}
