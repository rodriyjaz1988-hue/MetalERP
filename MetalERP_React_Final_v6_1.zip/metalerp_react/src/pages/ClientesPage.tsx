import { useState } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field } from '../components/ui'
import type { BadgeVariant } from '../components/ui'

interface Cliente {
  id: number; razon: string; cuit: string | null; iva: string | null
  rubro: string | null; localidad: string | null; direccion: string | null
  contacto: string | null; cargo: string | null; telefono: string | null
  email: string | null; categoria: string; plazo_pago: string | null; obs: string | null
}

const CATS = ['Regular', 'Premium', 'Ocasional', 'Potencial']
const IVA_CONDS = ['Responsable Inscripto', 'Monotributista', 'Exento', 'Consumidor Final']
const CAT_VARIANTS: Record<string, BadgeVariant> = {
  Premium: 'teal', Regular: 'blue', Ocasional: 'gray', Potencial: 'purple',
}

const EMPTY = {
  razon: '', cuit: '', iva: 'Responsable Inscripto', rubro: '', localidad: '', direccion: '',
  contacto: '', cargo: '', telefono: '', email: '', categoria: 'Regular', plazo_pago: '', obs: '',
}

export default function ClientesPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<Cliente>({
    path: '/clientes',
    searchKeys: ['razon', 'cuit', 'contacto'],
    errorMsg: 'Error cargando clientes',
  })
  const [editing, setEditing] = useState<Cliente | null>(null)
  const [open, setOpen] = useState(false)
  const { values, bind, reset } = useForm(EMPTY)

  function openNew() {
    setEditing(null); reset(EMPTY); setOpen(true)
  }

  function openEdit(c: Cliente) {
    setEditing(c)
    reset({
      razon: c.razon, cuit: c.cuit || '', iva: c.iva || 'Responsable Inscripto',
      rubro: c.rubro || '', localidad: c.localidad || '', direccion: c.direccion || '',
      contacto: c.contacto || '', cargo: c.cargo || '', telefono: c.telefono || '',
      email: c.email || '', categoria: c.categoria, plazo_pago: c.plazo_pago || '', obs: c.obs || '',
    })
    setOpen(true)
  }

  async function save() {
    if (!values.razon) { toast('Razón social requerida', 'warn'); return }
    try {
      editing
        ? await api.put(`/clientes/${editing.id}`, values)
        : await api.post('/clientes', values)
      toast(editing ? 'Cliente actualizado' : 'Cliente registrado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Clientes"
        search={search} onSearch={setSearch}
        searchPlaceholder="Buscar por razón, CUIT..."
        onReload={reload}
        primaryLabel="Nuevo cliente" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin clientes" desc="Registrá el primer cliente" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Razón social</th><th>CUIT</th><th>Contacto</th>
                <th>Teléfono</th><th>Email</th><th>Categoría</th><th>Plazo pago</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td><b style={{ fontSize: 13 }}>{r.razon}</b></td>
                  <td className="cell-mono">{r.cuit || '—'}</td>
                  <td className="cell-tight">
                    {r.contacto || '—'}
                    {r.cargo && <div style={{ fontSize: 10, color: 'var(--c-text-3)' }}>{r.cargo}</div>}
                  </td>
                  <td className="cell-tight">{r.telefono || '—'}</td>
                  <td className="cell-tight">{r.email || '—'}</td>
                  <td><Badge value={r.categoria} variant={CAT_VARIANTS[r.categoria]} /></td>
                  <td className="cell-tight">{r.plazo_pago || '—'}</td>
                  <td><button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button></td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar: ${editing.razon}` : 'Nuevo cliente'} size="lg"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Razón social" required span2>
            <input className="form-input" {...bind('razon')} placeholder="Empresa SA" />
          </Field>
          <Field label="CUIT"><input className="form-input" {...bind('cuit')} placeholder="20-12345678-9" /></Field>
          <Field label="Cond. IVA">
            <select className="form-select" {...bind('iva')}>
              {IVA_CONDS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Contacto"><input className="form-input" {...bind('contacto')} /></Field>
          <Field label="Cargo"><input className="form-input" {...bind('cargo')} /></Field>
          <Field label="Teléfono"><input className="form-input" {...bind('telefono')} /></Field>
          <Field label="Email"><input className="form-input" type="email" {...bind('email')} /></Field>
          <Field label="Categoría">
            <select className="form-select" {...bind('categoria')}>
              {CATS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Plazo de pago"><input className="form-input" {...bind('plazo_pago')} placeholder="30 días, contado..." /></Field>
          <Field label="Observaciones" span2>
            <textarea className="form-textarea" {...bind('obs')} />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
