import { useState } from 'react'
import { ChevronRight } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import {
  Badge, PageLoading, EmptyState, Toolbar, Card, ProgressBar, fmtDate,
} from '../components/ui'

interface OT {
  id: number; numero: string; descripcion: string
  producto_codigo: string | null; producto_nombre: string | null
  cliente_nombre: string | null; cantidad: number
  estado: string; prioridad: number; fecha_entrega: string | null
  costo_mat: number; costo_mo: number
}

interface OpOT {
  id: number; orden: number; nombre: string
  estado: string; tiempo_setup_min: number; tiempo_ciclo_min: number
  empleado_nombre: string | null; maquina_nombre: string | null
  fecha_inicio: string | null; fecha_fin: string | null
}

interface MatOT {
  id: number; codigo: string; descripcion: string
  cantidad_requerida: number; cantidad_asignada: number; unidad: string
}

const ESTADOS_OP = ['Pendiente', 'En proceso', 'Pausada', 'Completada']
const FILTROS = ['Pendiente', 'En proceso', 'Completada']

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div style={{
      fontSize: 12, fontWeight: 600, color: 'var(--c-text-3)',
      textTransform: 'uppercase', letterSpacing: '.4px', marginBottom: 8,
    }}>
      {children}
    </div>
  )
}

export default function CtrlProdPage() {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('En proceso')
  const { loading, search, setSearch, reload, filtered } = useResource<OT>({
    path: estFilter ? `/ordenes?estado=${estFilter}` : '/ordenes',
    searchKeys: ['numero', 'descripcion', 'producto_nombre'],
    errorMsg: 'Error cargando OTs',
  })
  const [selected, setSelected] = useState<OT | null>(null)
  const [ops, setOps] = useState<OpOT[]>([])
  const [mats, setMats] = useState<MatOT[]>([])
  const [loadingDet, setLoadingDet] = useState(false)

  async function selectOT(ot: OT) {
    setSelected(ot); setLoadingDet(true)
    try {
      const [o, m] = await Promise.all([
        api.get<OpOT[]>(`/ordenes/${ot.id}/operaciones`),
        api.get<MatOT[]>(`/ordenes/${ot.id}/materiales`),
      ])
      setOps(o); setMats(m)
    } catch { toast('Error cargando detalle', 'error') }
    finally { setLoadingDet(false) }
  }

  async function cambiarEstadoOp(op: OpOT, nuevo: string) {
    if (!selected) return
    try {
      await api.put(`/ordenes/${selected.id}/operaciones/${op.id}`, { estado: nuevo })
      toast(`Operación ${nuevo.toLowerCase()}`)
      selectOT(selected)
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Control de producción"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar OT..."
        onReload={reload}
        rightChildren={
          <select className="form-select" style={{ width: 160 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
            <option value="">Todos los estados</option>
            {FILTROS.map(s => <option key={s} value={s}>{s}</option>)}
          </select>
        }
      />

      <div style={{ display: 'grid', gridTemplateColumns: selected ? '380px 1fr' : '1fr', gap: 16, minHeight: 400 }}>
        {/* OT list */}
        <Card padded={false}>
          <div style={{ maxHeight: 600, overflowY: 'auto' }}>
            {loading ? <PageLoading /> : filtered.length === 0
              ? <EmptyState title="Sin OTs" desc="No hay órdenes con este filtro" />
              : filtered.map(o => {
                  const isActive = selected?.id === o.id
                  return (
                    <div key={o.id} onClick={() => selectOT(o)} style={{
                      padding: '12px 14px', borderBottom: '1px solid var(--c-border)',
                      cursor: 'pointer',
                      background: isActive ? 'var(--c-primary)' : undefined,
                      color: isActive ? '#fff' : undefined,
                    }}>
                      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
                        <b style={{ fontSize: 13, fontFamily: 'monospace' }}>{o.numero}</b>
                        <ChevronRight size={14} style={{ opacity: isActive ? 1 : .3 }} />
                      </div>
                      <div style={{ fontSize: 12, marginBottom: 4 }}>{o.producto_nombre || o.descripcion}</div>
                      <div style={{ fontSize: 11, opacity: isActive ? .9 : .7 }}>
                        {o.cantidad} unid · {o.cliente_nombre || 'sin cliente'}
                      </div>
                    </div>
                  )
                })}
          </div>
        </Card>

        {/* OT detail */}
        {selected && (
          <Card>
            {loadingDet ? <PageLoading /> : (
              <>
                {/* Header */}
                <div style={{
                  display: 'flex', alignItems: 'center', justifyContent: 'space-between',
                  marginBottom: 14, paddingBottom: 12, borderBottom: '1px solid var(--c-border)',
                }}>
                  <div>
                    <div style={{ fontSize: 16, fontWeight: 700 }}>{selected.numero}</div>
                    <div style={{ fontSize: 13, color: 'var(--c-text-2)' }}>
                      {selected.producto_codigo} — {selected.producto_nombre}
                    </div>
                  </div>
                  <Badge value={selected.estado} />
                </div>

                <div className="kv-grid kv-grid-3" style={{ marginBottom: 16 }}>
                  {[
                    { label: 'Cliente', value: selected.cliente_nombre || '—' },
                    { label: 'Cantidad', value: `${selected.cantidad} unid` },
                    { label: 'Entrega', value: fmtDate(selected.fecha_entrega) },
                  ].map(({ label, value }) => (
                    <div key={label} className="kv-cell">
                      <div className="kv-label">{label}</div>
                      <div className="kv-value" style={{ fontSize: 13 }}>{value}</div>
                    </div>
                  ))}
                </div>

                {/* Operations */}
                <SectionLabel>Operaciones</SectionLabel>
                {ops.length === 0 ? <EmptyState title="Sin operaciones" /> : (
                  <table>
                    <thead><tr><th>#</th><th>Operación</th><th>Recurso</th><th>Estado</th><th></th></tr></thead>
                    <tbody>{ops.map(op => (
                      <tr key={op.id}>
                        <td style={{ textAlign: 'center', fontSize: 12 }}>{op.orden}</td>
                        <td style={{ fontSize: 13 }}>
                          <b>{op.nombre}</b>
                          <div style={{ fontSize: 10, color: 'var(--c-text-3)' }}>
                            Setup: {op.tiempo_setup_min}min · Ciclo: {Math.round(op.tiempo_ciclo_min * 60)}seg
                          </div>
                        </td>
                        <td style={{ fontSize: 11 }}>
                          {op.maquina_nombre && <div>🔧 {op.maquina_nombre}</div>}
                          {op.empleado_nombre && <div>👤 {op.empleado_nombre}</div>}
                          {!op.maquina_nombre && !op.empleado_nombre && '—'}
                        </td>
                        <td><Badge value={op.estado} /></td>
                        <td>
                          <select className="form-select" style={{ fontSize: 11, padding: '3px 6px', width: 130 }}
                            value={op.estado} onChange={e => cambiarEstadoOp(op, e.target.value)}>
                            {ESTADOS_OP.map(s => <option key={s} value={s}>{s}</option>)}
                          </select>
                        </td>
                      </tr>
                    ))}</tbody>
                  </table>
                )}

                {/* Materials */}
                {mats.length > 0 && (
                  <div style={{ marginTop: 16 }}>
                    <SectionLabel>Materiales</SectionLabel>
                    <table>
                      <thead><tr><th>Material</th><th>Requerido</th><th>Asignado</th><th>Cobertura</th></tr></thead>
                      <tbody>{mats.map(m => {
                        const cov = m.cantidad_requerida > 0
                          ? Math.round(m.cantidad_asignada / m.cantidad_requerida * 100) : 0
                        return (
                          <tr key={m.id}>
                            <td style={{ fontSize: 12 }}><b>{m.codigo}</b> {m.descripcion}</td>
                            <td style={{ fontSize: 12 }}>{m.cantidad_requerida} {m.unidad}</td>
                            <td style={{ fontSize: 12 }}>{m.cantidad_asignada}</td>
                            <td>
                              <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 100 }}>
                                <ProgressBar value={cov} color={cov >= 100 ? 'var(--c-green)' : 'var(--c-amber)'} />
                                <span style={{ fontSize: 11, fontWeight: 600 }}>{cov}%</span>
                              </div>
                            </td>
                          </tr>
                        )
                      })}</tbody>
                    </table>
                  </div>
                )}
              </>
            )}
          </Card>
        )}
      </div>
    </div>
  )
}
