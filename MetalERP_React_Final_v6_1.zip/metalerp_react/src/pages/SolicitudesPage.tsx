import { useState, useEffect, Fragment } from 'react'
import { ChevronDown, ChevronRight } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, fmtMoney } from '../components/ui'
import type { BadgeVariant } from '../components/ui'

interface SC {
  id: number; numero: string; tipo: string; descripcion: string
  material_id: number | null; mat_nombre: string | null; mat_unidad: string | null
  cantidad: number; unidad: string; urgencia: string; estado: string
  ot_numero: string | null; obs: string | null; creado: string
}
interface Cot {
  id: number; solicitud_id: number; proveedor_nombre: string
  precio_unit: number; plazo_entrega_dias: number | null
  condicion_pago: string | null; seleccionada: number
}

interface Material { id: number; codigo: string; descripcion: string; unidad: string }
interface Proveedor { id: number; razon: string }

const URGENCIAS = ['Normal', 'Alta', 'Crítica']
const URG_VARIANT: Record<string, BadgeVariant> = { Crítica: 'red', Alta: 'amber', Normal: 'blue' }

export default function SolicitudesPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<SC>({
    path: '/solicitudes_compra',
    searchKeys: ['numero', 'descripcion'],
    errorMsg: 'Error cargando solicitudes',
  })
  const [cots, setCots] = useState<Record<number, Cot[]>>({})
  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [mats, setMats] = useState<Material[]>([])
  const [provs, setProvs] = useState<Proveedor[]>([])
  const [openSC, setOpenSC] = useState(false)
  const [openCot, setOpenCot] = useState<SC | null>(null)
  const scForm = useForm({ tipo: 'Productiva', descripcion: '', material_id: '', cantidad: '', unidad: 'kg', urgencia: 'Normal', obs: '' })
  const cotForm = useForm({ proveedor_id: '', precio_unit: '', plazo_entrega_dias: '3', condicion_pago: '', obs: '' })

  useEffect(() => {
    api.get<Cot[]>('/cotizaciones_compra').then(all => {
      const grouped: Record<number, Cot[]> = {}
      all.forEach(c => { (grouped[c.solicitud_id] ||= []).push(c) })
      setCots(grouped)
    }).catch(() => {})
  }, [filtered])

  const toggle = (id: number) =>
    setExpanded(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n })

  async function openSCNew() {
    if (!mats.length) setMats(await api.get<Material[]>('/materiales'))
    scForm.reset({ tipo: 'Productiva', descripcion: '', material_id: '', cantidad: '', unidad: 'kg', urgencia: 'Normal', obs: '' })
    setOpenSC(true)
  }

  async function openCotForSC(sc: SC) {
    if (!provs.length) setProvs(await api.get<Proveedor[]>('/proveedores'))
    cotForm.reset({ proveedor_id: '', precio_unit: '', plazo_entrega_dias: '3', condicion_pago: '', obs: '' })
    setOpenCot(sc)
  }

  async function saveSC() {
    if (!scForm.values.descripcion || !scForm.values.cantidad) { toast('Descripción y cantidad requeridas', 'warn'); return }
    const body = { ...scForm.values, cantidad: Number(scForm.values.cantidad), material_id: scForm.values.material_id ? Number(scForm.values.material_id) : null }
    try { await api.post('/solicitudes_compra', body); toast('Solicitud creada'); setOpenSC(false); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  async function saveCot() {
    if (!openCot || !cotForm.values.proveedor_id || !cotForm.values.precio_unit) { toast('Proveedor y precio requeridos', 'warn'); return }
    const body = {
      solicitud_id: openCot.id, ...cotForm.values,
      precio_unit: Number(cotForm.values.precio_unit),
      plazo_entrega_dias: Number(cotForm.values.plazo_entrega_dias),
    }
    try { await api.post('/cotizaciones_compra', body); toast('Cotización cargada'); setOpenCot(null); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  async function selCot(id: number) {
    try { await api.post(`/cotizaciones_compra/${id}/seleccionar`, {}); toast('Cotización seleccionada'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Solicitudes de compra"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar SC..."
        onReload={reload} primaryLabel="Nueva SC" onPrimary={openSCNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin solicitudes" desc="Creá la primera solicitud de compra" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th style={{ width: 36 }}></th>
                <th>N°</th><th>Tipo</th><th>Descripción / Material</th>
                <th>Cantidad</th><th>Urgencia</th><th>Estado</th><th>Mejor precio</th><th></th>
              </tr></thead>
              <tbody>
                {filtered.map(r => {
                  const rcots = cots[r.id] || []
                  const minCot = rcots.length ? rcots.reduce((a, b) => a.precio_unit < b.precio_unit ? a : b) : null
                  const isExp = expanded.has(r.id)
                  return (
                    <Fragment key={r.id}>
                      <tr>
                        <td>
                          <button style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--c-text-3)' }} onClick={() => toggle(r.id)}>
                            {isExp ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                          </button>
                        </td>
                        <td className="cell-mono">{r.numero}</td>
                        <td><Badge value={r.tipo} variant={r.tipo === 'Productiva' ? 'blue' : 'purple'} /></td>
                        <td style={{ fontSize: 12 }}>
                          {r.descripcion}
                          {r.mat_nombre && <div style={{ fontSize: 10, color: 'var(--c-text-3)' }}>{r.mat_nombre}</div>}
                        </td>
                        <td style={{ fontSize: 12 }}>{r.cantidad} {r.mat_unidad || r.unidad}</td>
                        <td><Badge value={r.urgencia} variant={URG_VARIANT[r.urgencia]} /></td>
                        <td><Badge value={r.estado} /></td>
                        <td style={{ fontSize: 12 }}>
                          {minCot
                            ? <><b style={{ color: 'var(--c-green)' }}>{fmtMoney(minCot.precio_unit)}</b> <span style={{ color: 'var(--c-text-3)' }}>{minCot.proveedor_nombre}</span></>
                            : <span style={{ color: 'var(--c-text-3)' }}>—</span>}
                        </td>
                        <td><button className="btn btn-xs btn-primary" onClick={() => openCotForSC(r)}>+ Cot.</button></td>
                      </tr>
                      {isExp && (
                        <tr>
                          <td colSpan={9} style={{ padding: 0 }}>
                            <div style={{ padding: '8px 12px 12px 48px', background: 'var(--c-bg)', borderBottom: '1px solid var(--c-border)' }}>
                              {!rcots.length
                                ? <p style={{ fontSize: 12, color: 'var(--c-text-3)' }}>Sin cotizaciones. Usá "+ Cot." para agregar.</p>
                                : (() => {
                                    const minP = Math.min(...rcots.map(c => c.precio_unit))
                                    return (
                                      <table style={{ fontSize: 11 }}>
                                        <thead><tr><th>Proveedor</th><th>Precio unit.</th><th>Plazo</th><th>Condición</th><th>Total</th><th></th></tr></thead>
                                        <tbody>{rcots.map(c => (
                                          <tr key={c.id} style={{ background: c.precio_unit === minP ? '#EAF3DE' : undefined }}>
                                            <td>{c.proveedor_nombre}</td>
                                            <td style={{ fontWeight: c.precio_unit === minP ? 700 : 400 }}>
                                              {fmtMoney(c.precio_unit)}
                                              {c.precio_unit === minP && <Badge value="✓ Mejor" variant="green" />}
                                            </td>
                                            <td>{c.plazo_entrega_dias || '—'}d</td>
                                            <td>{c.condicion_pago || '—'}</td>
                                            <td>{fmtMoney(c.precio_unit * r.cantidad)}</td>
                                            <td>{c.seleccionada
                                              ? <Badge value="✓ Seleccionada" variant="green" />
                                              : <button className="btn btn-xs btn-primary" onClick={() => selCot(c.id)}>Seleccionar</button>}
                                            </td>
                                          </tr>
                                        ))}</tbody>
                                      </table>
                                    )
                                  })()
                              }
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  )
                })}
              </tbody>
            </table></div>
          )}
      </Card>

      <Modal open={openSC} onClose={() => setOpenSC(false)} title="Nueva solicitud de compra"
        footer={<>
          <button className="btn" onClick={() => setOpenSC(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={saveSC}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Tipo">
            <select className="form-select" {...scForm.bind('tipo')}>
              <option>Productiva</option><option>Indirecta</option><option>Servicio</option>
            </select>
          </Field>
          <Field label="Urgencia">
            <select className="form-select" {...scForm.bind('urgencia')}>
              {URGENCIAS.map(u => <option key={u} value={u}>{u}</option>)}
            </select>
          </Field>
          {scForm.values.tipo === 'Productiva' && (
            <Field label="Material" span2>
              <select className="form-select" value={scForm.values.material_id} onChange={e => {
                const m = mats.find(x => String(x.id) === e.target.value)
                scForm.setValues(v => ({ ...v, material_id: e.target.value, descripcion: m?.descripcion || v.descripcion, unidad: m?.unidad || v.unidad }))
              }}>
                <option value="">— Seleccionar material —</option>
                {mats.map(m => <option key={m.id} value={m.id}>{m.codigo} — {m.descripcion}</option>)}
              </select>
            </Field>
          )}
          <Field label="Descripción" required span2>
            <input className="form-input" {...scForm.bind('descripcion')} />
          </Field>
          <Field label="Cantidad" required><input className="form-input" type="number" min="0.01" step="0.01" {...scForm.bind('cantidad')} /></Field>
          <Field label="Unidad"><input className="form-input" {...scForm.bind('unidad')} /></Field>
        </div>
      </Modal>

      <Modal open={!!openCot} onClose={() => setOpenCot(null)} title={`Cotización para: ${openCot?.numero}`}
        footer={<>
          <button className="btn" onClick={() => setOpenCot(null)}>Cancelar</button>
          <button className="btn btn-primary" onClick={saveCot}>Guardar cotización</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Proveedor" required span2>
            <select className="form-select" {...cotForm.bind('proveedor_id')}>
              <option value="">— Seleccionar proveedor —</option>
              {provs.map(p => <option key={p.id} value={p.id}>{p.razon}</option>)}
            </select>
          </Field>
          <Field label="Precio unitario" required><input className="form-input" type="number" min="0" step="0.01" {...cotForm.bind('precio_unit')} /></Field>
          <Field label="Plazo (días)"><input className="form-input" type="number" min="0" {...cotForm.bind('plazo_entrega_dias')} /></Field>
          <Field label="Condición de pago" span2>
            <input className="form-input" {...cotForm.bind('condicion_pago')} placeholder="Contado, 30 días..." />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
