import { useState, useEffect } from 'react'
import { Pencil, Trash2 } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import {
  Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, ProgressBar,
  fmtDate, rendimientoColor,
} from '../components/ui'

interface Novedad {
  id: number
  orden_id: number; ot_numero: string
  orden_operacion_id: number; operacion_nombre: string | null; op_orden: number | null
  empleado_id: number | null; empleado_nombre: string | null
  producto_nombre: string | null
  cantidad_producida: number
  tiempo_real_min: number
  rendimiento_pct: number; desvio: number
  turno: string | null; obs: string | null; creado: string
}

interface OT { id: number; numero: string; descripcion: string }
interface OpOT { id: number; orden: number; nombre: string }
interface Empleado { id: number; nombre: string }

const TURNOS = ['Mañana', 'Tarde', 'Noche']
const EMPTY = { orden_id: '', orden_operacion_id: '', empleado_id: '',
                cantidad_producida: '', tiempo_real_min: '', turno: '', obs: '' }

export default function NovedadesPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<Novedad>({
    path: '/novedades',
    searchKeys: ['ot_numero', 'empleado_nombre', 'operacion_nombre'],
    errorMsg: 'Error cargando novedades',
  })
  const [ots, setOts] = useState<OT[]>([])
  const [emps, setEmps] = useState<Empleado[]>([])
  const [ops, setOps] = useState<OpOT[]>([])
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Novedad | null>(null)
  const [saving, setSaving] = useState(false)
  const { values, bind, reset, setValues } = useForm(EMPTY)

  useEffect(() => {
    Promise.all([api.get<OT[]>('/ordenes?estado=En proceso'), api.get<Empleado[]>('/empleados')])
      .then(([o, e]) => { setOts(o); setEmps(e) })
      .catch(() => {})
  }, [])

  function openNew() {
    setEditing(null); reset(EMPTY); setOps([]); setOpen(true)
  }

  async function openEdit(n: Novedad) {
    setEditing(n)
    reset({
      orden_id: String(n.orden_id),
      orden_operacion_id: String(n.orden_operacion_id),
      empleado_id: String(n.empleado_id ?? ''),
      cantidad_producida: String(n.cantidad_producida),
      tiempo_real_min: String(n.tiempo_real_min),
      turno: n.turno || '',
      obs: n.obs || '',
    })
    setOps(await api.get<OpOT[]>(`/ordenes/${n.orden_id}/operaciones`))
    setOpen(true)
  }

  async function del(n: Novedad) {
    if (!window.confirm(`¿Borrar esta novedad de ${n.ot_numero}? Se revertirán los consumos de stock asociados.`)) return
    try { await api.delete(`/novedades/${n.id}`); toast('Novedad eliminada'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  async function loadOps(otId: string) {
    setValues(v => ({ ...v, orden_id: otId, orden_operacion_id: '' }))
    setOps(otId ? await api.get<OpOT[]>(`/ordenes/${otId}/operaciones`) : [])
  }

  async function save() {
    if (!values.orden_id || !values.orden_operacion_id) {
      toast('OT y operación requeridas', 'warn'); return
    }
    const qty = Number(values.cantidad_producida)
    const t = Number(values.tiempo_real_min)
    if (qty <= 0 || t <= 0) { toast('Cantidad y tiempo deben ser mayores a 0', 'warn'); return }

    setSaving(true)
    try {
      if (editing) {
        await api.put(`/novedades/${editing.id}`, {
          cantidad_producida: qty, tiempo_real_min: t,
          empleado_id: values.empleado_id ? Number(values.empleado_id) : null,
          turno: values.turno || null, obs: values.obs || null,
        })
        toast('Novedad actualizada')
      } else {
        const r = await api.post<{ numero: string; rendimiento_pct: number }>('/novedades', {
          orden_id: Number(values.orden_id),
          orden_operacion_id: Number(values.orden_operacion_id),
          empleado_id: values.empleado_id ? Number(values.empleado_id) : null,
          cantidad_producida: qty, tiempo_real_min: t,
          turno: values.turno || null, obs: values.obs || null,
        })
        toast(`Novedad ${r.numero} — Rendimiento: ${r.rendimiento_pct}%`)
      }
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
    finally { setSaving(false) }
  }

  return (
    <div className="page">
      <Toolbar
        title="Novedades por OT"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar OT, empleado, operación..."
        onReload={reload} primaryLabel="Nueva novedad" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin novedades" desc="Registrá la primera novedad de producción para calcular rendimientos" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Fecha</th><th>OT</th><th>Operación</th><th>Empleado</th>
                <th>Producido</th><th>Tiempo (min)</th>
                <th style={{ minWidth: 140 }}>Rendimiento</th>
                <th>Observaciones</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const color = rendimientoColor(r.rendimiento_pct)
                return (
                  <tr key={r.id}>
                    <td style={{ fontSize: 12 }}>{fmtDate(r.creado)}</td>
                    <td className="cell-mono">{r.ot_numero}</td>
                    <td style={{ fontSize: 12 }}>
                      {r.op_orden ? `${r.op_orden}. ` : ''}{r.operacion_nombre || '—'}
                    </td>
                    <td style={{ fontSize: 12 }}>{r.empleado_nombre || '—'}</td>
                    <td className="cell-num">{r.cantidad_producida}</td>
                    <td className="cell-num">{r.tiempo_real_min}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <ProgressBar value={r.rendimiento_pct} color={color} />
                        <span style={{ fontSize: 11, fontWeight: 700, color, minWidth: 36 }}>
                          {r.rendimiento_pct}%
                        </span>
                      </div>
                      {r.desvio === 1 && <Badge value="Bajo std" variant="red" />}
                    </td>
                    <td className="cell-tight">{r.obs || '—'}</td>
                    <td>
                      <div style={{ display: 'flex', gap: 4 }}>
                        <button className="btn btn-xs" onClick={() => openEdit(r)} title="Editar"><Pencil size={11} /></button>
                        <button className="btn btn-xs btn-danger" onClick={() => del(r)} title="Borrar"><Trash2 size={11} /></button>
                      </div>
                    </td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar novedad — ${editing.ot_numero}` : 'Registrar novedad de producción'} size="lg"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save} disabled={saving}>
            {saving ? 'Guardando...' : editing ? 'Guardar cambios' : 'Registrar'}
          </button>
        </>}
      >
        <div className="alert-banner alert-info mb-4">
          El <b>rendimiento</b> se calcula automáticamente comparando cantidad producida
          y tiempo real contra el ciclo estándar de la operación.
          {editing && ' Al editar, se ajustan los consumos de stock por diferencia.'}
        </div>
        <div className="form-grid">
          <Field label="OT" required>
            <select className="form-select" value={values.orden_id} onChange={e => loadOps(e.target.value)} disabled={!!editing}>
              <option value="">— Seleccionar OT —</option>
              {ots.map(o => <option key={o.id} value={o.id}>{o.numero} — {o.descripcion}</option>)}
            </select>
          </Field>
          <Field label="Operación" required>
            <select className="form-select" {...bind('orden_operacion_id')} disabled={!ops.length || !!editing}>
              <option value="">— Seleccionar operación —</option>
              {ops.map(op => <option key={op.id} value={op.id}>{op.orden}. {op.nombre}</option>)}
            </select>
          </Field>
          <Field label="Empleado">
            <select className="form-select" {...bind('empleado_id')}>
              <option value="">— Sin empleado —</option>
              {emps.map(e => <option key={e.id} value={e.id}>{e.nombre}</option>)}
            </select>
          </Field>
          <Field label="Turno">
            <select className="form-select" {...bind('turno')}>
              <option value="">— Sin turno —</option>
              {TURNOS.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Cantidad producida" required>
            <input className="form-input" type="number" min="0.01" step="0.01" {...bind('cantidad_producida')} />
          </Field>
          <Field label="Tiempo real (min)" required>
            <input className="form-input" type="number" min="0.1" step="0.1" {...bind('tiempo_real_min')} />
          </Field>
          <Field label="Observaciones" span2>
            <textarea className="form-textarea" {...bind('obs')} />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
