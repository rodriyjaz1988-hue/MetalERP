import { useResource } from '../hooks/useResource'
import { PageLoading, EmptyState, Toolbar, Card, ProgressBar, rendimientoColor } from '../components/ui'

interface RendOp {
  empleado_id: number; empleado_nombre: string; tipo: string
  total_novedades: number; avg_rend: number
  total_producido: number; total_horas: number
}

export default function RendimientoPage() {
  const { loading, reload, rows } = useResource<RendOp>({
    path: '/rendimiento_operarios', errorMsg: 'Error cargando rendimiento',
  })

  const sorted = [...rows].sort((a, b) => b.avg_rend - a.avg_rend)

  return (
    <div className="page">
      <Toolbar title="Rendimiento de operarios" onReload={reload} />

      <Card padded={false}>
        {loading ? <PageLoading /> : sorted.length === 0
          ? <EmptyState title="Sin datos de rendimiento" desc="Aún no hay novedades de producción con cantidad y tiempo registrados" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>#</th><th>Empleado</th><th>Tipo</th>
                <th style={{ minWidth: 200 }}>Rendimiento promedio</th>
                <th>Novedades</th><th>Total producido</th><th>Horas trabajadas</th>
              </tr></thead>
              <tbody>{sorted.map((r, i) => {
                const color = rendimientoColor(r.avg_rend)
                return (
                  <tr key={r.empleado_id}>
                    <td style={{ fontSize: 13, textAlign: 'center', color: 'var(--c-text-3)' }}>{i + 1}</td>
                    <td style={{ fontSize: 13, fontWeight: 600 }}>{r.empleado_nombre}</td>
                    <td style={{ fontSize: 12, color: 'var(--c-text-3)' }}>{r.tipo}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <ProgressBar value={r.avg_rend || 0} color={color} />
                        <span style={{ fontSize: 12, fontWeight: 600, color, minWidth: 40 }}>
                          {r.avg_rend || 0}%
                        </span>
                      </div>
                    </td>
                    <td style={{ fontSize: 12, textAlign: 'center' }}>{r.total_novedades}</td>
                    <td className="cell-num">{r.total_producido}</td>
                    <td className="cell-num">{r.total_horas ? `${r.total_horas} hs` : '—'}</td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>
    </div>
  )
}
