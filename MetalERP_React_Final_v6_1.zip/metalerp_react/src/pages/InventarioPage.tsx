import { useState } from 'react'
import { AlertTriangle } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, PageLoading, EmptyState, Toolbar, Card, Field, fmtMoney } from '../components/ui'

interface Material {
  id: number; codigo: string; descripcion: string; categoria: string
  unidad: string; stock: number; stock_min: number; precio_unit: number
}

const CATS = ['Material', 'Herramienta', 'Consumible', 'Producto terminado', 'Semielaborado']
const EMPTY = { codigo: '', descripcion: '', categoria: 'Material', unidad: 'kg',
                stock: '0', stock_min: '0', precio_unit: '0', obs: '' }

export default function InventarioPage() {
  const toast = useToast()
  const [catFilter, setCatFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<Material>({
    path: '/materiales',
    searchKeys: ['codigo', 'descripcion'],
    filter: r => !catFilter || r.categoria === catFilter,
    errorMsg: 'Error cargando materiales',
  })
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Material | null>(null)
  const { values, bind, reset } = useForm(EMPTY)

  function openNew() { setEditing(null); reset(EMPTY); setOpen(true) }
  function openEdit(m: Material) {
    setEditing(m)
    reset({ codigo: m.codigo, descripcion: m.descripcion, categoria: m.categoria, unidad: m.unidad,
            stock: String(m.stock), stock_min: String(m.stock_min), precio_unit: String(m.precio_unit), obs: '' })
    setOpen(true)
  }

  async function save() {
    if (!values.codigo || !values.descripcion) { toast('Código y descripción requeridos', 'warn'); return }
    const body = { ...values, stock: Number(values.stock), stock_min: Number(values.stock_min), precio_unit: Number(values.precio_unit) }
    try {
      editing ? await api.put(`/materiales/${editing.id}`, body) : await api.post('/materiales', body)
      toast(editing ? 'Material actualizado' : 'Material creado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const criticos = filtered.filter(r => r.stock <= r.stock_min && r.stock_min > 0).length

  return (
    <div className="page">
      <Toolbar
        title="Inventario de materiales"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar material..."
        onReload={reload} primaryLabel="Nuevo material" onPrimary={openNew}
        badge={criticos > 0
          ? <span className="counter-pill counter-pill-red">
              <AlertTriangle size={14} /> {criticos} bajo stock mínimo
            </span>
          : undefined
        }
        rightChildren={
          <select className="form-select" style={{ width: 170 }} value={catFilter} onChange={e => setCatFilter(e.target.value)}>
            <option value="">Todas las categorías</option>
            {CATS.map(c => <option key={c} value={c}>{c}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin materiales" desc="Agregá materiales al inventario" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Código</th><th>Descripción</th><th>Categoría</th>
                <th>Stock</th><th>Stock mín.</th><th>Unidad</th><th>Precio unit.</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const critico = r.stock <= r.stock_min && r.stock_min > 0
                return (
                  <tr key={r.id}>
                    <td className="cell-mono">{r.codigo}</td>
                    <td style={{ fontSize: 13 }}>{r.descripcion}</td>
                    <td><span className="badge badge-gray" style={{ fontSize: 10 }}>{r.categoria}</span></td>
                    <td style={{ fontWeight: critico ? 700 : 400, color: critico ? 'var(--c-red)' : undefined }}>
                      {r.stock} {critico && <AlertTriangle size={11} style={{ marginLeft: 4, verticalAlign: 'middle' }} />}
                    </td>
                    <td style={{ color: 'var(--c-text-3)', fontSize: 12 }}>{r.stock_min}</td>
                    <td style={{ fontSize: 12 }}>{r.unidad}</td>
                    <td style={{ fontSize: 12 }}>{fmtMoney(r.precio_unit)}</td>
                    <td><button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button></td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar: ${editing.codigo}` : 'Nuevo material'}
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Código" required><input className="form-input" {...bind('codigo')} placeholder="MAT-001" /></Field>
          <Field label="Categoría">
            <select className="form-select" {...bind('categoria')}>
              {CATS.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Descripción" required span2><input className="form-input" {...bind('descripcion')} /></Field>
          <Field label="Stock actual"><input className="form-input" type="number" {...bind('stock')} /></Field>
          <Field label="Stock mínimo"><input className="form-input" type="number" {...bind('stock_min')} /></Field>
          <Field label="Unidad"><input className="form-input" {...bind('unidad')} placeholder="kg, m, unid..." /></Field>
          <Field label="Precio unitario"><input className="form-input" type="number" {...bind('precio_unit')} /></Field>
        </div>
      </Modal>
    </div>
  )
}
