import { ExternalLink, Upload } from 'lucide-react'

export default function CargaMasivaPage() {
  return (
    <div className="page">
      <h2 className="page-title">Carga masiva desde Excel</h2>

      <div className="card info-card">
        <div className="info-card-icon">
          <Upload size={24} />
        </div>
        <h3>Carga masiva</h3>
        <p>
          La carga masiva desde Excel (con plantillas descargables, soporte multi-archivo,
          validación de FKs y conversión automática) requiere XLSX en el navegador y manejo
          de archivos. Está disponible en la versión anterior.
        </p>
        <a href="/" className="btn btn-primary" style={{ textDecoration: 'none', display: 'inline-flex', gap: 6 }}>
          <ExternalLink size={14} /> Abrir versión anterior
        </a>
        <p className="footnote">Desde el menú, ir a Sistema → Carga masiva</p>
      </div>
    </div>
  )
}
