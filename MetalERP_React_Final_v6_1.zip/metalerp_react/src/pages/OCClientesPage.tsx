import { useState, useEffect, Fragment } from 'react'
import { ChevronDown, ChevronRight, Plus, Pencil, Zap, BarChart3, Trash2 } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import {
  Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field,
  ProgressBar, fmtDate, fmtMoney,
} from '../components/ui'

interface OCItem {
  id: number; producto_id: number
  producto_codigo: string; producto_nombre: string
  cantidad: number; precio_unit: number; fecha_deseada: string | null
  unidad: string; ot_id: number | null; obs?: string | null
}

interface OC {
  id: number; numero: string; cliente_nombre: string; cliente_id: number
  fecha: string | null; fecha_entrega: string | null; estado: string; obs: string | null
  items: OCItem[]
}

interface Cliente { id: number; razon: string }
interface Producto { id: number; codigo: string; nombre: string; precio_venta: number; unidad: string }

interface AvanceItem {
  id: number; prod_codigo: string; prod_nombre: string; cantidad: number; unidad: string
  entregado: number; pct: number
  remitos: { numero: string; fecha: string; estado: string; cantidad: number }[]
}

const ESTADOS = ['Recibida', 'Confirmada', 'En proceso', 'Completada', 'Cancelada']

interface OCFormItem {
  producto_id: string; cantidad: string; precio_unit: string; fecha_deseada: string; obs: string
}

const EMPTY_ITEM: OCFormItem = { producto_id: '', cantidad: '1', precio_unit: '0', fecha_deseada: '', obs: '' }

export default function OCClientesPage() {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<OC>({
    path: estFilter ? `/ordenes_cliente?estado=${estFilter}` : '/ordenes_cliente',
    searchKeys: ['numero', 'cliente_nombre'],
    errorMsg: 'Error cargando pedidos',
  })
  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [prods, setProds] = useState<Producto[]>([])
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<OC | null>(null)
  const [avance, setAvance] = useState<{ oc: OC; items: AvanceItem[] } | null>(null)
  const [avanceLoading, setAvanceLoading] = useState(false)
  const ocForm = useForm({ cliente_id: '', numero_oc: '', fecha_entrega: '', estado: 'Recibida', obs: '' })
  const [items, setItems] = useState<OCFormItem[]>([{ ...EMPTY_ITEM }])

  useEffect(() => {
    Promise.all([api.get<Cliente[]>('/clientes'), api.get<Producto[]>('/productos')])
      .then(([c, p]) => { setClientes(c); setProds(p) })
      .catch(() => {})
  }, [])

  const toggle = (id: number) =>
    setExpanded(prev => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })

  function openNew() {
    setEditing(null)
    ocForm.reset({ cliente_id: '', numero_oc: '', fecha_entrega: '', estado: 'Recibida', obs: '' })
    setItems([{ ...EMPTY_ITEM }])
    setOpen(true)
  }

  function openEdit(oc: OC) {
    setEditing(oc)
    ocForm.reset({
      cliente_id: String(oc.cliente_id),
      numero_oc: oc.numero,
      fecha_entrega: oc.fecha_entrega?.slice(0, 10) ?? '',
      estado: oc.estado,
      obs: oc.obs || '',
    })
    setItems(oc.items.map(i => ({
      producto_id: String(i.producto_id),
      cantidad: String(i.cantidad),
      precio_unit: String(i.precio_unit),
      fecha_deseada: i.fecha_deseada?.slice(0, 10) ?? '',
      obs: i.obs || '',
    })))
    setOpen(true)
  }

  function addItem() { setItems(prev => [...prev, { ...EMPTY_ITEM }]) }
  function removeItem(idx: number) { setItems(prev => prev.filter((_, i) => i !== idx)) }
  function updateItem(idx: number, patch: Partial<OCFormItem>) {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, ...patch } : it))
  }
  function selectProd(idx: number, prodId: string) {
    const p = prods.find(x => String(x.id) === prodId)
    updateItem(idx, { producto_id: prodId, precio_unit: p ? String(p.precio_venta) : '0' })
  }

  async function save() {
    if (!ocForm.values.cliente_id) { toast('Cliente requerido', 'warn'); return }
    const validItems = items.filter(i => i.producto_id && Number(i.cantidad) > 0)
    if (!editing && validItems.length === 0) { toast('Agregá al menos un producto', 'warn'); return }
    const body = {
      ...ocForm.values,
      cliente_id: Number(ocForm.values.cliente_id),
      fecha_entrega: ocForm.values.fecha_entrega || null,
      items: validItems.map(i => ({
        producto_id: Number(i.producto_id),
        cantidad: Number(i.cantidad),
        precio_unit: Number(i.precio_unit),
        fecha_deseada: i.fecha_deseada || null,
        obs: i.obs,
      })),
    }
    try {
      editing
        ? await api.put(`/ordenes_cliente/${editing.id}`, body)
        : await api.post('/ordenes_cliente', body)
      toast(editing ? 'OC actualizada' : 'OC creada')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function explotar(oc: OC) {
    if (!window.confirm(`¿Generar OTs para la ${oc.numero}?\nSe creará una OT por cada renglón sin OT vinculada (incluyendo explosión multinivel para productos compuestos).`)) return
    try {
      const r = await api.post<{ ots: { numero: string }[] }>(`/ordenes_cliente/${oc.id}/explotar`, {})
      toast(`OTs generadas: ${r.ots?.map(o => o.numero).join(', ') || 'ninguna'}`)
      reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function verAvance(oc: OC) {
    setAvance({ oc, items: [] }); setAvanceLoading(true)
    try {
      const items = await api.get<AvanceItem[]>(`/ordenes_cliente/${oc.id}/avance`)
      setAvance({ oc, items })
    } catch (e: any) { toast(e.message, 'error'); setAvance(null) }
    finally { setAvanceLoading(false) }
  }

  async function del(oc: OC) {
    if (!window.confirm(`¿Eliminar la OC ${oc.numero}?`)) return
    try { await api.delete(`/ordenes_cliente/${oc.id}`); toast('OC eliminada'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Pedidos de clientes"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar OC, cliente..."
        onReload={reload} primaryLabel="Nueva OC" onPrimary={openNew}
        rightChildren={
          <select className="form-select" style={{ width: 160 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
            <option value="">Todos los estados</option>
            {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin pedidos" desc="No hay órdenes de clientes registradas" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th style={{ width: 36 }}></th>
                <th>N° OC</th><th>Cliente</th><th>Artículos</th>
                <th>Fecha</th><th>F. entrega</th><th>Estado</th><th>Avance</th><th></th>
              </tr></thead>
              <tbody>
                {filtered.map(r => {
                  const isExp = expanded.has(r.id)
                  const totalItems = r.items.length
                  const conOT = r.items.filter(i => i.ot_id).length
                  const avPct = totalItems > 0 ? Math.round(conOT / totalItems * 100) : 0
                  const avColor = avPct === 100 ? 'var(--c-green)' : avPct > 0 ? 'var(--c-amber)' : 'var(--c-red)'
                  return (
                    <Fragment key={r.id}>
                      <tr>
                        <td style={{ textAlign: 'center', cursor: 'pointer' }} onClick={() => toggle(r.id)}>
                          {isExp ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                        </td>
                        <td className="cell-mono">{r.numero}</td>
                        <td style={{ fontSize: 13 }}>{r.cliente_nombre}</td>
                        <td className="cell-tight" style={{ color: 'var(--c-text-3)', maxWidth: 180 }}>
                          {r.items.map(i => `${i.producto_codigo} ×${i.cantidad}`).join(' · ')}
                        </td>
                        <td style={{ fontSize: 12 }}>{fmtDate(r.fecha)}</td>
                        <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_entrega)}</td>
                        <td><Badge value={r.estado} /></td>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 6, minWidth: 80 }}>
                            <ProgressBar value={avPct} color={avColor} />
                            <span style={{ fontSize: 11, fontWeight: 600, color: avColor }}>{avPct}%</span>
                          </div>
                        </td>
                        <td>
                          <div style={{ display: 'flex', gap: 4 }}>
                            <button className="btn btn-xs" onClick={() => openEdit(r)} title="Editar"><Pencil size={11} /></button>
                            <button className="btn btn-xs btn-primary" onClick={() => verAvance(r)} title="Ver avance">
                              <BarChart3 size={11} />
                            </button>
                            {conOT < totalItems && (
                              <button className="btn btn-xs btn-primary" onClick={() => explotar(r)} title="Generar OTs">
                                <Zap size={11} />
                              </button>
                            )}
                            <button className="btn btn-xs btn-danger" onClick={() => del(r)} title="Eliminar"><Trash2 size={11} /></button>
                          </div>
                        </td>
                      </tr>
                      {isExp && (
                        <tr>
                          <td colSpan={9} style={{ padding: 0 }}>
                            <div style={{ padding: '8px 12px 12px 48px', background: 'var(--c-bg)', borderBottom: '1px solid var(--c-border)' }}>
                              <table style={{ fontSize: 11 }}>
                                <thead><tr>
                                  <th>Código</th><th>Producto</th><th>Cantidad</th>
                                  <th>Precio unit.</th><th>F. deseada</th><th>OT</th><th>Estado</th>
                                </tr></thead>
                                <tbody>{r.items.map(i => (
                                  <tr key={i.id}>
                                    <td><b>{i.producto_codigo}</b></td>
                                    <td>{i.producto_nombre}</td>
                                    <td>{i.cantidad} {i.unidad || 'unid'}</td>
                                    <td>{fmtMoney(i.precio_unit)}</td>
                                    <td>{fmtDate(i.fecha_deseada)}</td>
                                    <td style={{ color: i.ot_id ? 'var(--c-blue)' : 'var(--c-text-3)' }}>
                                      {i.ot_id ? 'OT vinculada' : '—'}
                                    </td>
                                    <td><Badge value={i.ot_id ? 'Explotada' : 'Pendiente'} variant={i.ot_id ? 'green' : 'amber'} /></td>
                                  </tr>
                                ))}</tbody>
                              </table>
                            </div>
                          </td>
                        </tr>
                      )}
                    </Fragment>
                  )
                })}
              </tbody>
            </table></div>
          )}
      </Card>

      {/* Edit/new modal */}
      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar OC: ${editing.numero}` : 'Nueva OC de cliente'} size="xl"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Cliente" required>
            <select className="form-select" {...ocForm.bind('cliente_id')} disabled={!!editing}>
              <option value="">— Seleccionar —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select>
          </Field>
          <Field label="N° OC (opcional)" hint="Si está vacío, se genera automáticamente">
            <input className="form-input" {...ocForm.bind('numero_oc')} disabled={!!editing} />
          </Field>
          <Field label="Fecha entrega"><input className="form-input" type="date" {...ocForm.bind('fecha_entrega')} /></Field>
          <Field label="Estado">
            <select className="form-select" {...ocForm.bind('estado')}>
              {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </Field>
          <Field label="Observaciones" span2><textarea className="form-textarea" {...ocForm.bind('obs')} /></Field>
        </div>

        <div style={{ marginTop: 16, marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, margin: 0 }}>Renglones</h3>
          {!editing && (
            <button className="btn btn-sm btn-primary" onClick={addItem}><Plus size={12} /> Agregar renglón</button>
          )}
        </div>

        {editing && (
          <div className="alert-banner alert-info" style={{ marginBottom: 12 }}>
            Para modificar los renglones, eliminá la OC y creala de nuevo.
          </div>
        )}

        <table>
          <thead><tr>
            <th>Producto</th><th>Cantidad</th><th>Precio</th><th>F. deseada</th><th></th>
          </tr></thead>
          <tbody>{items.map((it, idx) => (
            <tr key={idx}>
              <td>
                <select className="form-select" style={{ width: '100%' }} value={it.producto_id}
                  onChange={e => selectProd(idx, e.target.value)} disabled={!!editing}>
                  <option value="">— Seleccionar producto —</option>
                  {prods.map(p => <option key={p.id} value={p.id}>{p.codigo} — {p.nombre}</option>)}
                </select>
              </td>
              <td>
                <input className="form-input" type="number" min="1" style={{ width: 80 }}
                  value={it.cantidad} onChange={e => updateItem(idx, { cantidad: e.target.value })}
                  disabled={!!editing} />
              </td>
              <td>
                <input className="form-input" type="number" min="0" step="0.01" style={{ width: 100 }}
                  value={it.precio_unit} onChange={e => updateItem(idx, { precio_unit: e.target.value })}
                  disabled={!!editing} />
              </td>
              <td>
                <input className="form-input" type="date" value={it.fecha_deseada}
                  onChange={e => updateItem(idx, { fecha_deseada: e.target.value })}
                  disabled={!!editing} />
              </td>
              <td>
                {!editing && items.length > 1 && (
                  <button className="btn btn-xs btn-danger" onClick={() => removeItem(idx)}><Trash2 size={10} /></button>
                )}
              </td>
            </tr>
          ))}</tbody>
        </table>
      </Modal>

      {/* Avance modal */}
      <Modal open={!!avance} onClose={() => setAvance(null)}
        title={avance ? `Avance: ${avance.oc.numero} — ${avance.oc.cliente_nombre}` : ''} size="xl"
        footer={<button className="btn" onClick={() => setAvance(null)}>Cerrar</button>}
      >
        {avanceLoading ? <PageLoading /> : avance && (
          <table>
            <thead><tr>
              <th>Producto</th><th>Cantidad</th><th>Entregado</th>
              <th style={{ minWidth: 160 }}>Avance</th><th>Remitos</th>
            </tr></thead>
            <tbody>{avance.items.map(item => (
              <tr key={item.id}>
                <td><b>{item.prod_codigo}</b> {item.prod_nombre}</td>
                <td>{item.cantidad} {item.unidad}</td>
                <td>{item.entregado} {item.unidad}</td>
                <td>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <ProgressBar value={item.pct} color={item.pct === 100 ? 'var(--c-green)' : 'var(--c-amber)'} />
                    <span style={{ fontSize: 11, fontWeight: 600 }}>{item.pct}%</span>
                  </div>
                </td>
                <td style={{ fontSize: 11 }}>
                  {item.remitos.length === 0
                    ? <span style={{ color: 'var(--c-text-3)' }}>Sin remitos</span>
                    : item.remitos.map((r, i) => (
                        <div key={i}>
                          <b>{r.numero}</b> · {fmtDate(r.fecha)} · {r.cantidad} {item.unidad}
                        </div>
                      ))}
                </td>
              </tr>
            ))}</tbody>
          </table>
        )}
      </Modal>
    </div>
  )
}
