import { useState, useEffect } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, fmtDate, fmtMoney } from '../components/ui'

interface Pres {
  id: number; numero: string; cliente_nombre: string
  fecha: string; estado: string; total: number; obs: string | null
}
interface Cliente { id: number; razon: string }

const ESTADOS = ['Borrador', 'Enviado', 'Aprobado', 'Rechazado', 'Facturado']
const PIPELINE_ESTADOS = new Set(['Borrador', 'Enviado', 'Aprobado'])

export default function PresupuestosPage() {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<Pres>({
    path: '/presupuestos',
    searchKeys: ['numero', 'cliente_nombre'],
    filter: r => !estFilter || r.estado === estFilter,
    errorMsg: 'Error cargando presupuestos',
  })
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [open, setOpen] = useState(false)
  const { values, bind, reset } = useForm({ cliente_id: '', estado: 'Borrador', total: '0', obs: '' })

  useEffect(() => { api.get<Cliente[]>('/clientes').then(setClientes).catch(() => {}) }, [])

  function openNew() {
    reset({ cliente_id: '', estado: 'Borrador', total: '0', obs: '' })
    setOpen(true)
  }

  async function save() {
    if (!values.cliente_id) { toast('Cliente requerido', 'warn'); return }
    try {
      await api.post('/presupuestos', {
        cliente_id: Number(values.cliente_id),
        estado: values.estado, total: Number(values.total), obs: values.obs,
      })
      toast('Presupuesto creado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  const totalPipeline = filtered
    .filter(r => PIPELINE_ESTADOS.has(r.estado))
    .reduce((s, r) => s + (r.total || 0), 0)

  return (
    <div className="page">
      <Toolbar
        title="Presupuestos"
        search={search} onSearch={setSearch}
        onReload={reload} primaryLabel="Nuevo presupuesto" onPrimary={openNew}
        badge={totalPipeline > 0
          ? <span className="counter-pill counter-pill-blue">Pipeline: {fmtMoney(totalPipeline)}</span>
          : undefined
        }
        rightChildren={
          <select className="form-select" style={{ width: 140 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
            <option value="">Todos los estados</option>
            {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin presupuestos" desc="Creá el primer presupuesto" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>N°</th><th>Cliente</th><th>Fecha</th><th>Estado</th><th>Total</th><th>Observaciones</th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.numero}</td>
                  <td style={{ fontSize: 13 }}>{r.cliente_nombre}</td>
                  <td style={{ fontSize: 12 }}>{fmtDate(r.fecha)}</td>
                  <td><Badge value={r.estado} /></td>
                  <td style={{ fontSize: 13, fontWeight: 600 }}>{fmtMoney(r.total)}</td>
                  <td className="cell-tight">{r.obs || '—'}</td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Nuevo presupuesto"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Cliente" required span2>
            <select className="form-select" {...bind('cliente_id')}>
              <option value="">— Seleccionar —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select>
          </Field>
          <Field label="Estado">
            <select className="form-select" {...bind('estado')}>
              {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </Field>
          <Field label="Total estimado">
            <input className="form-input" type="number" min="0" step="0.01" {...bind('total')} />
          </Field>
          <Field label="Observaciones" span2>
            <textarea className="form-textarea" {...bind('obs')} />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
