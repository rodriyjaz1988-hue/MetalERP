import { useState, useEffect } from 'react'
import { Eye, Plus, Pencil, Trash2, Copy, Users, Wrench, Paperclip } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import {
  Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field,
  fmtMoney,
} from '../components/ui'

interface Cat { id: number; nombre: string }
interface Cliente { id: number; razon: string }
interface CatMaq { id: number; nombre: string }
interface Maq { id: number; codigo: string; nombre: string; categoria_id: number | null }
interface Material { id: number; codigo: string; descripcion: string; unidad: string }
interface ProveedorOp { id: number; razon: string }

interface OpMat {
  id?: number
  material_id?: number | null
  producto_id?: number | null
  codigo: string
  descripcion: string
  cantidad: number
  unidad: string
  tipo?: 'material' | 'producto'
}

interface Op {
  id: number; orden: number; nombre: string; descripcion: string | null
  es_tercerizada: number; proveedor_id: number | null; proveedor_nombre: string | null
  precio_tercerizado: number
  tiempo_setup_min: number; tiempo_ciclo_min: number
  categoria_maquina_id: number | null; maquina_id: number | null
  maq_nombre: string | null; cat_maq_nombre: string | null
  materiales: OpMat[]
  productos_insumo: OpMat[]
}

interface Producto {
  id: number; codigo: string; nombre: string; descripcion: string | null
  categoria_id: number | null; categoria_nombre: string | null
  cliente_id: number | null; cliente_nombre: string | null
  unidad: string; precio_venta: number; peso_kg: number
  tiempo_ciclo_total_min: number | null; activo: number
  operaciones?: Op[]
}

const EMPTY_PROD = {
  codigo: '', nombre: '', descripcion: '', categoria_id: '', cliente_id: '',
  unidad: 'unid', precio_venta: '0', peso_kg: '0', obs: '',
}

const EMPTY_OP = {
  orden: '1', nombre: '', descripcion: '',
  es_tercerizada: false,
  categoria_maquina_id: '', maquina_id: '',
  tiempo_setup_min: '0', tiempo_ciclo_min: '0',
  proveedor_id: '', precio_tercerizado: '0',
  obs: '',
}

// ── OpForm: modal de alta/edición de operación ────────────────────────────
function OpForm({
  open, onClose, productoId, editing, cats, maqs, mats, provs, onSaved,
}: {
  open: boolean
  onClose: () => void
  productoId: number
  editing: Op | null
  cats: CatMaq[]
  maqs: Maq[]
  mats: Material[]
  provs: ProveedorOp[]
  onSaved: () => void
}) {
  const toast = useToast()
  const { values, bind, set, reset, setValues } = useForm(EMPTY_OP)
  const [opMats, setOpMats] = useState<OpMat[]>([])
  const [saving, setSaving] = useState(false)
  const [matBuscar, setMatBuscar] = useState('')

  useEffect(() => {
    if (!open) return
    if (editing) {
      reset({
        orden: String(editing.orden),
        nombre: editing.nombre,
        descripcion: editing.descripcion || '',
        es_tercerizada: editing.es_tercerizada === 1,
        categoria_maquina_id: String(editing.categoria_maquina_id ?? ''),
        maquina_id: String(editing.maquina_id ?? ''),
        tiempo_setup_min: String(editing.tiempo_setup_min),
        tiempo_ciclo_min: String(editing.tiempo_ciclo_min),
        proveedor_id: String(editing.proveedor_id ?? ''),
        precio_tercerizado: String(editing.precio_tercerizado),
        obs: '',
      })
      // Combine materials + insumos
      const combined: OpMat[] = [
        ...(editing.materiales || []).map(m => ({ ...m, tipo: 'material' as const })),
        ...(editing.productos_insumo || []).map(m => ({ ...m, tipo: 'producto' as const })),
      ]
      setOpMats(combined)
    } else {
      reset(EMPTY_OP)
      setOpMats([])
    }
    setMatBuscar('')
  }, [open, editing])

  const maqsFiltradas = values.categoria_maquina_id
    ? maqs.filter(m => String(m.categoria_id) === values.categoria_maquina_id)
    : maqs

  const matsFiltrados = matBuscar
    ? mats.filter(m =>
        m.codigo.toLowerCase().includes(matBuscar.toLowerCase()) ||
        m.descripcion.toLowerCase().includes(matBuscar.toLowerCase()))
    : mats.slice(0, 50)

  function addMat(m: Material) {
    if (opMats.some(om => om.material_id === m.id && om.tipo === 'material')) {
      toast(`${m.codigo} ya está agregado`, 'warn'); return
    }
    setOpMats([...opMats, {
      material_id: m.id, codigo: m.codigo, descripcion: m.descripcion,
      cantidad: 1, unidad: m.unidad, tipo: 'material',
    }])
    setMatBuscar('')
  }

  function updateMatQty(idx: number, qty: number) {
    setOpMats(prev => prev.map((m, i) => i === idx ? { ...m, cantidad: qty } : m))
  }

  function removeMat(idx: number) {
    setOpMats(prev => prev.filter((_, i) => i !== idx))
  }

  async function save() {
    if (!values.nombre) { toast('Nombre de la operación requerido', 'warn'); return }
    const body: any = {
      producto_id: productoId,
      orden: Number(values.orden) || 1,
      nombre: values.nombre,
      descripcion: values.descripcion,
      es_tercerizada: values.es_tercerizada ? 1 : 0,
      obs: values.obs,
      materiales: opMats.map(m => ({
        material_id: m.tipo === 'material' ? m.material_id : null,
        producto_id: m.tipo === 'producto' ? m.producto_id : null,
        cantidad: m.cantidad,
        unidad: m.unidad,
        tipo: m.tipo || 'material',
      })),
    }
    if (values.es_tercerizada) {
      body.proveedor_id = values.proveedor_id ? Number(values.proveedor_id) : null
      body.precio_tercerizado = Number(values.precio_tercerizado) || 0
    } else {
      body.categoria_maquina_id = values.categoria_maquina_id ? Number(values.categoria_maquina_id) : null
      body.maquina_id = values.maquina_id ? Number(values.maquina_id) : null
      body.tiempo_setup_min = Number(values.tiempo_setup_min) || 0
      body.tiempo_ciclo_min = Number(values.tiempo_ciclo_min) || 0
    }
    setSaving(true)
    try {
      editing
        ? await api.put(`/operaciones/${editing.id}`, body)
        : await api.post('/operaciones', body)
      toast(editing ? 'Operación actualizada' : 'Operación agregada')
      onSaved(); onClose()
    } catch (e: any) { toast(e.message, 'error') }
    finally { setSaving(false) }
  }

  return (
    <Modal open={open} onClose={onClose}
      title={editing ? `Editar operación: ${editing.nombre}` : 'Nueva operación'} size="xl"
      footer={<>
        <button className="btn" onClick={onClose}>Cancelar</button>
        <button className="btn btn-primary" onClick={save} disabled={saving}>
          {saving ? 'Guardando...' : 'Guardar operación'}
        </button>
      </>}
    >
      <div className="form-grid">
        <Field label="Orden" required>
          <input className="form-input" type="number" min="1" {...bind('orden')} />
        </Field>
        <Field label="Nombre" required>
          <input className="form-input" {...bind('nombre')} placeholder="Tornear, Soldar, Pintar..." />
        </Field>
        <Field label="Descripción" span2>
          <input className="form-input" {...bind('descripcion')} />
        </Field>

        <div className="form-group col-span-2">
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
            <input type="checkbox" checked={values.es_tercerizada}
              onChange={e => set({ es_tercerizada: e.target.checked })}
              style={{ width: 16, height: 16 }} />
            <span style={{ fontSize: 13, fontWeight: 600 }}>Operación tercerizada</span>
          </label>
        </div>

        {!values.es_tercerizada ? (
          <>
            <Field label="Categoría de máquina">
              <select className="form-select" value={values.categoria_maquina_id}
                onChange={e => setValues(v => ({ ...v, categoria_maquina_id: e.target.value, maquina_id: '' }))}>
                <option value="">— Cualquiera —</option>
                {cats.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
              </select>
            </Field>
            <Field label="Máquina específica">
              <select className="form-select" {...bind('maquina_id')}>
                <option value="">— Cualquiera —</option>
                {maqsFiltradas.map(m => <option key={m.id} value={m.id}>{m.codigo} — {m.nombre}</option>)}
              </select>
            </Field>
            <Field label="Tiempo setup (min)">
              <input className="form-input" type="number" min="0" step="0.1" {...bind('tiempo_setup_min')} />
            </Field>
            <Field label="Tiempo ciclo (min)">
              <input className="form-input" type="number" min="0" step="0.01" {...bind('tiempo_ciclo_min')} />
            </Field>
          </>
        ) : (
          <>
            <Field label="Proveedor" span2>
              <select className="form-select" {...bind('proveedor_id')}>
                <option value="">— Sin asignar —</option>
                {provs.map(p => <option key={p.id} value={p.id}>{p.razon}</option>)}
              </select>
            </Field>
            <Field label="Precio acordado">
              <input className="form-input" type="number" min="0" step="0.01" {...bind('precio_tercerizado')} />
            </Field>
          </>
        )}

        {/* Materiales */}
        <div className="form-group col-span-2" style={{ marginTop: 8 }}>
          <label className="form-label">Materiales / insumos de esta operación</label>
          <div className="search-wrap" style={{ marginBottom: 6 }}>
            <input className="form-input" placeholder="Buscar material por código o descripción..."
              value={matBuscar} onChange={e => setMatBuscar(e.target.value)} />
          </div>
          {matBuscar && matsFiltrados.length > 0 && (
            <div style={{
              border: '1px solid var(--c-border)', borderRadius: 8, maxHeight: 140,
              overflowY: 'auto', background: 'var(--c-surface)', marginBottom: 8,
            }}>
              {matsFiltrados.map(m => (
                <div key={m.id} onClick={() => addMat(m)} style={{
                  padding: '6px 10px', cursor: 'pointer', borderBottom: '1px solid var(--c-border)',
                  fontSize: 12,
                }}>
                  <b>{m.codigo}</b> {m.descripcion} <span style={{ color: 'var(--c-text-3)' }}>({m.unidad})</span>
                </div>
              ))}
            </div>
          )}

          {opMats.length === 0 ? (
            <p style={{ fontSize: 12, color: 'var(--c-text-3)', fontStyle: 'italic' }}>
              Sin materiales asignados — opcional
            </p>
          ) : (
            <table style={{ fontSize: 12 }}>
              <thead><tr>
                <th>Tipo</th><th>Código</th><th>Descripción</th>
                <th>Cantidad</th><th>Unidad</th><th></th>
              </tr></thead>
              <tbody>{opMats.map((om, idx) => (
                <tr key={idx}>
                  <td>
                    <Badge value={om.tipo === 'producto' ? 'Producto' : 'Material'}
                      variant={om.tipo === 'producto' ? 'purple' : 'blue'} />
                  </td>
                  <td className="cell-mono">{om.codigo}</td>
                  <td>{om.descripcion}</td>
                  <td>
                    <input className="form-input" type="number" min="0.001" step="0.001"
                      style={{ width: 100 }} value={om.cantidad}
                      onChange={e => updateMatQty(idx, Number(e.target.value))} />
                  </td>
                  <td>{om.unidad}</td>
                  <td>
                    <button className="btn btn-xs btn-danger" onClick={() => removeMat(idx)}>
                      <Trash2 size={10} />
                    </button>
                  </td>
                </tr>
              ))}</tbody>
            </table>
          )}
        </div>
      </div>
    </Modal>
  )
}

// ── ArchivosModal: adjuntos (planos, PDFs, imágenes) de un producto ────────
interface Archivo {
  nombre: string; size: number; mime: string
  is_img: boolean; is_pdf: boolean
}

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`
}

function ArchivosModal({ prod, onClose }: { prod: Producto | null; onClose: () => void }) {
  const toast = useToast()
  const [archivos, setArchivos] = useState<Archivo[]>([])
  const [loading, setLoading] = useState(false)
  const [uploading, setUploading] = useState(false)

  async function load(pid: number) {
    setLoading(true)
    try {
      const r = await api.get<{ archivos: Archivo[] }>(`/productos/${pid}/archivos`)
      setArchivos(r.archivos || [])
    } catch (e: any) { toast(e.message, 'error') }
    finally { setLoading(false) }
  }

  useEffect(() => { if (prod) load(prod.id) }, [prod])

  async function onPick(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0]
    if (!file || !prod) return
    setUploading(true)
    try {
      await api.upload(`/productos/${prod.id}/archivos`, file)
      toast('Archivo subido')
      await load(prod.id)
    } catch (err: any) { toast(err.message, 'error') }
    finally { setUploading(false); e.target.value = '' }
  }

  async function del(nombre: string) {
    if (!prod || !window.confirm(`¿Eliminar "${nombre}"?`)) return
    try {
      await api.delete(`/productos/${prod.id}/archivos/${encodeURIComponent(nombre)}`)
      toast('Archivo eliminado')
      await load(prod.id)
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <Modal open={!!prod} onClose={onClose}
      title={prod ? `Archivos — ${prod.codigo} ${prod.nombre}` : ''} size="lg"
      footer={<button className="btn" onClick={onClose}>Cerrar</button>}
    >
      <div style={{ marginBottom: 16, padding: 12, background: 'var(--c-bg)', borderRadius: 8 }}>
        <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8 }}>Subir archivo</div>
        <p style={{ fontSize: 11, color: 'var(--c-text-3)', marginBottom: 8 }}>
          Planos, PDFs, imágenes técnicas, certificados. Se guardan en la carpeta del producto.
        </p>
        <label className="btn btn-primary btn-sm" style={{ cursor: uploading ? 'wait' : 'pointer' }}>
          <Paperclip size={12} /> {uploading ? 'Subiendo...' : 'Elegir archivo'}
          <input type="file" style={{ display: 'none' }} onChange={onPick} disabled={uploading} />
        </label>
      </div>

      {loading ? <PageLoading /> : archivos.length === 0
        ? <p style={{ fontSize: 12, color: 'var(--c-text-3)', fontStyle: 'italic' }}>Sin archivos adjuntos.</p>
        : (
          <table>
            <thead><tr><th>Archivo</th><th>Tipo</th><th>Tamaño</th><th></th></tr></thead>
            <tbody>{archivos.map(a => (
              <tr key={a.nombre}>
                <td style={{ fontSize: 13 }}>
                  {a.is_img ? '🖼️ ' : a.is_pdf ? '📄 ' : '📎 '}{a.nombre}
                </td>
                <td style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{a.mime}</td>
                <td style={{ fontSize: 12 }}>{fmtSize(a.size)}</td>
                <td>
                  <div style={{ display: 'flex', gap: 4, justifyContent: 'flex-end' }}>
                    <a className="btn btn-xs" href={`/api/productos/${prod!.id}/archivos/${encodeURIComponent(a.nombre)}`}
                      target="_blank" rel="noopener noreferrer" style={{ textDecoration: 'none' }}>
                      Ver
                    </a>
                    <button className="btn btn-xs btn-danger" onClick={() => del(a.nombre)}>
                      <Trash2 size={10} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}</tbody>
          </table>
        )}
    </Modal>
  )
}

// ── HerramientasModal: gestiona herramientas de una operación ─────────────
interface Herramienta {
  id: number; orden: number; nombre: string; descripcion: string | null
  duracion_min: number; unidad: string; cantidad: number
}

function HerramientasModal({ op, onClose }: { op: Op | null; onClose: () => void }) {
  const toast = useToast()
  const [rows, setRows] = useState<Herramienta[]>([])
  const [loading, setLoading] = useState(false)
  const form = useForm({ nombre: '', descripcion: '', duracion_min: '0', unidad: 'unid', cantidad: '1' })

  useEffect(() => {
    if (!op) return
    setLoading(true)
    api.get<Herramienta[]>(`/operaciones/${op.id}/herramientas`)
      .then(setRows).catch(() => {}).finally(() => setLoading(false))
  }, [op])

  async function add() {
    if (!op || !form.values.nombre) { toast('Nombre requerido', 'warn'); return }
    try {
      await api.post(`/operaciones/${op.id}/herramientas`, {
        orden: rows.length + 1,
        nombre: form.values.nombre,
        descripcion: form.values.descripcion,
        duracion_min: Number(form.values.duracion_min) || 0,
        unidad: form.values.unidad,
        cantidad: Number(form.values.cantidad) || 1,
      })
      setRows(await api.get<Herramienta[]>(`/operaciones/${op.id}/herramientas`))
      form.reset({ nombre: '', descripcion: '', duracion_min: '0', unidad: 'unid', cantidad: '1' })
      toast('Herramienta agregada')
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function del(hid: number) {
    if (!op) return
    try {
      await api.delete(`/operaciones/${op.id}/herramientas/${hid}`)
      setRows(await api.get<Herramienta[]>(`/operaciones/${op.id}/herramientas`))
      toast('Herramienta quitada')
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <Modal open={!!op} onClose={onClose}
      title={op ? `Herramientas — ${op.nombre}` : ''} size="lg"
      footer={<button className="btn" onClick={onClose}>Cerrar</button>}
    >
      <div style={{ marginBottom: 16, padding: 12, background: 'var(--c-bg)', borderRadius: 8 }}>
        <div style={{ fontSize: 12, fontWeight: 600, marginBottom: 8 }}>Agregar herramienta / utillaje</div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-end', flexWrap: 'wrap' }}>
          <div style={{ flex: '2 1 160px' }}>
            <label className="form-label">Nombre</label>
            <input className="form-input" {...form.bind('nombre')} placeholder="Matriz, calibre, plantilla..." />
          </div>
          <div style={{ flex: '1 1 70px' }}>
            <label className="form-label">Cantidad</label>
            <input className="form-input" type="number" min="1" {...form.bind('cantidad')} />
          </div>
          <div style={{ flex: '1 1 80px' }}>
            <label className="form-label">Duración (min)</label>
            <input className="form-input" type="number" min="0" {...form.bind('duracion_min')} />
          </div>
          <button className="btn btn-primary" onClick={add} style={{ marginBottom: 0 }}>Agregar</button>
        </div>
      </div>

      {loading ? <PageLoading /> : rows.length === 0
        ? <p style={{ fontSize: 12, color: 'var(--c-text-3)', fontStyle: 'italic' }}>Sin herramientas asignadas a esta operación.</p>
        : (
          <table>
            <thead><tr><th>#</th><th>Herramienta</th><th>Cantidad</th><th>Duración</th><th></th></tr></thead>
            <tbody>{rows.map(h => (
              <tr key={h.id}>
                <td style={{ textAlign: 'center', fontSize: 12 }}>{h.orden}</td>
                <td style={{ fontSize: 13 }}>
                  <b>{h.nombre}</b>
                  {h.descripcion && <div style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{h.descripcion}</div>}
                </td>
                <td style={{ fontSize: 12 }}>{h.cantidad} {h.unidad}</td>
                <td style={{ fontSize: 12 }}>{h.duracion_min ? `${h.duracion_min} min` : '—'}</td>
                <td>
                  <button className="btn btn-xs btn-danger" onClick={() => del(h.id)}><Trash2 size={10} /></button>
                </td>
              </tr>
            ))}</tbody>
          </table>
        )}
    </Modal>
  )
}

// ── OpRow: visualización de una operación dentro del proceso ──────────────
function OpRow({
  op, idx, onEdit, onDelete, onHerramientas,
}: { op: Op; idx: number; onEdit: () => void; onDelete: () => void; onHerramientas: () => void }) {
  return (
    <div style={{
      border: '1px solid var(--c-border)', borderRadius: 10, padding: 14,
      background: op.es_tercerizada ? 'var(--c-amber-bg)' : 'var(--c-surface)',
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 8 }}>
        <div style={{
          width: 28, height: 28, borderRadius: '50%', background: 'var(--c-primary)', color: '#fff',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 13, fontWeight: 700, flexShrink: 0,
        }}>{idx + 1}</div>
        <div style={{ flex: 1 }}>
          <div style={{ fontWeight: 600, fontSize: 14 }}>{op.nombre}</div>
          {op.descripcion && <div style={{ fontSize: 12, color: 'var(--c-text-3)' }}>{op.descripcion}</div>}
        </div>
        {op.es_tercerizada
          ? <Badge value="Tercerizada" variant="amber" />
          : <span style={{ fontSize: 11, color: 'var(--c-text-3)' }}>
              Setup: {op.tiempo_setup_min} min · Ciclo: {Math.round(op.tiempo_ciclo_min * 60)} seg
            </span>}
        <button className="btn btn-xs" onClick={onHerramientas} title="Herramientas"><Wrench size={11} /></button>
        <button className="btn btn-xs" onClick={onEdit} title="Editar"><Pencil size={11} /></button>
        <button className="btn btn-xs btn-danger" onClick={onDelete} title="Borrar"><Trash2 size={11} /></button>
      </div>
      <div style={{ display: 'flex', gap: 8, fontSize: 12, flexWrap: 'wrap' }}>
        {op.maq_nombre && <span style={{ color: 'var(--c-text-3)' }}>🔧 {op.maq_nombre}</span>}
        {op.proveedor_nombre && <span style={{ color: 'var(--c-amber)' }}>🏭 {op.proveedor_nombre}</span>}
        {op.materiales?.map(m => (
          <span key={`m-${m.id}`} className="counter-pill counter-pill-blue" style={{ fontSize: 11 }}>
            {m.codigo} ×{m.cantidad} {m.unidad}
          </span>
        ))}
        {op.productos_insumo?.map(p => (
          <span key={`p-${p.id}`} className="counter-pill counter-pill-blue" style={{ fontSize: 11 }}>
            📦 {p.codigo} ×{p.cantidad}
          </span>
        ))}
      </div>
    </div>
  )
}

// ── ProcesosPage main component ───────────────────────────────────────────
export default function ProcesosPage() {
  const toast = useToast()
  const [cliFilter, setCliFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<Producto>({
    path: '/productos' + (cliFilter ? `?cliente_id=${cliFilter}` : ''),
    searchKeys: ['codigo', 'nombre'],
    errorMsg: 'Error cargando productos',
  })
  const [cats, setCats] = useState<Cat[]>([])
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [catsMaq, setCatsMaq] = useState<CatMaq[]>([])
  const [maqs, setMaqs] = useState<Maq[]>([])
  const [mats, setMats] = useState<Material[]>([])
  const [provs, setProvs] = useState<ProveedorOp[]>([])
  const [showModal, setShowModal] = useState(false)
  const [verProc, setVerProc] = useState<Producto | null>(null)
  const [loadingProc, setLoadingProc] = useState(false)
  const [editing, setEditing] = useState<Producto | null>(null)
  const [opFormOpen, setOpFormOpen] = useState(false)
  const [editingOp, setEditingOp] = useState<Op | null>(null)
  const [herramientasOp, setHerramientasOp] = useState<Op | null>(null)
  const [archivosProd, setArchivosProd] = useState<Producto | null>(null)
  const [copyFrom, setCopyFrom] = useState<Producto | null>(null)
  const [multiCli, setMultiCli] = useState<Producto | null>(null)
  const [multiCliRows, setMultiCliRows] = useState<Cliente[]>([])
  const [multiCliAdd, setMultiCliAdd] = useState('')
  const { values, bind, reset } = useForm(EMPTY_PROD)
  const copyForm = useForm({ codigo: '', nombre: '' })

  useEffect(() => {
    Promise.all([
      api.get<Cat[]>('/categorias_producto'),
      api.get<Cliente[]>('/clientes'),
      api.get<CatMaq[]>('/categorias_maquina'),
      api.get<Maq[]>('/maquinas'),
      api.get<Material[]>('/materiales'),
      api.get<ProveedorOp[]>('/proveedores'),
    ]).then(([c, cl, cm, mq, ma, pr]) => {
      setCats(c); setClientes(cl); setCatsMaq(cm); setMaqs(mq); setMats(ma); setProvs(pr)
    }).catch(() => {})
  }, [])

  function openNew() { setEditing(null); reset(EMPTY_PROD); setShowModal(true) }
  function openEdit(p: Producto) {
    setEditing(p)
    reset({
      codigo: p.codigo, nombre: p.nombre, descripcion: p.descripcion || '',
      categoria_id: String(p.categoria_id ?? ''), cliente_id: String(p.cliente_id ?? ''),
      unidad: p.unidad, precio_venta: String(p.precio_venta),
      peso_kg: String(p.peso_kg), obs: '',
    })
    setShowModal(true)
  }

  async function loadProc(id: number) {
    setLoadingProc(true)
    try { setVerProc(await api.get<Producto>(`/productos/${id}`)) }
    catch { toast('Error cargando proceso', 'error') }
    finally { setLoadingProc(false) }
  }

  async function openVerProc(p: Producto) {
    setVerProc({ ...p, operaciones: undefined })
    await loadProc(p.id)
  }

  async function save() {
    if (!values.codigo || !values.nombre) { toast('Código y nombre requeridos', 'warn'); return }
    const body = {
      ...values,
      categoria_id: values.categoria_id ? Number(values.categoria_id) : null,
      cliente_id: values.cliente_id ? Number(values.cliente_id) : null,
      precio_venta: Number(values.precio_venta),
      peso_kg: Number(values.peso_kg),
    }
    try {
      editing ? await api.put(`/productos/${editing.id}`, body) : await api.post('/productos', body)
      toast(editing ? 'Producto actualizado' : 'Producto creado')
      setShowModal(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  function openOpNew() {
    setEditingOp(null); setOpFormOpen(true)
  }

  function openOpEdit(op: Op) {
    setEditingOp(op); setOpFormOpen(true)
  }

  async function deleteOp(op: Op) {
    if (!window.confirm(`¿Borrar la operación "${op.nombre}"?`)) return
    try {
      await api.delete(`/operaciones/${op.id}`)
      toast('Operación borrada')
      if (verProc) loadProc(verProc.id)
    } catch (e: any) { toast(e.message, 'error') }
  }

  function openCopy(p: Producto) {
    setCopyFrom(p)
    copyForm.reset({ codigo: '', nombre: `${p.nombre} (copia)` })
  }

  async function doCopy() {
    if (!copyFrom) return
    if (!copyForm.values.codigo) { toast('Código requerido', 'warn'); return }
    try {
      await api.post(`/productos/${copyFrom.id}/copiar`, copyForm.values)
      toast('Producto copiado'); setCopyFrom(null); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function openMultiCli(p: Producto) {
    setMultiCli(p); setMultiCliAdd('')
    try { setMultiCliRows(await api.get<Cliente[]>(`/productos/${p.id}/clientes`)) }
    catch { toast('Error cargando clientes', 'error') }
  }

  async function linkCli() {
    if (!multiCli || !multiCliAdd) return
    try {
      await api.post(`/productos/${multiCli.id}/clientes`, { cliente_id: Number(multiCliAdd) })
      setMultiCliRows(await api.get<Cliente[]>(`/productos/${multiCli.id}/clientes`))
      setMultiCliAdd('')
      toast('Cliente vinculado')
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function unlinkCli(cid: number) {
    if (!multiCli) return
    try {
      await api.delete(`/productos/${multiCli.id}/clientes/${cid}`)
      setMultiCliRows(await api.get<Cliente[]>(`/productos/${multiCli.id}/clientes`))
      toast('Cliente desvinculado')
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Procesos / Productos"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar producto..."
        onReload={reload} primaryLabel="Nuevo producto" onPrimary={openNew}
        rightChildren={
          <select className="form-select" style={{ width: 180 }} value={cliFilter} onChange={e => setCliFilter(e.target.value)}>
            <option value="">Todos los clientes</option>
            {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin productos" desc="Registrá el primer producto terminado" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Código</th><th>Nombre</th><th>Cliente</th><th>Categoría</th>
                <th>Ciclo total</th><th>Peso</th><th>Precio venta</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.codigo}</td>
                  <td style={{ fontSize: 13 }}>{r.nombre}</td>
                  <td style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{r.cliente_nombre || '—'}</td>
                  <td>{r.categoria_nombre ? <Badge value={r.categoria_nombre} variant="gray" /> : '—'}</td>
                  <td style={{ fontSize: 12 }}>{r.tiempo_ciclo_total_min != null ? `${r.tiempo_ciclo_total_min} min` : '—'}</td>
                  <td style={{ fontSize: 12 }}>{r.peso_kg > 0 ? `${r.peso_kg} kg` : '—'}</td>
                  <td style={{ fontSize: 13, fontWeight: 600 }}>{fmtMoney(r.precio_venta)}</td>
                  <td><Badge value={r.activo ? 'Activo' : 'Inactivo'} /></td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-xs btn-primary" onClick={() => openVerProc(r)} title="Ver proceso">
                        <Eye size={11} />
                      </button>
                      <button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button>
                      <button className="btn btn-xs" onClick={() => openCopy(r)} title="Copiar producto">
                        <Copy size={11} />
                      </button>
                      <button className="btn btn-xs" onClick={() => openMultiCli(r)} title="Clientes adicionales">
                        <Users size={11} />
                      </button>
                      <button className="btn btn-xs" onClick={() => setArchivosProd(r)} title="Archivos adjuntos">
                        <Paperclip size={11} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      {/* Modal alta/edición de producto */}
      <Modal open={showModal} onClose={() => setShowModal(false)}
        title={editing ? `Editar: ${editing.codigo}` : 'Nuevo producto terminado'} size="lg"
        footer={<>
          <button className="btn" onClick={() => setShowModal(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Código" required><input className="form-input" {...bind('codigo')} placeholder="PROD-001" /></Field>
          <Field label="Categoría">
            <select className="form-select" {...bind('categoria_id')}>
              <option value="">— Sin categoría —</option>
              {cats.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select>
          </Field>
          <Field label="Nombre" required span2><input className="form-input" {...bind('nombre')} /></Field>
          <Field label="Cliente (dueño del producto)" span2>
            <select className="form-select" {...bind('cliente_id')}>
              <option value="">— Sin cliente —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select>
          </Field>
          <Field label="Unidad"><input className="form-input" {...bind('unidad')} /></Field>
          <Field label="Precio venta"><input className="form-input" type="number" min="0" step="0.01" {...bind('precio_venta')} /></Field>
          <Field label="Peso (kg)"><input className="form-input" type="number" min="0" step="0.001" {...bind('peso_kg')} /></Field>
          <Field label="Descripción" span2><textarea className="form-textarea" {...bind('descripcion')} /></Field>
        </div>
      </Modal>

      {/* Modal ver/editar proceso */}
      <Modal open={!!verProc} onClose={() => setVerProc(null)}
        title={verProc ? `Proceso: ${verProc.codigo} — ${verProc.nombre}` : ''} size="xl"
        footer={<button className="btn" onClick={() => setVerProc(null)}>Cerrar</button>}
      >
        {loadingProc ? <PageLoading /> : verProc && (
          <>
            <div className="kv-grid kv-grid-3" style={{ marginBottom: 20 }}>
              {[
                { label: 'Cliente', value: verProc.cliente_nombre || '—' },
                { label: 'Precio venta', value: fmtMoney(verProc.precio_venta) },
                { label: 'Ciclo total', value: verProc.tiempo_ciclo_total_min != null ? `${verProc.tiempo_ciclo_total_min} min` : '—' },
              ].map(({ label, value }) => (
                <div key={label} className="kv-cell">
                  <div className="kv-label">{label}</div>
                  <div className="kv-value">{value}</div>
                </div>
              ))}
            </div>

            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
              <h3 style={{ fontSize: 14, fontWeight: 600, margin: 0 }}>Operaciones del proceso</h3>
              <button className="btn btn-sm btn-primary" onClick={openOpNew}>
                <Plus size={12} /> Agregar operación
              </button>
            </div>

            {!verProc.operaciones?.length
              ? <EmptyState title="Sin operaciones" desc='Agregá la primera operación con el botón "Agregar operación"' />
              : (
                <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {verProc.operaciones.map((op, idx) => (
                    <OpRow key={op.id} op={op} idx={idx}
                      onEdit={() => openOpEdit(op)}
                      onDelete={() => deleteOp(op)}
                      onHerramientas={() => setHerramientasOp(op)} />
                  ))}
                </div>
              )}
          </>
        )}
      </Modal>

      {/* Herramientas modal */}
      <HerramientasModal op={herramientasOp} onClose={() => setHerramientasOp(null)} />

      {/* Archivos modal */}
      <ArchivosModal prod={archivosProd} onClose={() => setArchivosProd(null)} />

      {/* Modal alta/edición de operación */}
      {verProc && (
        <OpForm
          open={opFormOpen}
          onClose={() => setOpFormOpen(false)}
          productoId={verProc.id}
          editing={editingOp}
          cats={catsMaq}
          maqs={maqs}
          mats={mats}
          provs={provs}
          onSaved={() => loadProc(verProc.id)}
        />
      )}

      {/* Modal copiar producto */}
      <Modal open={!!copyFrom} onClose={() => setCopyFrom(null)}
        title={copyFrom ? `Copiar producto: ${copyFrom.codigo}` : ''}
        footer={<>
          <button className="btn" onClick={() => setCopyFrom(null)}>Cancelar</button>
          <button className="btn btn-primary" onClick={doCopy}>Crear copia</button>
        </>}
      >
        <p style={{ fontSize: 13, color: 'var(--c-text-3)', marginBottom: 12 }}>
          Se copiarán las operaciones, materiales y configuración del producto.
        </p>
        <div className="form-grid">
          <Field label="Nuevo código" required>
            <input className="form-input" {...copyForm.bind('codigo')} placeholder="PROD-002" autoFocus />
          </Field>
          <Field label="Nuevo nombre">
            <input className="form-input" {...copyForm.bind('nombre')} />
          </Field>
        </div>
      </Modal>

      {/* Modal multi-cliente */}
      <Modal open={!!multiCli} onClose={() => setMultiCli(null)}
        title={multiCli ? `Clientes de: ${multiCli.codigo}` : ''}
        footer={<button className="btn" onClick={() => setMultiCli(null)}>Cerrar</button>}
      >
        <p style={{ fontSize: 13, color: 'var(--c-text-3)', marginBottom: 12 }}>
          Vinculá este producto a clientes adicionales (más allá del dueño).
          Solo los clientes vinculados podrán pedirlo en sus OCs.
        </p>
        <div style={{ display: 'flex', gap: 8, marginBottom: 16 }}>
          <select className="form-select" style={{ flex: 1 }} value={multiCliAdd} onChange={e => setMultiCliAdd(e.target.value)}>
            <option value="">— Seleccionar cliente para vincular —</option>
            {clientes.filter(c => !multiCliRows.some(r => r.id === c.id)).map(c => (
              <option key={c.id} value={c.id}>{c.razon}</option>
            ))}
          </select>
          <button className="btn btn-primary" onClick={linkCli} disabled={!multiCliAdd}>Vincular</button>
        </div>

        {multiCliRows.length === 0
          ? <p style={{ fontSize: 12, color: 'var(--c-text-3)', fontStyle: 'italic' }}>Sin clientes adicionales vinculados.</p>
          : (
            <table>
              <thead><tr><th>Cliente</th><th></th></tr></thead>
              <tbody>{multiCliRows.map(c => (
                <tr key={c.id}>
                  <td style={{ fontSize: 13 }}>{c.razon}</td>
                  <td style={{ textAlign: 'right' }}>
                    <button className="btn btn-xs btn-danger" onClick={() => unlinkCli(c.id)}>
                      <Trash2 size={10} /> Desvincular
                    </button>
                  </td>
                </tr>
              ))}</tbody>
            </table>
          )}
      </Modal>
    </div>
  )
}
