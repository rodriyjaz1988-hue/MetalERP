import { useState } from 'react'
import { Trash2, Shield } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field } from '../components/ui'
import type { BadgeVariant } from '../components/ui'

interface Usuario {
  id: number; username: string; nombre: string
  rol: string; activo: number; creado: string
}

const ROLES = ['admin', 'operario', 'vendedor', 'almacen']
const ROL_VARIANT: Record<string, BadgeVariant> = {
  admin: 'red', operario: 'blue', vendedor: 'green', almacen: 'amber',
}

// Same list of modules used in legacy — must match server's perm keys
const MODULOS = [
  { k: 'dash_operativo',    l: 'Dashboard Producción' },
  { k: 'dash_economico',    l: 'Dashboard Económico' },
  { k: 'ordenes',           l: 'Órdenes de trabajo' },
  { k: 'procesos',          l: 'Procesos / Productos' },
  { k: 'ctrl_prod',         l: 'Control de producción' },
  { k: 'novedades_ot',      l: 'Novedades por OT' },
  { k: 'mrp',               l: 'Planificación MRP' },
  { k: 'maquinas',          l: 'Máquinas' },
  { k: 'rrhh',              l: 'Recursos humanos' },
  { k: 'rendimiento',       l: 'Rendimiento operarios' },
  { k: 'inventario',        l: 'Inventario' },
  { k: 'movimientos',       l: 'Movimientos' },
  { k: 'lotes',             l: 'Lotes' },
  { k: 'remitir',           l: 'Remitir a cliente' },
  { k: 'presupuestos',      l: 'Presupuestos' },
  { k: 'clientes',          l: 'Clientes' },
  { k: 'oc_clientes',       l: 'Pedidos de clientes' },
  { k: 'solicitudes',       l: 'Compras' },
  { k: 'proveedores',       l: 'Proveedores' },
  { k: 'liberacion_lotes',  l: 'Liberación de lotes' },
  { k: 'ott',               l: 'OTT — Terceros' },
  { k: 'configuracion',     l: 'Configuración' },
  { k: 'carga_masiva',      l: 'Carga masiva' },
]

export default function UsuariosPage() {
  const toast = useToast()
  const { loading, reload, rows } = useResource<Usuario>({
    path: '/usuarios', errorMsg: 'Error cargando usuarios',
  })
  const [open, setOpen] = useState(false)
  const [permsFor, setPermsFor] = useState<Usuario | null>(null)
  const [perms, setPerms] = useState<Record<string, string>>({})
  const [permsLoading, setPermsLoading] = useState(false)
  const { values, bind, reset } = useForm({ username: '', password: '', nombre: '', rol: 'operario' })

  function openNew() {
    reset({ username: '', password: '', nombre: '', rol: 'operario' })
    setOpen(true)
  }

  async function save() {
    if (!values.username || !values.password || !values.nombre) {
      toast('Todos los campos requeridos', 'warn'); return
    }
    try {
      await api.post('/usuarios', values)
      toast('Usuario creado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function del(u: Usuario) {
    if (!window.confirm(`¿Eliminar al usuario ${u.username}? Esta acción es definitiva.`)) return
    try { await api.delete(`/usuarios/${u.id}`); toast('Usuario eliminado'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  async function openPerms(u: Usuario) {
    setPermsFor(u); setPermsLoading(true); setPerms({})
    try {
      const p = await api.get<Record<string, string>>(`/usuarios/${u.id}/permisos`)
      setPerms(p)
    } catch (e: any) { toast(e.message, 'error') }
    finally { setPermsLoading(false) }
  }

  function togglePerm(key: string) {
    setPerms(prev => ({ ...prev, [key]: prev[key] === '0' ? '1' : '0' }))
  }

  async function savePerms() {
    if (!permsFor) return
    const payload: Record<string, string> = {}
    MODULOS.forEach(m => { payload['mod_' + m.k] = perms['mod_' + m.k] === '0' ? '0' : '1' })
    payload['ver_monetario'] = perms['ver_monetario'] === '0' ? '0' : '1'
    try {
      await api.post(`/usuarios/${permsFor.id}/permisos`, payload)
      toast('Permisos guardados'); setPermsFor(null)
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Usuarios del sistema"
        onReload={reload} primaryLabel="Nuevo usuario" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : rows.length === 0
          ? <EmptyState title="Sin usuarios" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Usuario</th><th>Nombre</th><th>Rol</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{rows.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.username}</td>
                  <td style={{ fontSize: 13 }}>{r.nombre}</td>
                  <td><Badge value={r.rol} variant={ROL_VARIANT[r.rol] || 'gray'} /></td>
                  <td><Badge value={r.activo ? 'Activo' : 'Inactivo'} /></td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-xs" onClick={() => openPerms(r)} title="Permisos por módulo">
                        <Shield size={11} /> Permisos
                      </button>
                      <button className="btn btn-xs btn-danger" onClick={() => del(r)} title="Eliminar">
                        <Trash2 size={11} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Nuevo usuario"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Crear usuario</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Usuario" required>
            <input className="form-input" {...bind('username')} placeholder="jperez" />
          </Field>
          <Field label="Rol">
            <select className="form-select" {...bind('rol')}>
              {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
          </Field>
          <Field label="Nombre completo" required span2>
            <input className="form-input" {...bind('nombre')} />
          </Field>
          <Field label="Contraseña" required span2>
            <input className="form-input" type="password" {...bind('password')} />
          </Field>
        </div>
      </Modal>

      {/* Permisos modal */}
      <Modal open={!!permsFor} onClose={() => setPermsFor(null)}
        title={permsFor ? `Permisos: ${permsFor.username}` : ''} size="lg"
        footer={<>
          <button className="btn" onClick={() => setPermsFor(null)}>Cancelar</button>
          <button className="btn btn-primary" onClick={savePerms}>Guardar permisos</button>
        </>}
      >
        {permsLoading ? <PageLoading /> : (
          <>
            <p style={{ fontSize: 13, color: 'var(--c-text-3)', marginBottom: 12 }}>
              Marcá los módulos a los que este usuario puede acceder. Los administradores ven todos.
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 4 }}>
              {MODULOS.map(m => {
                const key = 'mod_' + m.k
                const checked = perms[key] !== '0'
                return (
                  <label key={m.k} style={{
                    display: 'flex', alignItems: 'center', gap: 6,
                    fontSize: 12, cursor: 'pointer', padding: '3px 0',
                  }}>
                    <input type="checkbox" checked={checked} onChange={() => togglePerm(key)} />
                    {m.l}
                  </label>
                )
              })}
            </div>
            <div style={{
              marginTop: 12, paddingTop: 10,
              borderTop: '1px solid var(--c-border)',
            }}>
              <label style={{ display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, cursor: 'pointer' }}>
                <input type="checkbox"
                  checked={perms['ver_monetario'] !== '0'}
                  onChange={() => togglePerm('ver_monetario')}
                  style={{ width: 15, height: 15 }} />
                Puede ver valores monetarios (precios, costos, facturación)
              </label>
            </div>
          </>
        )}
      </Modal>
    </div>
  )
}
