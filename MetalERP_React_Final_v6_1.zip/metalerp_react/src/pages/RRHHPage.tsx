import { useState } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field } from '../components/ui'

interface Emp {
  id: number; legajo: string; nombre: string; apellido: string | null
  cargo: string | null; tipo: 'Directo' | 'Indirecto'
  turno: string | null; activo: number; obs: string | null
}

const TIPOS = ['Directo', 'Indirecto']
const TURNOS = ['Mañana', 'Tarde', 'Noche', 'Rotativo']
const EMPTY = { legajo: '', nombre: '', apellido: '', cargo: '', tipo: 'Directo', turno: '', activo: 1, obs: '' }

export default function RRHHPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<Emp>({
    path: '/empleados', searchKeys: ['legajo', 'nombre', 'apellido'], errorMsg: 'Error cargando empleados',
  })
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Emp | null>(null)
  const { values, bind, reset, setValues } = useForm(EMPTY)

  function openNew() { setEditing(null); reset(EMPTY); setOpen(true) }
  function openEdit(e: Emp) {
    setEditing(e)
    reset({ legajo: e.legajo, nombre: e.nombre, apellido: e.apellido || '', cargo: e.cargo || '',
            tipo: e.tipo, turno: e.turno || '', activo: e.activo, obs: e.obs || '' })
    setOpen(true)
  }

  async function save() {
    if (!values.legajo || !values.nombre) { toast('Legajo y nombre requeridos', 'warn'); return }
    const body = { ...values, apellido: values.apellido || null }
    try {
      editing ? await api.put(`/empleados/${editing.id}`, body) : await api.post('/empleados', body)
      toast(editing ? 'Empleado actualizado' : 'Empleado registrado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Recursos humanos"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar empleado..."
        onReload={reload} primaryLabel="Nuevo empleado" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin empleados" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Legajo</th><th>Nombre completo</th><th>Cargo</th>
                <th>Tipo</th><th>Turno</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.legajo}</td>
                  <td style={{ fontSize: 13 }}>{r.nombre} {r.apellido || ''}</td>
                  <td style={{ fontSize: 12 }}>{r.cargo || '—'}</td>
                  <td><Badge value={r.tipo} /></td>
                  <td style={{ fontSize: 12 }}>{r.turno || '—'}</td>
                  <td><Badge value={r.activo ? 'Activo' : 'Inactivo'} /></td>
                  <td><button className="btn btn-xs" onClick={() => openEdit(r)}>Editar</button></td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar: ${editing.nombre}` : 'Nuevo empleado'}
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Legajo" required>
            <input className="form-input" {...bind('legajo')} placeholder="EMP-001" />
          </Field>
          <Field label="Tipo" hint="Directo: operario · Indirecto: admin, supervisor">
            <select className="form-select" {...bind('tipo')}>
              {TIPOS.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Nombre" required><input className="form-input" {...bind('nombre')} /></Field>
          <Field label="Apellido"><input className="form-input" {...bind('apellido')} /></Field>
          <Field label="Cargo"><input className="form-input" {...bind('cargo')} placeholder="Tornero, soldador..." /></Field>
          <Field label="Turno">
            <select className="form-select" {...bind('turno')}>
              <option value="">— Sin turno —</option>
              {TURNOS.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Observaciones" span2><textarea className="form-textarea" {...bind('obs')} /></Field>
          <div className="form-group col-span-2">
            <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer' }}>
              <input type="checkbox" checked={values.activo === 1}
                onChange={e => setValues(v => ({ ...v, activo: e.target.checked ? 1 : 0 }))}
                style={{ width: 16, height: 16 }} />
              <span style={{ fontSize: 13 }}>Empleado activo</span>
            </label>
          </div>
        </div>
      </Modal>
    </div>
  )
}
