import { useState } from 'react'
import { Plus, Pencil } from 'lucide-react'
import { api } from '../../api/client'
import { useToast } from '../../context/ToastContext'
import { useResource } from '../../hooks/useResource'
import { useForm } from '../../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Card, Field, fmtMoney } from '../../components/ui'
import type { BadgeVariant } from '../../components/ui'

interface Maq { id: number; codigo: string; nombre: string }
interface Ticket {
  id: number; numero: string; maquina_id: number; maquina_nombre: string; maquina_codigo: string
  tipo: string; descripcion: string; prioridad: string; estado: string
  responsable: string | null; horas_paro: number; costo: number
  solucion: string | null; creado: string; fecha_cierre: string | null
}

const TIPOS = ['Correctivo', 'Preventivo', 'Emergencia']
const PRIORIDADES = ['Baja', 'Normal', 'Alta', 'Crítica']
const ESTADOS = ['Abierto', 'En proceso', 'Cerrado']
const PRIO_VARIANT: Record<string, BadgeVariant> = { Crítica: 'red', Alta: 'amber', Normal: 'blue', Baja: 'gray' }
const FILTROS = ['', 'Abierto', 'En proceso', 'Cerrado']

const EMPTY = {
  maquina_id: '', tipo: 'Correctivo', descripcion: '', prioridad: 'Normal',
  estado: 'Abierto', responsable: '', horas_paro: '0', costo: '0', solucion: '',
}

export default function TicketsTab({ maqs }: { maqs: Maq[] }) {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('')
  const { loading, reload, rows } = useResource<Ticket>({
    path: estFilter ? `/tickets?estado=${estFilter}` : '/tickets',
    errorMsg: 'Error cargando tickets',
  })
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Ticket | null>(null)
  const { values, bind, reset } = useForm(EMPTY)

  function openNew() { setEditing(null); reset(EMPTY); setOpen(true) }
  function openEdit(t: Ticket) {
    setEditing(t)
    reset({
      maquina_id: String(t.maquina_id), tipo: t.tipo, descripcion: t.descripcion,
      prioridad: t.prioridad, estado: t.estado, responsable: t.responsable || '',
      horas_paro: String(t.horas_paro), costo: String(t.costo), solucion: t.solucion || '',
    })
    setOpen(true)
  }

  async function save() {
    if (!values.maquina_id || !values.descripcion) { toast('Máquina y descripción requeridas', 'warn'); return }
    const body = {
      ...values, maquina_id: Number(values.maquina_id),
      horas_paro: Number(values.horas_paro) || 0, costo: Number(values.costo) || 0,
    }
    try {
      editing ? await api.put(`/tickets/${editing.id}`, body) : await api.post('/tickets', body)
      toast(editing ? 'Ticket actualizado' : 'Ticket creado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <Card padded={false}>
      <div style={{ padding: '12px 16px', display: 'flex', gap: 8, justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--c-border)' }}>
        <div style={{ display: 'flex', gap: 4 }}>
          {FILTROS.map(f => (
            <button key={f || 'all'}
              className={`tab${estFilter === f ? ' active' : ''}`}
              style={{ padding: '4px 12px', fontSize: 12 }}
              onClick={() => setEstFilter(f)}>
              {f || 'Todos'}
            </button>
          ))}
        </div>
        <button className="btn btn-sm btn-primary" onClick={openNew}><Plus size={12} /> Nuevo ticket</button>
      </div>
      {loading ? <PageLoading /> : rows.length === 0
        ? <EmptyState title="Sin tickets" desc="No hay tickets de reparación con este filtro" />
        : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>N°</th><th>Máquina</th><th>Tipo</th><th>Descripción</th>
              <th>Prioridad</th><th>Estado</th><th>H. paro</th><th>Costo</th><th></th>
            </tr></thead>
            <tbody>{rows.map(r => (
              <tr key={r.id}>
                <td className="cell-mono">{r.numero}</td>
                <td style={{ fontSize: 12 }}><b>{r.maquina_codigo}</b> {r.maquina_nombre}</td>
                <td style={{ fontSize: 12 }}>{r.tipo}</td>
                <td className="cell-tight" style={{ maxWidth: 200 }}>{r.descripcion}</td>
                <td><Badge value={r.prioridad} variant={PRIO_VARIANT[r.prioridad]} /></td>
                <td><Badge value={r.estado} /></td>
                <td style={{ fontSize: 12 }}>{r.horas_paro ? `${r.horas_paro}h` : '—'}</td>
                <td style={{ fontSize: 12 }}>{r.costo ? fmtMoney(r.costo) : '—'}</td>
                <td>
                  <button className="btn btn-xs" onClick={() => openEdit(r)}><Pencil size={11} /></button>
                </td>
              </tr>
            ))}</tbody>
          </table></div>
        )}

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar ticket: ${editing.numero}` : 'Nuevo ticket de reparación'} size="lg"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar ticket</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Máquina" required>
            <select className="form-select" {...bind('maquina_id')} disabled={!!editing}>
              <option value="">— Seleccionar —</option>
              {maqs.map(m => <option key={m.id} value={m.id}>{m.codigo} — {m.nombre}</option>)}
            </select>
          </Field>
          <Field label="Tipo">
            <select className="form-select" {...bind('tipo')}>
              {TIPOS.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Descripción" required span2>
            <textarea className="form-textarea" {...bind('descripcion')} placeholder="Falla, síntomas, contexto..." />
          </Field>
          <Field label="Prioridad">
            <select className="form-select" {...bind('prioridad')}>
              {PRIORIDADES.map(p => <option key={p} value={p}>{p}</option>)}
            </select>
          </Field>
          <Field label="Estado">
            <select className="form-select" {...bind('estado')}>
              {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </Field>
          <Field label="Responsable"><input className="form-input" {...bind('responsable')} /></Field>
          <Field label="Horas de paro"><input className="form-input" type="number" min="0" step="0.5" {...bind('horas_paro')} /></Field>
          <Field label="Costo de reparación" span2>
            <input className="form-input" type="number" min="0" step="0.01" {...bind('costo')} />
          </Field>
          <Field label="Solución aplicada" span2>
            <textarea className="form-textarea" {...bind('solucion')} placeholder="Qué se hizo para resolver (al cerrar)" />
          </Field>
        </div>
      </Modal>
    </Card>
  )
}
