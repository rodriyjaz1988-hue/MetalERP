import { useState } from 'react'
import { Plus, Trash2, Pencil } from 'lucide-react'
import { api } from '../../api/client'
import { useToast } from '../../context/ToastContext'
import { useResource } from '../../hooks/useResource'
import { useForm } from '../../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Card, Field, fmtDate } from '../../components/ui'

interface Maq { id: number; codigo: string; nombre: string }
interface Mant {
  id: number; maquina_id: number; maquina_nombre: string; maquina_codigo: string
  tarea: string; tipo: string
  frecuencia_tipo: string | null; frecuencia_valor: number | null
  ultima_fecha: string | null; proxima_fecha: string | null
  responsable: string | null; obs: string | null
}

const TIPOS = ['Frecuencia fija', 'Preventivo', 'Predictivo', 'Por uso']
const FREC_TIPOS = ['días', 'semanas', 'meses', 'horas de uso']
const EMPTY = {
  maquina_id: '', tarea: '', tipo: 'Frecuencia fija',
  frecuencia_tipo: 'días', frecuencia_valor: '30',
  ultima_fecha: '', proxima_fecha: '', responsable: '', obs: '',
}

export default function MantenimientoTab({ maqs }: { maqs: Maq[] }) {
  const toast = useToast()
  const { loading, reload, rows } = useResource<Mant>({
    path: '/mantenimiento', errorMsg: 'Error cargando plan de mantenimiento',
  })
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<Mant | null>(null)
  const { values, bind, reset } = useForm(EMPTY)

  function openNew() { setEditing(null); reset(EMPTY); setOpen(true) }
  function openEdit(m: Mant) {
    setEditing(m)
    reset({
      maquina_id: String(m.maquina_id), tarea: m.tarea, tipo: m.tipo,
      frecuencia_tipo: m.frecuencia_tipo || 'días', frecuencia_valor: String(m.frecuencia_valor ?? '30'),
      ultima_fecha: m.ultima_fecha?.slice(0, 10) ?? '', proxima_fecha: m.proxima_fecha?.slice(0, 10) ?? '',
      responsable: m.responsable || '', obs: m.obs || '',
    })
    setOpen(true)
  }

  async function save() {
    if (!values.maquina_id || !values.tarea) { toast('Máquina y tarea requeridas', 'warn'); return }
    const body = {
      ...values, maquina_id: Number(values.maquina_id),
      frecuencia_valor: Number(values.frecuencia_valor) || null,
      ultima_fecha: values.ultima_fecha || null, proxima_fecha: values.proxima_fecha || null,
    }
    try {
      editing ? await api.put(`/mantenimiento/${editing.id}`, body) : await api.post('/mantenimiento', body)
      toast(editing ? 'Tarea actualizada' : 'Tarea creada')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function del(m: Mant) {
    if (!window.confirm(`¿Eliminar la tarea "${m.tarea}"?`)) return
    try { await api.delete(`/mantenimiento/${m.id}`); toast('Tarea eliminada'); reload() }
    catch (e: any) { toast(e.message, 'error') }
  }

  function proximaColor(fecha: string | null): string | undefined {
    if (!fecha) return undefined
    const days = (new Date(fecha).getTime() - Date.now()) / 86400000
    if (days < 0) return 'var(--c-red)'
    if (days <= 7) return 'var(--c-amber)'
    return undefined
  }

  return (
    <Card padded={false}>
      <div style={{ padding: '12px 16px', display: 'flex', justifyContent: 'flex-end', borderBottom: '1px solid var(--c-border)' }}>
        <button className="btn btn-sm btn-primary" onClick={openNew}><Plus size={12} /> Nueva tarea</button>
      </div>
      {loading ? <PageLoading /> : rows.length === 0
        ? <EmptyState title="Sin plan de mantenimiento" desc="Creá la primera tarea preventiva" />
        : (
          <div className="table-wrap"><table>
            <thead><tr>
              <th>Máquina</th><th>Tarea</th><th>Tipo</th><th>Frecuencia</th>
              <th>Última</th><th>Próxima</th><th>Responsable</th><th></th>
            </tr></thead>
            <tbody>{rows.map(r => (
              <tr key={r.id}>
                <td style={{ fontSize: 12 }}><b>{r.maquina_codigo}</b> {r.maquina_nombre}</td>
                <td style={{ fontSize: 13 }}>{r.tarea}</td>
                <td><Badge value={r.tipo} variant="blue" /></td>
                <td style={{ fontSize: 12 }}>
                  {r.frecuencia_valor ? `cada ${r.frecuencia_valor} ${r.frecuencia_tipo || ''}` : '—'}
                </td>
                <td style={{ fontSize: 12 }}>{fmtDate(r.ultima_fecha)}</td>
                <td style={{ fontSize: 12, fontWeight: 600, color: proximaColor(r.proxima_fecha) }}>
                  {fmtDate(r.proxima_fecha)}
                </td>
                <td style={{ fontSize: 12 }}>{r.responsable || '—'}</td>
                <td>
                  <div style={{ display: 'flex', gap: 4 }}>
                    <button className="btn btn-xs" onClick={() => openEdit(r)}><Pencil size={11} /></button>
                    <button className="btn btn-xs btn-danger" onClick={() => del(r)}><Trash2 size={11} /></button>
                  </div>
                </td>
              </tr>
            ))}</tbody>
          </table></div>
        )}

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? 'Editar tarea de mantenimiento' : 'Nueva tarea de mantenimiento'} size="lg"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar tarea</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Máquina" required>
            <select className="form-select" {...bind('maquina_id')}>
              <option value="">— Seleccionar —</option>
              {maqs.map(m => <option key={m.id} value={m.id}>{m.codigo} — {m.nombre}</option>)}
            </select>
          </Field>
          <Field label="Tipo">
            <select className="form-select" {...bind('tipo')}>
              {TIPOS.map(t => <option key={t} value={t}>{t}</option>)}
            </select>
          </Field>
          <Field label="Tarea" required span2>
            <input className="form-input" {...bind('tarea')} placeholder="Cambio de aceite, calibración..." />
          </Field>
          <Field label="Frecuencia (cada)">
            <input className="form-input" type="number" min="1" {...bind('frecuencia_valor')} />
          </Field>
          <Field label="Unidad de frecuencia">
            <select className="form-select" {...bind('frecuencia_tipo')}>
              {FREC_TIPOS.map(f => <option key={f} value={f}>{f}</option>)}
            </select>
          </Field>
          <Field label="Última realización"><input className="form-input" type="date" {...bind('ultima_fecha')} /></Field>
          <Field label="Próxima fecha"><input className="form-input" type="date" {...bind('proxima_fecha')} /></Field>
          <Field label="Responsable" span2><input className="form-input" {...bind('responsable')} /></Field>
          <Field label="Observaciones" span2><textarea className="form-textarea" {...bind('obs')} /></Field>
        </div>
      </Modal>
    </Card>
  )
}
