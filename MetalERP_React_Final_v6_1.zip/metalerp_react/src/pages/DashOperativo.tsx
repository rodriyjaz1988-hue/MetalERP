import { useEffect, useState } from 'react'
import {
  ClipboardList, AlertTriangle, Package, Wrench,
  TrendingUp, CheckCircle,
} from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { Badge, PageLoading, Card, StatCard, ProgressBar, EmptyState, fmtDate, rendimientoColor } from '../components/ui'

interface OTReciente {
  id: number; numero: string; producto_nombre: string | null
  descripcion: string; estado: string; fecha_entrega: string | null
  prioridad: number
}

interface DashOp {
  ot_activas: number
  ot_completadas_mes: number
  lotes_pendientes: number
  stock_critico: number
  maquinas_fuera: number
  ots_recientes: OTReciente[]
  ots_urgentes: OTReciente[]
  eficiencia_ops: { avg_rend: number; total_novedades: number } | null
}

interface RendSem {
  semanas: { semana: string; fecha_inicio: string; avg_rend: number; novedades: number; total_prod: number }[]
  semana_actual: string
}

export default function DashOperativo() {
  const toast = useToast()
  const [dash, setDash] = useState<DashOp | null>(null)
  const [rend, setRend] = useState<RendSem | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([api.get<DashOp>('/dashboard/operativo'), api.get<RendSem>('/dashboard/rendimiento_semanal')])
      .then(([d, r]) => { setDash(d); setRend(r) })
      .catch(() => toast('Error cargando dashboard', 'error'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <PageLoading />
  if (!dash) return null

  return (
    <div className="page">
      <h2 className="page-title">Dashboard Producción / Calidad</h2>

      <div className="grid-3">
        <StatCard label="OTs activas" value={dash.ot_activas} icon={<ClipboardList size={18} />} color="var(--c-primary)" />
        <StatCard label="Completadas (mes)" value={dash.ot_completadas_mes} icon={<CheckCircle size={18} />} color="var(--c-green)" />
        <StatCard label="Lotes pendientes" value={dash.lotes_pendientes} icon={<Package size={18} />} color="var(--c-amber)" />
        <StatCard label="Stock crítico" value={dash.stock_critico} icon={<AlertTriangle size={18} />} color="var(--c-red)" />
        <StatCard label="Máquinas fuera" value={dash.maquinas_fuera} icon={<Wrench size={18} />} color="#6B7280" />
        <StatCard
          label="Eficiencia promedio"
          value={dash.eficiencia_ops ? `${dash.eficiencia_ops.avg_rend}%` : '—'}
          icon={<TrendingUp size={18} />} color="var(--c-green)"
        />
      </div>

      <div className="grid-2">
        <Card title="OTs activas recientes">
          {dash.ots_recientes.length === 0
            ? <EmptyState title="" desc="Sin OTs activas" />
            : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>N° OT</th><th>Descripción</th><th>Estado</th><th>Entrega</th></tr></thead>
                  <tbody>
                    {dash.ots_recientes.slice(0, 8).map(o => (
                      <tr key={o.id}>
                        <td className="cell-mono">{o.numero}</td>
                        <td className="cell-tight" style={{ maxWidth: 160, fontSize: 12 }}>
                          {o.producto_nombre || o.descripcion}
                        </td>
                        <td><Badge value={o.estado} /></td>
                        <td style={{ fontSize: 12 }}>{fmtDate(o.fecha_entrega)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
        </Card>

        <Card title="⚠ OTs urgentes (próx. 5 días)">
          {dash.ots_urgentes.length === 0
            ? <EmptyState title="" desc="Sin entregas urgentes" />
            : (
              <div className="table-wrap">
                <table>
                  <thead><tr><th>N° OT</th><th>Producto</th><th>Entrega</th></tr></thead>
                  <tbody>
                    {dash.ots_urgentes.map(o => (
                      <tr key={o.id}>
                        <td className="cell-mono">{o.numero}</td>
                        <td style={{ fontSize: 12 }}>{o.producto_nombre || o.descripcion}</td>
                        <td>
                          <span style={{ color: 'var(--c-red)', fontWeight: 600, fontSize: 12 }}>
                            {fmtDate(o.fecha_entrega)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
        </Card>
      </div>

      <Card title="Rendimiento semanal — últimas 26 semanas">
        {!rend || rend.semanas.length === 0
          ? <EmptyState title="" desc="Sin novedades registradas en las últimas 26 semanas." />
          : (
            <div className="table-wrap">
              <table>
                <thead><tr>
                  <th>Semana</th>
                  <th style={{ minWidth: 220 }}>Rendimiento promedio</th>
                  <th>Novedades</th>
                  <th>Producido</th>
                </tr></thead>
                <tbody>
                  {rend.semanas.map(s => {
                    const pct = Math.min(s.avg_rend || 0, 100)
                    const isActual = s.semana === rend.semana_actual
                    const color = rendimientoColor(pct)
                    return (
                      <tr key={s.semana} style={{ background: isActual ? 'var(--c-primary-lt)' : undefined }}>
                        <td style={{
                          fontWeight: isActual ? 700 : undefined,
                          color: isActual ? 'var(--c-primary)' : undefined,
                          fontSize: 12, whiteSpace: 'nowrap',
                        }}>
                          {fmtDate(s.fecha_inicio)}{isActual ? ' ◀ actual' : ''}
                        </td>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <ProgressBar value={pct} color={color} />
                            <span style={{ fontSize: 12, fontWeight: 600, color, minWidth: 36 }}>{pct}%</span>
                          </div>
                        </td>
                        <td style={{ fontSize: 12, textAlign: 'center' }}>{s.novedades || 0}</td>
                        <td style={{ fontSize: 12, textAlign: 'center' }}>{s.total_prod || 0}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
          )}
      </Card>
    </div>
  )
}
