import { useState, useEffect } from 'react'
import { ArrowDown, ArrowUp } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, PageLoading, EmptyState, Toolbar, Card, Field, fmtDate } from '../components/ui'

type MovTipo = 'entrada' | 'salida' | 'ajuste'

interface Mov {
  id: number; fecha: string; tipo: MovTipo
  material_id: number; mat_codigo: string; mat_descripcion: string; mat_unidad: string
  lote_id: number | null; lote_numero: string | null
  cantidad: number; referencia: string | null; usuario_nombre: string | null
}

interface Material { id: number; codigo: string; descripcion: string; unidad: string; stock: number }

const TIPO_COLOR: Record<MovTipo, string> = { entrada: 'green', salida: 'red', ajuste: 'amber' }
const TIPO_PREFIX: Record<MovTipo, string> = { entrada: '+', salida: '−', ajuste: '±' }

function TipoIcon({ tipo }: { tipo: MovTipo }) {
  if (tipo === 'entrada') return <ArrowDown size={11} />
  if (tipo === 'salida') return <ArrowUp size={11} />
  return null
}

export default function MovimientosPage() {
  const toast = useToast()
  const [tipoFilter, setTipoFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<Mov>({
    path: '/movimientos',
    searchKeys: ['mat_codigo', 'mat_descripcion', 'referencia'],
    filter: r => !tipoFilter || r.tipo === tipoFilter,
    errorMsg: 'Error cargando movimientos',
  })
  const [mats, setMats] = useState<Material[]>([])
  const [open, setOpen] = useState(false)
  const { values, bind, reset } = useForm({ material_id: '', tipo: 'entrada', cantidad: '', referencia: '' })

  useEffect(() => { api.get<Material[]>('/materiales').then(setMats).catch(() => {}) }, [])

  function openNew() {
    reset({ material_id: '', tipo: 'entrada', cantidad: '', referencia: '' })
    setOpen(true)
  }

  async function save() {
    if (!values.material_id || !values.cantidad) { toast('Material y cantidad requeridos', 'warn'); return }
    const qty = Number(values.cantidad)
    if (qty <= 0) { toast('La cantidad debe ser mayor a 0', 'warn'); return }
    try {
      await api.post(`/materiales/${values.material_id}/movimiento`, {
        tipo: values.tipo, cantidad: qty, referencia: values.referencia || null,
      })
      toast('Movimiento registrado')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Movimientos de inventario"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar material..."
        onReload={reload}
        primaryLabel="Nuevo movimiento" onPrimary={openNew}
        rightChildren={
          <select className="form-select" style={{ width: 140 }} value={tipoFilter} onChange={e => setTipoFilter(e.target.value)}>
            <option value="">Todos los tipos</option>
            <option value="entrada">Entradas</option>
            <option value="salida">Salidas</option>
            <option value="ajuste">Ajustes</option>
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin movimientos" desc="Aún no hay movimientos de inventario registrados" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>Fecha</th><th>Tipo</th><th>Material</th><th>Lote</th>
                <th>Cantidad</th><th>Referencia</th><th>Usuario</th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const color = TIPO_COLOR[r.tipo]
                return (
                  <tr key={r.id}>
                    <td style={{ fontSize: 12 }}>{fmtDate(r.fecha)}</td>
                    <td>
                      <span className={`badge badge-${color}`} style={{ display: 'inline-flex', alignItems: 'center', gap: 3 }}>
                        <TipoIcon tipo={r.tipo} /> {r.tipo}
                      </span>
                    </td>
                    <td style={{ fontSize: 12 }}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                    <td className="cell-mono">{r.lote_numero || '—'}</td>
                    <td style={{
                      fontSize: 13, fontWeight: 600,
                      color: color === 'green' ? 'var(--c-green)' : color === 'red' ? 'var(--c-red)' : undefined,
                    }}>
                      {TIPO_PREFIX[r.tipo]}{Math.abs(r.cantidad)} {r.mat_unidad}
                    </td>
                    <td style={{ fontSize: 12 }}>{r.referencia || '—'}</td>
                    <td style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{r.usuario_nombre || '—'}</td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Registrar movimiento manual"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Registrar</button>
        </>}
      >
        <div className="alert-banner alert-info" style={{ marginBottom: 14 }}>
          Para ingresos de proveedor, usá <b>Lotes</b> en su lugar.
          Este formulario es para ajustes manuales o consumos directos.
        </div>
        <div className="form-grid">
          <Field label="Material" required span2>
            <select className="form-select" {...bind('material_id')}>
              <option value="">— Seleccionar material —</option>
              {mats.map(m => (
                <option key={m.id} value={m.id}>
                  {m.codigo} — {m.descripcion} (stock: {m.stock} {m.unidad})
                </option>
              ))}
            </select>
          </Field>
          <Field label="Tipo">
            <select className="form-select" {...bind('tipo')}>
              <option value="entrada">Entrada (+)</option>
              <option value="salida">Salida (−)</option>
              <option value="ajuste">Ajuste (fija stock)</option>
            </select>
          </Field>
          <Field label="Cantidad" required>
            <input className="form-input" type="number" min="0.001" step="0.001" {...bind('cantidad')} />
          </Field>
          <Field label="Referencia" span2 hint="Motivo, número de OT, factura...">
            <input className="form-input" {...bind('referencia')} />
          </Field>
        </div>
      </Modal>
    </div>
  )
}
