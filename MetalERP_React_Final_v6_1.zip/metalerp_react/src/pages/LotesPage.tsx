import { useState, useEffect } from 'react'
import { GitBranch } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, fmtDate } from '../components/ui'

interface Lote {
  id: number; numero: string; material_id: number
  mat_codigo: string; mat_descripcion: string; mat_unidad: string
  cantidad_original: number; cantidad_disponible: number; cantidad_activa: number
  estado: string; proveedor_id: number | null; proveedor_nombre: string | null
  referencia_proveedor: string | null; certificado: string | null; fecha_ingreso: string
}

interface Material { id: number; codigo: string; descripcion: string; unidad: string }

interface TrazMov {
  id: number; tipo: string; cantidad: number; referencia: string | null
  fecha: string; usuario_nombre: string | null
}
interface TrazOrden {
  id: number; ot_numero: string; ot_estado: string
  producto_nombre: string | null; cliente_nombre: string | null
  cantidad: number; mat_descripcion: string
}
interface Trazabilidad {
  lote: Lote
  movimientos: TrazMov[]
  ordenes: TrazOrden[]
}

const ESTADOS = ['Ingresado', 'Aprobado', 'Rechazado', 'Agotado']

export default function LotesPage() {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('')
  const { loading, search, setSearch, reload, filtered, rows: _rows } = useResource<Lote>({
    path: estFilter ? `/lotes?estado=${estFilter}` : '/lotes',
    searchKeys: ['numero', 'mat_codigo', 'mat_descripcion'],
    errorMsg: 'Error cargando lotes',
  })
  const [mats, setMats] = useState<Material[]>([])
  const [open, setOpen] = useState(false)
  const { values, bind, reset } = useForm({ material_id: '', cantidad: '', referencia_proveedor: '', certificado: '', obs: '' })

  // Trazabilidad
  const [traz, setTraz] = useState<Trazabilidad | null>(null)
  const [trazLoading, setTrazLoading] = useState(false)

  useEffect(() => { void _rows }, [_rows])

  async function openNew() {
    if (!mats.length) setMats(await api.get<Material[]>('/materiales?categoria=Material'))
    reset({ material_id: '', cantidad: '', referencia_proveedor: '', certificado: '', obs: '' })
    setOpen(true)
  }

  async function openTraz(lote: Lote) {
    setTraz({ lote, movimientos: [], ordenes: [] }); setTrazLoading(true)
    try { setTraz(await api.get<Trazabilidad>(`/lotes/${lote.id}/trazabilidad`)) }
    catch (e: any) { toast(e.message, 'error'); setTraz(null) }
    finally { setTrazLoading(false) }
  }

  async function save() {
    if (!values.material_id || !values.cantidad) { toast('Material y cantidad requeridos', 'warn'); return }
    try {
      await api.post('/lotes', {
        material_id: Number(values.material_id),
        cantidad: Number(values.cantidad),
        referencia_proveedor: values.referencia_proveedor || null,
        certificado: values.certificado || null,
      })
      toast('Lote creado'); setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Lotes"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar lote..."
        onReload={reload} primaryLabel="Nuevo lote" onPrimary={openNew}
        rightChildren={
          <select className="form-select" style={{ width: 160 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
            <option value="">Todos los estados</option>
            {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin lotes" desc="Ingresá el primer lote de materia prima" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>N° Lote</th><th>Material</th><th>Original</th><th>Disponible</th>
                <th>Aprobado</th><th>Sin aprobar</th><th>Proveedor</th><th>Certificado</th><th>Ingreso</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const sinAprobar = r.cantidad_disponible - r.cantidad_activa
                return (
                  <tr key={r.id}>
                    <td className="cell-mono">{r.numero}</td>
                    <td style={{ fontSize: 12 }}><b>{r.mat_codigo}</b> {r.mat_descripcion}</td>
                    <td style={{ fontSize: 12 }}>{r.cantidad_original} {r.mat_unidad}</td>
                    <td style={{ fontSize: 12, fontWeight: 600 }}>{r.cantidad_disponible}</td>
                    <td style={{ fontSize: 12, color: 'var(--c-green)', fontWeight: 600 }}>{r.cantidad_activa}</td>
                    <td style={{ fontSize: 12, color: sinAprobar > 0 ? 'var(--c-amber)' : 'var(--c-text-3)' }}>{sinAprobar.toFixed(2)}</td>
                    <td style={{ fontSize: 12 }}>{r.proveedor_nombre || r.referencia_proveedor || '—'}</td>
                    <td style={{ fontSize: 12 }}>{r.certificado || '—'}</td>
                    <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_ingreso)}</td>
                    <td><Badge value={r.estado} /></td>
                    <td>
                      <button className="btn btn-xs" onClick={() => openTraz(r)} title="Trazabilidad">
                        <GitBranch size={11} />
                      </button>
                    </td>
                  </tr>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)} title="Nuevo ingreso de lote"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Material" required span2>
            <select className="form-select" {...bind('material_id')}>
              <option value="">— Seleccionar —</option>
              {mats.map(m => <option key={m.id} value={m.id}>{m.codigo} — {m.descripcion}</option>)}
            </select>
          </Field>
          <Field label="Cantidad" required><input className="form-input" type="number" min="0.01" step="0.01" {...bind('cantidad')} /></Field>
          <Field label="Referencia proveedor"><input className="form-input" {...bind('referencia_proveedor')} /></Field>
          <Field label="Certificado" span2>
            <input className="form-input" {...bind('certificado')} placeholder="N° de certificado de calidad" />
          </Field>
        </div>
      </Modal>

      {/* Trazabilidad modal */}
      <Modal open={!!traz} onClose={() => setTraz(null)}
        title={traz ? `Trazabilidad — Lote ${traz.lote.numero}` : ''} size="xl"
        footer={<button className="btn" onClick={() => setTraz(null)}>Cerrar</button>}
      >
        {trazLoading ? <PageLoading /> : traz && (
          <>
            <div className="kv-grid kv-grid-3" style={{ marginBottom: 20 }}>
              {[
                { label: 'Material', value: `${traz.lote.mat_codigo} — ${traz.lote.mat_descripcion}` },
                { label: 'Cantidad original', value: `${traz.lote.cantidad_original} ${traz.lote.mat_unidad}` },
                { label: 'Estado', value: traz.lote.estado },
              ].map(({ label, value }) => (
                <div key={label} className="kv-cell">
                  <div className="kv-label">{label}</div>
                  <div className="kv-value" style={{ fontSize: 13 }}>{value}</div>
                </div>
              ))}
            </div>

            <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Movimientos del lote</h3>
            {traz.movimientos.length === 0
              ? <p style={{ fontSize: 12, color: 'var(--c-text-3)', fontStyle: 'italic', marginBottom: 16 }}>Sin movimientos registrados.</p>
              : (
                <table style={{ marginBottom: 20 }}>
                  <thead><tr><th>Fecha</th><th>Tipo</th><th>Cantidad</th><th>Referencia</th><th>Usuario</th></tr></thead>
                  <tbody>{traz.movimientos.map(m => (
                    <tr key={m.id}>
                      <td style={{ fontSize: 12 }}>{fmtDate(m.fecha)}</td>
                      <td><Badge value={m.tipo} variant={m.tipo === 'entrada' ? 'green' : m.tipo === 'salida' ? 'red' : 'amber'} /></td>
                      <td style={{ fontSize: 12 }}>{m.cantidad} {traz.lote.mat_unidad}</td>
                      <td style={{ fontSize: 12 }}>{m.referencia || '—'}</td>
                      <td style={{ fontSize: 11, color: 'var(--c-text-3)' }}>{m.usuario_nombre || '—'}</td>
                    </tr>
                  ))}</tbody>
                </table>
              )}

            <h3 style={{ fontSize: 14, fontWeight: 600, marginBottom: 8 }}>Órdenes de trabajo que consumieron este lote</h3>
            {traz.ordenes.length === 0
              ? <p style={{ fontSize: 12, color: 'var(--c-text-3)', fontStyle: 'italic' }}>Este lote no fue consumido por ninguna OT todavía.</p>
              : (
                <table>
                  <thead><tr><th>OT</th><th>Producto</th><th>Cliente</th><th>Cantidad usada</th><th>Estado OT</th></tr></thead>
                  <tbody>{traz.ordenes.map(o => (
                    <tr key={o.id}>
                      <td className="cell-mono">{o.ot_numero}</td>
                      <td style={{ fontSize: 12 }}>{o.producto_nombre || '—'}</td>
                      <td style={{ fontSize: 12 }}>{o.cliente_nombre || '—'}</td>
                      <td style={{ fontSize: 12 }}>{o.cantidad} {traz.lote.mat_unidad}</td>
                      <td><Badge value={o.ot_estado} /></td>
                    </tr>
                  ))}</tbody>
                </table>
              )}
          </>
        )}
      </Modal>
    </div>
  )
}
