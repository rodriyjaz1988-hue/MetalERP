import { useEffect, useState, useMemo } from 'react'
import { DollarSign, ShoppingCart, FileText, Users } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { PageLoading, Card, StatCard, ProgressBar, EmptyState, fmtMoney } from '../components/ui'

interface DashEco {
  facturacion_mes: number; valor_pedidos: number
  compras_pendientes: number; monto_compras_pend: number; pedidos_activos: number
  top_clientes: { cliente: string; total: number }[]
}

interface CliData {
  anio: number; mes_actual: string
  facturado: { mes: string; cliente: string; total: number }[]
  pedidos:   { mes: string; cliente: string; total: number }[]
  empleados: { tipo: string; cantidad: number }[]
}

const CHART_COLORS = [
  'var(--c-chart-1)', 'var(--c-chart-2)', 'var(--c-chart-3)', 'var(--c-chart-4)',
  'var(--c-chart-5)', 'var(--c-chart-6)', 'var(--c-chart-7)', 'var(--c-chart-8)',
]

export default function DashEconomico() {
  const toast = useToast()
  const [dash, setDash] = useState<DashEco | null>(null)
  const [cliData, setCliData] = useState<CliData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([
      api.get<DashEco>('/dashboard/economico'),
      api.get<CliData>('/dashboard/facturacion_por_cliente'),
    ])
      .then(([d, c]) => { setDash(d); setCliData(c) })
      .catch(() => toast('Error cargando dashboard', 'error'))
      .finally(() => setLoading(false))
  }, [])

  // Aggregate chart data once per cliData change
  const chartData = useMemo(() => {
    if (!cliData) return null
    const meses = Array.from({ length: 12 }, (_, i) => `${cliData.anio}-${String(i + 1).padStart(2, '0')}`)
    const clientes = [...new Set([
      ...cliData.facturado.map(r => r.cliente),
      ...cliData.pedidos.map(r => r.cliente),
    ])].slice(0, 8)

    const byKey: Record<string, { fact: number; ped: number }> = {}
    cliData.facturado.forEach(r => { byKey[`${r.mes}|${r.cliente}`] = { fact: r.total, ped: 0 } })
    cliData.pedidos.forEach(r => {
      const k = `${r.mes}|${r.cliente}`
      if (byKey[k]) byKey[k].ped = r.total
      else byKey[k] = { fact: 0, ped: r.total }
    })

    const maxVal = meses.reduce((mx, m) => {
      const s = clientes.reduce((a, c) => {
        const v = byKey[`${m}|${c}`]
        return a + (v?.fact || 0) + (v?.ped || 0)
      }, 0)
      return Math.max(mx, s)
    }, 1)

    return { meses, clientes, byKey, maxVal }
  }, [cliData])

  if (loading) return <PageLoading />
  if (!dash) return null

  return (
    <div className="page">
      <h2 className="page-title">Dashboard Económico / Financiero</h2>

      <div className="grid-4">
        <StatCard label="Facturación del mes" value={fmtMoney(dash.facturacion_mes)} sub="presupuestos facturados" icon={<DollarSign size={18} />} color="var(--c-green)" />
        <StatCard label="Valor pedidos activos" value={fmtMoney(dash.valor_pedidos)} sub="en producción" icon={<FileText size={18} />} color="var(--c-primary)" />
        <StatCard label="Compras pendientes" value={dash.compras_pendientes} sub={`${fmtMoney(dash.monto_compras_pend)} en OCs`} icon={<ShoppingCart size={18} />} color="var(--c-amber)" />
        <StatCard label="Pedidos de clientes" value={dash.pedidos_activos} sub="activos" icon={<Users size={18} />} color="var(--c-chart-5)" />
      </div>

      {/* Chart: facturación + pedidos por cliente, mes a mes */}
      {chartData && chartData.clientes.length > 0 && cliData && (
        <Card title={`Facturación por cliente — ${cliData.anio}`}>
          {/* Legend */}
          <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap', marginBottom: 12 }}>
            {chartData.clientes.map((c, i) => (
              <span key={c} style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 11 }}>
                <span style={{ width: 10, height: 10, borderRadius: 2, background: CHART_COLORS[i % CHART_COLORS.length], display: 'inline-block' }} />
                {c}
              </span>
            ))}
          </div>
          {/* Stacked bar chart */}
          <div style={{ display: 'flex', gap: 3, alignItems: 'flex-end', height: 130, overflowX: 'auto', paddingBottom: 28, position: 'relative' }}>
            {chartData.meses.map(m => {
              const isPast = m < cliData.mes_actual
              const isCur = m === cliData.mes_actual
              return (
                <div key={m} style={{ flex: 1, minWidth: 28, display: 'flex', flexDirection: 'column', justifyContent: 'flex-end', alignItems: 'center', position: 'relative' }}>
                  {chartData.clientes.map((c, ci) => {
                    const v = (chartData.byKey[`${m}|${c}`]?.fact || 0) + (chartData.byKey[`${m}|${c}`]?.ped || 0)
                    if (!v) return null
                    const h = Math.round((v / chartData.maxVal) * 110)
                    const color = CHART_COLORS[ci % CHART_COLORS.length]
                    return (
                      <div key={c} title={`${c}: ${fmtMoney(v)}`} style={{
                        width: '100%', height: h,
                        background: isPast ? color : 'transparent',
                        border: isPast ? 'none' : `2px dashed ${color}`,
                        boxSizing: 'border-box',
                      }} />
                    )
                  })}
                  <span style={{
                    position: 'absolute', bottom: -20, fontSize: 9,
                    color: isCur ? 'var(--c-primary)' : 'var(--c-text-3)',
                    fontWeight: isCur ? 700 : 400, whiteSpace: 'nowrap',
                  }}>
                    {m.slice(5)}{isCur ? ' ◀' : ''}
                  </span>
                </div>
              )
            })}
          </div>
        </Card>
      )}

      <div className="grid-2">
        <Card title="Top clientes">
          {!dash.top_clientes?.length
            ? <EmptyState title="" desc="Sin datos" />
            : (
              <table>
                <thead><tr><th>Cliente</th><th>Total</th></tr></thead>
                <tbody>{dash.top_clientes.map(c => (
                  <tr key={c.cliente}>
                    <td style={{ fontSize: 13 }}>{c.cliente}</td>
                    <td style={{ fontSize: 13 }}><b>{fmtMoney(c.total)}</b></td>
                  </tr>
                ))}</tbody>
              </table>
            )
          }
        </Card>

        <Card title="Ratio empleados">
          {!cliData?.empleados?.length
            ? <EmptyState title="" desc="Sin empleados registrados" />
            : (() => {
                const total = cliData.empleados.reduce((s, e) => s + e.cantidad, 0)
                return (
                  <table>
                    <thead><tr><th>Tipo</th><th>Cantidad</th><th>%</th></tr></thead>
                    <tbody>{cliData.empleados.map(e => {
                      const pct = Math.round(e.cantidad / total * 100)
                      return (
                        <tr key={e.tipo}>
                          <td style={{ fontSize: 13 }}>{e.tipo}</td>
                          <td style={{ fontSize: 13 }}><b>{e.cantidad}</b></td>
                          <td style={{ minWidth: 100 }}>
                            <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                              <ProgressBar value={pct} />
                              <span style={{ fontSize: 11 }}>{pct}%</span>
                            </div>
                          </td>
                        </tr>
                      )
                    })}</tbody>
                  </table>
                )
              })()
          }
        </Card>
      </div>
    </div>
  )
}
