import { useState, useEffect } from 'react'
import { FileText, Package, Pencil } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import { Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field, ProgressBar, fmtDate, fmtMoney } from '../components/ui'

interface OT {
  id: number; numero: string; descripcion: string
  producto_id: number | null; producto_nombre: string | null; producto_codigo: string | null
  cliente_id: number | null; cliente_nombre: string | null
  cantidad: number; estado: string; prioridad: number
  fecha_inicio: string | null; fecha_entrega: string | null
  costo_mat: number; costo_mo: number
}

interface Producto { id: number; codigo: string; nombre: string }
interface Cliente { id: number; razon: string }

interface OTMaterial {
  material_id: number; codigo: string; descripcion: string; unidad: string; stock: number
  cantidad_requerida: number; cantidad_asignada: number
}

interface LoteAprobado {
  id: number; numero: string; cantidad_disponible: number; cantidad_activa: number
}

const ESTADOS = ['Pendiente', 'En proceso', 'Completada', 'Cancelada']
const EMPTY = {
  descripcion: '', producto_id: '', cliente_id: '', cantidad: '1',
  prioridad: '3', estado: 'Pendiente', fecha_inicio: '', fecha_entrega: '',
}

function prioColor(p: number) {
  return p >= 4 ? 'var(--c-red)' : p === 3 ? 'var(--c-amber)' : 'var(--c-text-3)'
}

export default function OrdenesPage() {
  const toast = useToast()
  const [estFilter, setEstFilter] = useState('')
  const { loading, search, setSearch, reload, filtered } = useResource<OT>({
    path: estFilter ? `/ordenes?estado=${estFilter}` : '/ordenes',
    searchKeys: ['numero', 'descripcion', 'producto_nombre'],
    errorMsg: 'Error cargando OTs',
  })
  const [prods, setProds] = useState<Producto[]>([])
  const [clientes, setClientes] = useState<Cliente[]>([])
  const [open, setOpen] = useState(false)
  const [editing, setEditing] = useState<OT | null>(null)
  const { values, bind, reset } = useForm(EMPTY)

  // Materials modal
  const [matsOT, setMatsOT] = useState<OT | null>(null)
  const [mats, setMats] = useState<OTMaterial[]>([])
  const [matsLoading, setMatsLoading] = useState(false)
  const [asignMat, setAsignMat] = useState<OTMaterial | null>(null)
  const [lotes, setLotes] = useState<LoteAprobado[]>([])
  const asignForm = useForm({ lote_id: '', cantidad: '' })

  useEffect(() => {
    Promise.all([api.get<Producto[]>('/productos'), api.get<Cliente[]>('/clientes')])
      .then(([p, c]) => { setProds(p); setClientes(c) })
      .catch(() => {})
  }, [])

  async function openMats(ot: OT) {
    setMatsOT(ot); setMatsLoading(true); setMats([])
    try {
      const m = await api.get<OTMaterial[]>(`/ordenes/${ot.id}/materiales`)
      setMats(m)
    } catch (e: any) { toast(e.message, 'error') }
    finally { setMatsLoading(false) }
  }

  async function populateMats() {
    if (!matsOT) return
    try {
      await api.post(`/ordenes/${matsOT.id}/materiales/populate`, {})
      toast('Materiales calculados desde el proceso')
      openMats(matsOT)
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function openAsignar(mat: OTMaterial) {
    setAsignMat(mat)
    asignForm.reset({ lote_id: '', cantidad: String(mat.cantidad_requerida - mat.cantidad_asignada) })
    try {
      const l = await api.get<LoteAprobado[]>(`/materiales/${mat.material_id}/lotes_aprobados`)
      setLotes(l)
    } catch { setLotes([]) }
  }

  async function doAsignar() {
    if (!matsOT || !asignMat) return
    const qty = Number(asignForm.values.cantidad)
    if (qty <= 0) { toast('Cantidad inválida', 'warn'); return }
    try {
      if (asignForm.values.lote_id) {
        // Asignar desde lote específico
        await api.post(`/ordenes/${matsOT.id}/materiales/${asignMat.material_id}/asignar_lote`, {
          lote_id: Number(asignForm.values.lote_id), cantidad: qty,
        })
      } else {
        // Asignar desde stock general
        await api.post(`/ordenes/${matsOT.id}/materiales/${asignMat.material_id}/asignar`, {
          cantidad: qty,
        })
      }
      toast('Material asignado')
      setAsignMat(null)
      openMats(matsOT)
    } catch (e: any) { toast(e.message, 'error') }
  }

  function openNew() { setEditing(null); reset(EMPTY); setOpen(true) }
  function openEdit(ot: OT) {
    setEditing(ot)
    reset({
      descripcion: ot.descripcion, producto_id: String(ot.producto_id ?? ''),
      cliente_id: String(ot.cliente_id ?? ''), cantidad: String(ot.cantidad),
      prioridad: String(ot.prioridad), estado: ot.estado,
      fecha_inicio: ot.fecha_inicio?.slice(0, 10) ?? '',
      fecha_entrega: ot.fecha_entrega?.slice(0, 10) ?? '',
    })
    setOpen(true)
  }

  async function save() {
    const body = {
      descripcion: values.descripcion,
      producto_id: values.producto_id || null,
      cliente_id: values.cliente_id || null,
      cantidad: Number(values.cantidad),
      prioridad: Number(values.prioridad),
      estado: values.estado,
      fecha_inicio: values.fecha_inicio || null,
      fecha_entrega: values.fecha_entrega || null,
    }
    try {
      editing
        ? await api.put(`/ordenes/${editing.id}`, body)
        : await api.post('/ordenes', body)
      toast(editing ? 'OT actualizada' : 'OT creada')
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Órdenes de trabajo"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar OT..."
        onReload={reload} primaryLabel="Nueva OT" onPrimary={openNew}
        rightChildren={
          <select className="form-select" style={{ width: 160 }} value={estFilter} onChange={e => setEstFilter(e.target.value)}>
            <option value="">Todos los estados</option>
            {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
          </select>
        }
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin órdenes" desc="Creá la primera OT con el botón Nueva OT" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th>N° OT</th><th>Descripción</th><th>Producto</th><th>Cliente</th>
                <th>Cant.</th><th>Prioridad</th><th>Estado</th>
                <th>F. inicio</th><th>F. entrega</th><th>Costo</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => (
                <tr key={r.id}>
                  <td className="cell-mono">{r.numero}</td>
                  <td className="cell-tight" style={{ maxWidth: 180, fontSize: 13 }}>{r.descripcion}</td>
                  <td style={{ fontSize: 12 }}>
                    {r.producto_codigo ? <><b>{r.producto_codigo}</b> {r.producto_nombre}</> : '—'}
                  </td>
                  <td style={{ fontSize: 12 }}>{r.cliente_nombre || '—'}</td>
                  <td style={{ textAlign: 'center' }}>{r.cantidad}</td>
                  <td style={{ textAlign: 'center' }}>
                    <span style={{ fontWeight: 700, color: prioColor(r.prioridad), fontSize: 16 }}>
                      {'★'.repeat(r.prioridad)}
                    </span>
                  </td>
                  <td><Badge value={r.estado} /></td>
                  <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_inicio)}</td>
                  <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_entrega)}</td>
                  <td style={{ fontSize: 12 }}>{fmtMoney((r.costo_mat || 0) + (r.costo_mo || 0))}</td>
                  <td>
                    <div style={{ display: 'flex', gap: 4 }}>
                      <button className="btn btn-xs" onClick={() => openEdit(r)} title="Editar"><Pencil size={11} /></button>
                      <button className="btn btn-xs" onClick={() => openMats(r)} title="Materiales"><Package size={11} /></button>
                      <a className="btn btn-xs" href={`/api/ordenes/${r.id}/pdf`} target="_blank" rel="noopener noreferrer"
                        title="Ver PDF" style={{ textDecoration: 'none' }}>
                        <FileText size={11} />
                      </a>
                    </div>
                  </td>
                </tr>
              ))}</tbody>
            </table></div>
          )}
      </Card>

      <Modal open={open} onClose={() => setOpen(false)}
        title={editing ? `Editar OT ${editing.numero}` : 'Nueva orden de trabajo'} size="lg"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Guardar</button>
        </>}
      >
        <div className="form-grid">
          <Field label="Descripción" required span2>
            <input className="form-input" {...bind('descripcion')} placeholder="Ej: Fabricación de brida DN150" />
          </Field>
          <Field label="Producto">
            <select className="form-select" {...bind('producto_id')}>
              <option value="">— Sin producto —</option>
              {prods.map(p => <option key={p.id} value={p.id}>{p.codigo} — {p.nombre}</option>)}
            </select>
          </Field>
          <Field label="Cliente">
            <select className="form-select" {...bind('cliente_id')}>
              <option value="">— Sin cliente —</option>
              {clientes.map(c => <option key={c.id} value={c.id}>{c.razon}</option>)}
            </select>
          </Field>
          <Field label="Cantidad" required>
            <input className="form-input" type="number" min="1" step="1" {...bind('cantidad')} />
          </Field>
          <Field label="Estado">
            <select className="form-select" {...bind('estado')}>
              {ESTADOS.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </Field>
          <Field label="Prioridad (1=baja, 5=crítica)">
            <select className="form-select" {...bind('prioridad')}>
              {[1, 2, 3, 4, 5].map(n => <option key={n} value={n}>{'★'.repeat(n)} — {n}</option>)}
            </select>
          </Field>
          <Field label="Fecha inicio"><input className="form-input" type="date" {...bind('fecha_inicio')} /></Field>
          <Field label="Fecha entrega"><input className="form-input" type="date" {...bind('fecha_entrega')} /></Field>
        </div>
      </Modal>

      {/* Materials modal */}
      <Modal open={!!matsOT} onClose={() => setMatsOT(null)}
        title={matsOT ? `Materiales — ${matsOT.numero}` : ''} size="lg"
        footer={<>
          <button className="btn" onClick={populateMats} title="Recalcular desde el proceso del producto">
            Recalcular desde proceso
          </button>
          <button className="btn btn-primary" onClick={() => setMatsOT(null)}>Cerrar</button>
        </>}
      >
        {matsLoading ? <PageLoading /> : mats.length === 0
          ? <EmptyState title="Sin materiales"
              desc='Usá "Recalcular desde proceso" para poblar los materiales según el producto de la OT' />
          : (
            <table>
              <thead><tr>
                <th>Material</th><th>Requerido</th><th>Asignado</th>
                <th style={{ minWidth: 120 }}>Cobertura</th><th></th>
              </tr></thead>
              <tbody>{mats.map(m => {
                const cov = m.cantidad_requerida > 0
                  ? Math.round(m.cantidad_asignada / m.cantidad_requerida * 100) : 0
                const completo = cov >= 100
                return (
                  <tr key={m.material_id}>
                    <td style={{ fontSize: 12 }}>
                      <b>{m.codigo}</b> {m.descripcion}
                      <div style={{ fontSize: 10, color: 'var(--c-text-3)' }}>
                        Stock disponible: {m.stock} {m.unidad}
                      </div>
                    </td>
                    <td style={{ fontSize: 12 }}>{m.cantidad_requerida} {m.unidad}</td>
                    <td style={{ fontSize: 12 }}>{m.cantidad_asignada}</td>
                    <td>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                        <ProgressBar value={cov} color={completo ? 'var(--c-green)' : 'var(--c-amber)'} />
                        <span style={{ fontSize: 11, fontWeight: 600 }}>{cov}%</span>
                      </div>
                    </td>
                    <td>
                      {!completo && (
                        <button className="btn btn-xs btn-primary" onClick={() => openAsignar(m)}>
                          Asignar
                        </button>
                      )}
                    </td>
                  </tr>
                )
              })}</tbody>
            </table>
          )}
      </Modal>

      {/* Asignar material modal */}
      <Modal open={!!asignMat} onClose={() => setAsignMat(null)}
        title={asignMat ? `Asignar: ${asignMat.codigo}` : ''}
        footer={<>
          <button className="btn" onClick={() => setAsignMat(null)}>Cancelar</button>
          <button className="btn btn-primary" onClick={doAsignar}>Asignar</button>
        </>}
      >
        {asignMat && (
          <div className="form-grid">
            <Field label="Lote aprobado (opcional)" span2
              hint={lotes.length === 0 ? 'No hay lotes aprobados — se descontará del stock general' : 'Dejá vacío para usar stock general'}>
              <select className="form-select" {...asignForm.bind('lote_id')}>
                <option value="">— Stock general —</option>
                {lotes.map(l => (
                  <option key={l.id} value={l.id}>
                    {l.numero} (disp: {(l.cantidad_disponible - l.cantidad_activa).toFixed(2)})
                  </option>
                ))}
              </select>
            </Field>
            <Field label="Cantidad a asignar" required span2>
              <input className="form-input" type="number" min="0.001" step="0.001" autoFocus {...asignForm.bind('cantidad')} />
            </Field>
          </div>
        )}
      </Modal>
    </div>
  )
}
