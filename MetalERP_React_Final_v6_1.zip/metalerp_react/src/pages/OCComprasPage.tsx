import { useState, useEffect, Fragment } from 'react'
import { ChevronDown, ChevronRight, Plus, Trash2, CheckCircle, PackageCheck } from 'lucide-react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import { useResource } from '../hooks/useResource'
import { useForm } from '../hooks/useForm'
import {
  Modal, Badge, PageLoading, EmptyState, Toolbar, Card, Field,
  fmtDate, fmtMoney,
} from '../components/ui'

interface OCItem {
  id: number; material_id: number | null
  mat_codigo: string | null; mat_desc: string | null
  descripcion_libre: string | null
  cantidad: number; cantidad_recibida: number
  precio_unit: number; unidad: string
}

interface OC {
  id: number; numero: string; proveedor_id: number; proveedor_nombre: string
  estado: string; monto_total: number
  creado: string; fecha_aprobacion: string | null
  fecha_entrega_est: string | null
  creado_por_nombre: string | null; aprobado_por_nombre: string | null
  obs: string | null
  items: OCItem[]
}

interface Material { id: number; codigo: string; descripcion: string; unidad: string; precio_unit: number }
interface Proveedor { id: number; razon: string }

interface OCItemForm {
  material_id: string; descripcion_libre: string
  cantidad: string; precio_unit: string; unidad: string
}

const EMPTY_ITEM: OCItemForm = { material_id: '', descripcion_libre: '', cantidad: '1', precio_unit: '0', unidad: 'unid' }

export default function OCComprasPage() {
  const toast = useToast()
  const { loading, search, setSearch, reload, filtered } = useResource<OC>({
    path: '/ordenes_compra',
    searchKeys: ['numero', 'proveedor_nombre'],
    errorMsg: 'Error cargando órdenes de compra',
  })
  const [expanded, setExpanded] = useState<Set<number>>(new Set())
  const [mats, setMats] = useState<Material[]>([])
  const [provs, setProvs] = useState<Proveedor[]>([])
  const [open, setOpen] = useState(false)
  const [recvOC, setRecvOC] = useState<OC | null>(null)
  const [recvQtys, setRecvQtys] = useState<Record<number, string>>({})
  const ocForm = useForm({ proveedor_id: '', fecha_entrega_est: '', obs: '' })
  const [items, setItems] = useState<OCItemForm[]>([{ ...EMPTY_ITEM }])

  useEffect(() => {
    Promise.all([api.get<Material[]>('/materiales'), api.get<Proveedor[]>('/proveedores')])
      .then(([m, p]) => { setMats(m); setProvs(p) })
      .catch(() => {})
  }, [])

  const toggle = (id: number) =>
    setExpanded(prev => {
      const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n
    })

  function openNew() {
    ocForm.reset({ proveedor_id: '', fecha_entrega_est: '', obs: '' })
    setItems([{ ...EMPTY_ITEM }])
    setOpen(true)
  }

  function addItem() { setItems(prev => [...prev, { ...EMPTY_ITEM }]) }
  function removeItem(idx: number) { setItems(prev => prev.filter((_, i) => i !== idx)) }
  function updateItem(idx: number, patch: Partial<OCItemForm>) {
    setItems(prev => prev.map((it, i) => i === idx ? { ...it, ...patch } : it))
  }
  function selectMat(idx: number, matId: string) {
    const m = mats.find(x => String(x.id) === matId)
    updateItem(idx, {
      material_id: matId,
      unidad: m?.unidad ?? 'unid',
      precio_unit: m ? String(m.precio_unit) : '0',
    })
  }

  async function save() {
    if (!ocForm.values.proveedor_id) { toast('Proveedor requerido', 'warn'); return }
    const validItems = items.filter(i => Number(i.cantidad) > 0 && (i.material_id || i.descripcion_libre))
    if (validItems.length === 0) { toast('Agregá al menos un ítem', 'warn'); return }
    try {
      const r = await api.post<{ numero: string; estado: string }>('/ordenes_compra', {
        proveedor_id: Number(ocForm.values.proveedor_id),
        fecha_entrega_est: ocForm.values.fecha_entrega_est || null,
        obs: ocForm.values.obs,
        items: validItems.map(i => ({
          material_id: i.material_id ? Number(i.material_id) : null,
          descripcion_libre: i.descripcion_libre || null,
          cantidad: Number(i.cantidad),
          precio_unit: Number(i.precio_unit),
          unidad: i.unidad,
        })),
      })
      toast(`OC ${r.numero} creada — Estado: ${r.estado}`)
      setOpen(false); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  async function aprobar(oc: OC) {
    if (!window.confirm(`¿Aprobar la OC ${oc.numero} por ${fmtMoney(oc.monto_total)}?`)) return
    try {
      await api.post(`/ordenes_compra/${oc.id}/aprobar`, {})
      toast('OC aprobada'); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  function openRecv(oc: OC) {
    setRecvOC(oc)
    const init: Record<number, string> = {}
    oc.items.forEach(i => {
      init[i.id] = String(Math.max(0, i.cantidad - (i.cantidad_recibida || 0)))
    })
    setRecvQtys(init)
  }

  async function saveRecv() {
    if (!recvOC) return
    const recItems = Object.entries(recvQtys)
      .filter(([, qty]) => Number(qty) > 0)
      .map(([itemId, qty]) => ({ item_id: Number(itemId), cantidad: Number(qty) }))
    if (recItems.length === 0) { toast('Ingresá cantidades a recibir', 'warn'); return }
    try {
      await api.post(`/ordenes_compra/${recvOC.id}/recibir`, { items: recItems })
      toast('Recepción registrada')
      setRecvOC(null); reload()
    } catch (e: any) { toast(e.message, 'error') }
  }

  return (
    <div className="page">
      <Toolbar
        title="Órdenes de compra a proveedores"
        search={search} onSearch={setSearch} searchPlaceholder="Buscar OC, proveedor..."
        onReload={reload} primaryLabel="Nueva OC" onPrimary={openNew}
      />

      <Card padded={false}>
        {loading ? <PageLoading /> : filtered.length === 0
          ? <EmptyState title="Sin OCs de compra" desc="Creá la primera orden de compra a un proveedor" />
          : (
            <div className="table-wrap"><table>
              <thead><tr>
                <th style={{ width: 36 }}></th>
                <th>N°</th><th>Proveedor</th><th>Fecha</th>
                <th>Entrega est.</th><th>Total</th><th>Estado</th><th></th>
              </tr></thead>
              <tbody>{filtered.map(r => {
                const isExp = expanded.has(r.id)
                const totalRecv = r.items.reduce((s, i) => s + (i.cantidad_recibida || 0), 0)
                const totalQty = r.items.reduce((s, i) => s + i.cantidad, 0)
                const fullyReceived = totalQty > 0 && totalRecv >= totalQty
                return (
                  <Fragment key={r.id}>
                    <tr>
                      <td style={{ textAlign: 'center', cursor: 'pointer' }} onClick={() => toggle(r.id)}>
                        {isExp ? <ChevronDown size={13} /> : <ChevronRight size={13} />}
                      </td>
                      <td className="cell-mono">{r.numero}</td>
                      <td style={{ fontSize: 13 }}>{r.proveedor_nombre}</td>
                      <td style={{ fontSize: 12 }}>{fmtDate(r.creado)}</td>
                      <td style={{ fontSize: 12 }}>{fmtDate(r.fecha_entrega_est)}</td>
                      <td style={{ fontSize: 13, fontWeight: 600 }}>{fmtMoney(r.monto_total)}</td>
                      <td><Badge value={r.estado} /></td>
                      <td>
                        <div style={{ display: 'flex', gap: 4 }}>
                          {r.estado === 'Pendiente aprobacion' && (
                            <button className="btn btn-xs btn-primary" onClick={() => aprobar(r)} title="Aprobar">
                              <CheckCircle size={11} /> Aprobar
                            </button>
                          )}
                          {(r.estado === 'Aprobada' || r.estado === 'Parcial') && !fullyReceived && (
                            <button className="btn btn-xs btn-primary" onClick={() => openRecv(r)} title="Recibir">
                              <PackageCheck size={11} /> Recibir
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                    {isExp && (
                      <tr>
                        <td colSpan={8} style={{ padding: 0 }}>
                          <div style={{ padding: '8px 12px 12px 48px', background: 'var(--c-bg)', borderBottom: '1px solid var(--c-border)' }}>
                            {r.obs && <div style={{ fontSize: 12, color: 'var(--c-text-3)', marginBottom: 8 }}>📝 {r.obs}</div>}
                            <table style={{ fontSize: 11 }}>
                              <thead><tr>
                                <th>Código</th><th>Descripción</th>
                                <th>Cantidad</th><th>Recibido</th><th>Pendiente</th>
                                <th>Precio unit.</th><th>Subtotal</th>
                              </tr></thead>
                              <tbody>{r.items.map(i => {
                                const pend = i.cantidad - (i.cantidad_recibida || 0)
                                return (
                                  <tr key={i.id}>
                                    <td><b>{i.mat_codigo || '—'}</b></td>
                                    <td>{i.mat_desc || i.descripcion_libre}</td>
                                    <td>{i.cantidad} {i.unidad}</td>
                                    <td style={{ color: 'var(--c-green)' }}>{i.cantidad_recibida || 0}</td>
                                    <td style={{ color: pend > 0 ? 'var(--c-amber)' : 'var(--c-text-3)' }}>{pend}</td>
                                    <td>{fmtMoney(i.precio_unit)}</td>
                                    <td><b>{fmtMoney(i.precio_unit * i.cantidad)}</b></td>
                                  </tr>
                                )
                              })}</tbody>
                            </table>
                          </div>
                        </td>
                      </tr>
                    )}
                  </Fragment>
                )
              })}</tbody>
            </table></div>
          )}
      </Card>

      {/* Create OC */}
      <Modal open={open} onClose={() => setOpen(false)} title="Nueva orden de compra" size="xl"
        footer={<>
          <button className="btn" onClick={() => setOpen(false)}>Cancelar</button>
          <button className="btn btn-primary" onClick={save}>Crear OC</button>
        </>}
      >
        <div className="alert-banner alert-info" style={{ marginBottom: 14 }}>
          Si el total supera el límite de aprobación ($50.000), la OC queda <b>Pendiente de aprobación</b>.
        </div>
        <div className="form-grid">
          <Field label="Proveedor" required>
            <select className="form-select" {...ocForm.bind('proveedor_id')}>
              <option value="">— Seleccionar —</option>
              {provs.map(p => <option key={p.id} value={p.id}>{p.razon}</option>)}
            </select>
          </Field>
          <Field label="Fecha entrega estimada">
            <input className="form-input" type="date" {...ocForm.bind('fecha_entrega_est')} />
          </Field>
          <Field label="Observaciones" span2>
            <textarea className="form-textarea" {...ocForm.bind('obs')} />
          </Field>
        </div>

        <div style={{ marginTop: 16, marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <h3 style={{ fontSize: 14, fontWeight: 600, margin: 0 }}>Ítems</h3>
          <button className="btn btn-sm btn-primary" onClick={addItem}><Plus size={12} /> Agregar ítem</button>
        </div>

        <table style={{ fontSize: 12 }}>
          <thead><tr>
            <th>Material</th><th>O descripción libre</th>
            <th>Cantidad</th><th>Unidad</th><th>Precio unit.</th><th></th>
          </tr></thead>
          <tbody>{items.map((it, idx) => (
            <tr key={idx}>
              <td>
                <select className="form-select" style={{ width: 200 }} value={it.material_id}
                  onChange={e => selectMat(idx, e.target.value)}>
                  <option value="">— Sin material catálogo —</option>
                  {mats.map(m => <option key={m.id} value={m.id}>{m.codigo} — {m.descripcion}</option>)}
                </select>
              </td>
              <td>
                <input className="form-input" style={{ width: 180 }} value={it.descripcion_libre}
                  onChange={e => updateItem(idx, { descripcion_libre: e.target.value })}
                  placeholder="Servicio, accesorio..." />
              </td>
              <td>
                <input className="form-input" type="number" min="0.001" step="0.001" style={{ width: 80 }}
                  value={it.cantidad} onChange={e => updateItem(idx, { cantidad: e.target.value })} />
              </td>
              <td>
                <input className="form-input" style={{ width: 60 }} value={it.unidad}
                  onChange={e => updateItem(idx, { unidad: e.target.value })} />
              </td>
              <td>
                <input className="form-input" type="number" min="0" step="0.01" style={{ width: 100 }}
                  value={it.precio_unit} onChange={e => updateItem(idx, { precio_unit: e.target.value })} />
              </td>
              <td>
                {items.length > 1 && (
                  <button className="btn btn-xs btn-danger" onClick={() => removeItem(idx)}><Trash2 size={10} /></button>
                )}
              </td>
            </tr>
          ))}</tbody>
        </table>

        <div style={{ marginTop: 12, textAlign: 'right', fontSize: 14 }}>
          <b>Total: {fmtMoney(
            items.reduce((s, i) => s + Number(i.cantidad) * Number(i.precio_unit), 0)
          )}</b>
        </div>
      </Modal>

      {/* Receive OC */}
      <Modal open={!!recvOC} onClose={() => setRecvOC(null)}
        title={recvOC ? `Recibir mercadería — ${recvOC.numero}` : ''} size="lg"
        footer={<>
          <button className="btn" onClick={() => setRecvOC(null)}>Cancelar</button>
          <button className="btn btn-primary" onClick={saveRecv}>Registrar recepción</button>
        </>}
      >
        {recvOC && (
          <>
            <div className="alert-banner alert-info" style={{ marginBottom: 14 }}>
              Para materiales se generará automáticamente un lote.
              Ajustá las cantidades a las realmente recibidas.
            </div>
            <table>
              <thead><tr>
                <th>Material</th><th>Pedido</th><th>Recibido</th><th>Pendiente</th><th>Recibir ahora</th>
              </tr></thead>
              <tbody>{recvOC.items.map(i => {
                const pend = i.cantidad - (i.cantidad_recibida || 0)
                return (
                  <tr key={i.id}>
                    <td style={{ fontSize: 12 }}>
                      <b>{i.mat_codigo || '—'}</b> {i.mat_desc || i.descripcion_libre}
                    </td>
                    <td style={{ fontSize: 12 }}>{i.cantidad} {i.unidad}</td>
                    <td style={{ fontSize: 12, color: 'var(--c-green)' }}>{i.cantidad_recibida || 0}</td>
                    <td style={{ fontSize: 12, color: 'var(--c-amber)' }}>{pend}</td>
                    <td>
                      <input className="form-input" type="number" min="0" max={pend} step="0.001"
                        style={{ width: 100 }}
                        value={recvQtys[i.id] || ''}
                        onChange={e => setRecvQtys(prev => ({ ...prev, [i.id]: e.target.value }))} />
                    </td>
                  </tr>
                )
              })}</tbody>
            </table>
          </>
        )}
      </Modal>
    </div>
  )
}
