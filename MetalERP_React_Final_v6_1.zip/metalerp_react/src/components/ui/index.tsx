import type { ReactNode } from 'react'
import { X, Search, Plus, RefreshCw } from 'lucide-react'

// ── Modal ─────────────────────────────────────────────────────────────────────
interface ModalProps {
  open: boolean
  onClose: () => void
  title: string
  children: ReactNode
  footer?: ReactNode
  size?: 'sm' | 'md' | 'lg' | 'xl'
}

const MODAL_WIDTHS = { sm: 420, md: 580, lg: 760, xl: 960 }

export function Modal({ open, onClose, title, children, footer, size = 'md' }: ModalProps) {
  if (!open) return null
  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onClose()}>
      <div className="modal" style={{ maxWidth: MODAL_WIDTHS[size] }}>
        <div className="modal-header">
          <span className="modal-title">{title}</span>
          <button className="modal-close" onClick={onClose}><X size={16}/></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-footer">{footer}</div>}
      </div>
    </div>
  )
}

// ── Badge ─────────────────────────────────────────────────────────────────────
export type BadgeVariant = 'green' | 'amber' | 'red' | 'blue' | 'gray' | 'purple' | 'teal'

// Centralized status → variant mapping. New statuses only added here.
const STATUS_MAP: Record<string, BadgeVariant> = {
  // Generic states
  Pendiente: 'amber', 'En proceso': 'blue', Completada: 'green', Cancelada: 'gray',
  // Approvals
  Aprobado: 'green', Rechazado: 'red', Ingresado: 'amber', Agotado: 'gray',
  // Documents
  Recibida: 'blue', Confirmada: 'teal', Borrador: 'gray', Enviado: 'blue',
  Facturado: 'teal', Abierto: 'red', Cerrado: 'gray',
  // OTT
  'Remito emitido': 'blue', Recibido: 'teal', Completado: 'green',
  // People / things
  Activo: 'green', Inactivo: 'gray',
  Operativa: 'green', 'En mantenimiento': 'amber', 'Fuera de servicio': 'red',
  // Priority
  Alta: 'red', Normal: 'blue', Crítica: 'red',
  // Tipos
  Directo: 'blue', Indirecto: 'purple',
}

export function Badge({ value, variant }: { value: string; variant?: BadgeVariant }) {
  const v = variant ?? STATUS_MAP[value] ?? 'gray'
  return <span className={`badge badge-${v}`}>{value}</span>
}

// ── Loading + Empty ───────────────────────────────────────────────────────────
export function PageLoading({ text = 'Cargando...' }: { text?: string }) {
  return (
    <div className="page-loading">
      <span className="spinner" />
      <span>{text}</span>
    </div>
  )
}

export function EmptyState({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="empty-state">
      <h3>{title}</h3>
      {desc && <p>{desc}</p>}
      {action && <div className="mt-2">{action}</div>}
    </div>
  )
}

// ── Toolbar — replaces ~24 repeated div-with-flex headers ─────────────────────
interface ToolbarProps {
  title: string
  search?: string
  onSearch?: (v: string) => void
  searchPlaceholder?: string
  onReload?: () => void
  primaryLabel?: string
  onPrimary?: () => void
  rightChildren?: ReactNode
  badge?: ReactNode
}

export function Toolbar({
  title, search, onSearch, searchPlaceholder = 'Buscar...',
  onReload, primaryLabel, onPrimary, rightChildren, badge,
}: ToolbarProps) {
  return (
    <div className="toolbar">
      <h2 className="page-title">{title}</h2>
      {badge}
      {onSearch !== undefined && (
        <div className="search-wrap">
          <Search size={14} className="search-icon" />
          <input
            className="form-input"
            style={{ paddingLeft: 30, width: 220 }}
            placeholder={searchPlaceholder}
            value={search ?? ''}
            onChange={e => onSearch(e.target.value)}
          />
        </div>
      )}
      {rightChildren}
      {onReload && (
        <button className="btn" onClick={onReload} title="Recargar">
          <RefreshCw size={14} />
        </button>
      )}
      {primaryLabel && onPrimary && (
        <button className="btn btn-primary" onClick={onPrimary}>
          <Plus size={14} /> {primaryLabel}
        </button>
      )}
    </div>
  )
}

// ── Card with optional title (factored from 50+ inline card uses) ─────────────
export function Card({
  title, action, children, padded = true,
}: { title?: string; action?: ReactNode; children: ReactNode; padded?: boolean }) {
  return (
    <div className="card" style={padded ? undefined : { padding: 0 }}>
      {title && (
        <div className="card-header">
          <span className="card-title">{title}</span>
          {action}
        </div>
      )}
      {children}
    </div>
  )
}

// ── Confirm button ────────────────────────────────────────────────────────────
export function ConfirmBtn({
  onConfirm, children, danger = true, size = 'sm', confirmText = '¿Confirmar esta acción?',
}: {
  onConfirm: () => void; children: ReactNode; danger?: boolean
  size?: 'xs' | 'sm'; confirmText?: string
}) {
  return (
    <button
      className={`btn btn-${size} ${danger ? 'btn-danger' : ''}`}
      onClick={e => { e.stopPropagation(); if (window.confirm(confirmText)) onConfirm() }}
    >
      {children}
    </button>
  )
}

// ── Form field — replaces label+input boilerplate ─────────────────────────────
interface FieldProps {
  label: string
  required?: boolean
  span2?: boolean
  hint?: string
  children: ReactNode
}

export function Field({ label, required, span2, hint, children }: FieldProps) {
  return (
    <div className={`form-group${span2 ? ' col-span-2' : ''}`}>
      <label className="form-label">
        {label}{required && ' *'}
      </label>
      {children}
      {hint && <span className="form-hint">{hint}</span>}
    </div>
  )
}

// ── Stat card — used by both dashboards ───────────────────────────────────────
export function StatCard({
  label, value, sub, icon, color,
}: { label: string; value: string | number; sub?: string; icon?: ReactNode; color?: string }) {
  return (
    <div className="stat-card">
      <div className="stat-content">
        <div>
          <div className="stat-label">{label}</div>
          <div className="stat-value">{value}</div>
          {sub && <div className="stat-sub">{sub}</div>}
        </div>
        {icon && (
          <div className="stat-icon" style={color ? { background: `${color}18`, color } : undefined}>
            {icon}
          </div>
        )}
      </div>
    </div>
  )
}

// ── Progress bar (used in 6+ pages) ───────────────────────────────────────────
export function ProgressBar({
  value, max = 100, color,
}: { value: number; max?: number; color?: string }) {
  const pct = Math.min((value / max) * 100, 100)
  return (
    <div className="progress-bar">
      <div
        className="progress-fill"
        style={{ width: `${pct}%`, ...(color ? { background: color } : {}) }}
      />
    </div>
  )
}

// ── Helpers (formatting) ──────────────────────────────────────────────────────
export function fmtDate(s: string | null | undefined): string {
  if (!s) return '—'
  return s.slice(0, 10).split('-').reverse().join('/')
}

export function fmtMoney(n: number | null | undefined): string {
  if (n == null) return '—'
  return '$' + Math.round(n).toLocaleString('es-AR')
}

/** Calculate a color for a rendimiento/completion percentage. */
export function rendimientoColor(pct: number): string {
  if (pct >= 90) return 'var(--c-green)'
  if (pct >= 70) return 'var(--c-primary)'
  if (pct >= 50) return 'var(--c-amber)'
  return 'var(--c-red)'
}
