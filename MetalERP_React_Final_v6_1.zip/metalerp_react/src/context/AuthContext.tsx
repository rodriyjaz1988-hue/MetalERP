import { createContext, useContext, useEffect, useState } from 'react'
import type { ReactNode } from 'react'
import { api } from '../api/client'

export interface User {
  nombre: string
  rol: 'admin' | 'operario' | 'vendedor' | 'almacen' | string
  perms: Record<string, string>
}

interface AuthCtx {
  user: User | null
  loading: boolean
  login: (username: string, password: string) => Promise<void>
  logout: () => Promise<void>
}

const AuthContext = createContext<AuthCtx | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.me()
      .then(d => { if (d.auth) setUser({ nombre: d.nombre, rol: d.rol, perms: d.perms || {} }) })
      .catch(() => {})
      .finally(() => setLoading(false))
  }, [])

  async function login(username: string, password: string) {
    const d = await api.login(username, password)
    if (!d.ok) throw new Error('Credenciales incorrectas')
    const me = await api.me()
    setUser({ nombre: me.nombre, rol: me.rol, perms: me.perms || {} })
  }

  async function logout() {
    await api.logout()
    setUser(null)
  }

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
