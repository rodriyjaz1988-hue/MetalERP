// ── Auth ─────────────────────────────────────────────────────────────────────
export interface User {
  id: number
  username: string
  nombre: string
  rol: 'admin' | 'operario' | 'vendedor' | 'almacen'
  perms: Record<string, string>
}

// ── API helpers ───────────────────────────────────────────────────────────────
export interface ApiError {
  error: string
}

// ── Dashboard ─────────────────────────────────────────────────────────────────
export interface DashOperativo {
  ot_activas: number
  ot_completadas_mes: number
  lotes_pendientes: number
  tickets_abiertos: number
  stock_critico: number
  maquinas_fuera: number
  ots_por_estado: { estado: string; cantidad: number }[]
  ots_recientes: OT[]
  ots_urgentes: OT[]
  alertas_mat: number
  alertas_tkt: number
  eficiencia_ops: { avg_rend: number; total_novedades: number } | null
}

export interface DashEconomico {
  facturacion_mes: number
  valor_pedidos: number
  valor_produccion: number
  pedidos_activos: number
  compras_pendientes: number
  monto_compras_pend: number
  ocs_compra_pend: number
  top_clientes: { cliente: string; total: number }[]
  presupuestos_estado: { estado: string; cantidad: number; total: number }[]
  facturacion_historico: { mes: string; total: number }[]
}

export interface RendimientoSemanal {
  semanas: { semana: string; fecha_inicio: string; avg_rend: number; novedades: number; total_prod: number }[]
  semana_actual: string
}

// ── Entidades ─────────────────────────────────────────────────────────────────
export interface OT {
  id: number
  numero: string
  descripcion: string
  producto_id: number | null
  producto_nombre: string | null
  producto_codigo: string | null
  cliente_id: number | null
  cliente_nombre: string | null
  cantidad: number
  estado: string
  prioridad: number
  fecha_inicio: string | null
  fecha_entrega: string | null
  costo_mat: number
  costo_mo: number
}

export interface Producto {
  id: number
  codigo: string
  nombre: string
  descripcion: string | null
  categoria_id: number | null
  categoria_nombre: string | null
  cliente_id: number | null
  cliente_nombre: string | null
  unidad: string
  precio_venta: number
  costo_mat: number
  costo_mo: number
  peso_kg: number
  tiempo_ciclo_total_min: number | null
  activo: number
}

export interface Cliente {
  id: number
  razon: string
  cuit: string | null
  contacto: string | null
  email: string | null
  telefono: string | null
  categoria: string
  plazo_pago: string | null
}

export interface Material {
  id: number
  codigo: string
  descripcion: string
  categoria: string
  unidad: string
  stock: number
  stock_min: number
  precio_unit: number
}

export interface Lote {
  id: number
  numero: string
  material_id: number
  mat_codigo: string
  mat_descripcion: string
  cantidad_original: number
  cantidad_disponible: number
  cantidad_activa: number
  estado: 'Ingresado' | 'Aprobado' | 'Agotado' | 'Rechazado'
  proveedor_id: number | null
  fecha_ingreso: string
}

export interface OrdenCliente {
  id: number
  numero: string
  cliente_id: number
  cliente_nombre: string
  fecha: string | null
  fecha_entrega: string | null
  estado: string
  items: OCItem[]
}

export interface OCItem {
  id: number
  orden_cliente_id: number
  producto_id: number
  producto_codigo: string
  producto_nombre: string
  cantidad: number
  precio_unit: number
  fecha_deseada: string | null
  unidad: string
  ot_id: number | null
  ot_numero: string | null
}
