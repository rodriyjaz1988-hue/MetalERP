import { useEffect, useState } from 'react'
import { api } from '../api/client'
import { useToast } from '../context/ToastContext'
import {
  ClipboardList, AlertTriangle, Package, Wrench,
  TrendingUp, CheckCircle
} from 'lucide-react'

interface OTReciente {
  id: number; numero: string; producto_nombre: string | null
  descripcion: string; estado: string; fecha_entrega: string | null
  prioridad: number
}

interface DashOp {
  ot_activas: number
  ot_completadas_mes: number
  lotes_pendientes: number
  tickets_abiertos: number
  stock_critico: number
  maquinas_fuera: number
  ots_recientes: OTReciente[]
  ots_urgentes: OTReciente[]
  eficiencia_ops: { avg_rend: number; total_novedades: number } | null
}

interface RendSem {
  semanas: { semana: string; fecha_inicio: string; avg_rend: number; novedades: number; total_prod: number }[]
  semana_actual: string
}

const ESTADO_BADGE: Record<string, string> = {
  Pendiente: 'badge badge-amber',
  'En proceso': 'badge badge-blue',
  Completada: 'badge badge-green',
  Cancelada: 'badge badge-gray',
}

function fmtD(s: string | null) {
  if (!s) return '—'
  return s.slice(0, 10).split('-').reverse().join('/')
}

export default function DashOperativo() {
  const toast = useToast()
  const [dash, setDash] = useState<DashOp | null>(null)
  const [rend, setRend] = useState<RendSem | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    Promise.all([api.dashOperativo(), api.dashRendimiento()])
      .then(([d, r]) => { setDash(d); setRend(r) })
      .catch(() => toast('Error cargando dashboard', 'error'))
      .finally(() => setLoading(false))
  }, [])

  if (loading) return <div className="page-loading"><span className="spinner" /> Cargando...</div>
  if (!dash) return null

  const stats = [
    { label: 'OTs activas',        value: dash.ot_activas,         icon: <ClipboardList size={18}/>, color: 'var(--c-primary)' },
    { label: 'Completadas (mes)',   value: dash.ot_completadas_mes, icon: <CheckCircle size={18}/>,  color: 'var(--c-green)' },
    { label: 'Lotes pendientes',    value: dash.lotes_pendientes,   icon: <Package size={18}/>,      color: 'var(--c-amber)' },
    { label: 'Stock crítico',       value: dash.stock_critico,      icon: <AlertTriangle size={18}/>,color: 'var(--c-red)' },
    { label: 'Máquinas fuera',      value: dash.maquinas_fuera,     icon: <Wrench size={18}/>,       color: '#6B7280' },
    { label: 'Eficiencia promedio', value: dash.eficiencia_ops ? `${dash.eficiencia_ops.avg_rend}%` : '—',
      icon: <TrendingUp size={18}/>, color: 'var(--c-green)' },
  ]

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 20 }}>
      <h2 style={{ fontSize: 18, fontWeight: 700 }}>Dashboard Producción / Calidad</h2>

      {/* Stats grid */}
      <div className="grid-3" style={{ gridTemplateColumns: 'repeat(3, 1fr)' }}>
        {stats.map(s => (
          <div key={s.label} className="stat-card">
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div className="stat-label">{s.label}</div>
                <div className="stat-value">{s.value}</div>
              </div>
              <div style={{
                width: 38, height: 38, borderRadius: 10, background: `${s.color}18`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                color: s.color, flexShrink: 0,
              }}>{s.icon}</div>
            </div>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 }}>
        {/* OTs recientes */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">OTs activas recientes</span>
          </div>
          {dash.ots_recientes.length === 0
            ? <div className="empty-state"><p>Sin OTs activas</p></div>
            : <div className="table-wrap">
                <table>
                  <thead><tr>
                    <th>N° OT</th><th>Descripción</th><th>Estado</th><th>Entrega</th>
                  </tr></thead>
                  <tbody>
                    {dash.ots_recientes.slice(0, 8).map(o => (
                      <tr key={o.id}>
                        <td><span className="font-bold font-mono" style={{ fontSize: 12 }}>{o.numero}</span></td>
                        <td className="truncate" style={{ maxWidth: 160, fontSize: 12 }}>
                          {o.producto_nombre || o.descripcion}
                        </td>
                        <td><span className={ESTADO_BADGE[o.estado] || 'badge badge-gray'}>{o.estado}</span></td>
                        <td style={{ fontSize: 12 }}>{fmtD(o.fecha_entrega)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
          }
        </div>

        {/* OTs urgentes */}
        <div className="card">
          <div className="card-header">
            <span className="card-title">⚠ OTs urgentes (próx. 5 días)</span>
          </div>
          {dash.ots_urgentes.length === 0
            ? <div className="empty-state"><p>Sin entregas urgentes</p></div>
            : <div className="table-wrap">
                <table>
                  <thead><tr><th>N° OT</th><th>Producto</th><th>Entrega</th></tr></thead>
                  <tbody>
                    {dash.ots_urgentes.map(o => (
                      <tr key={o.id}>
                        <td><span className="font-bold font-mono" style={{ fontSize: 12 }}>{o.numero}</span></td>
                        <td style={{ fontSize: 12 }}>{o.producto_nombre || o.descripcion}</td>
                        <td>
                          <span style={{ color: 'var(--c-red)', fontWeight: 600, fontSize: 12 }}>
                            {fmtD(o.fecha_entrega)}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
          }
        </div>
      </div>

      {/* Rendimiento semanal */}
      <div className="card">
        <div className="card-header">
          <span className="card-title">Rendimiento semanal — últimas 26 semanas</span>
        </div>
        {!rend || rend.semanas.length === 0
          ? <div className="empty-state"><p>Sin novedades registradas en las últimas 26 semanas.</p></div>
          : <div style={{ overflowX: 'auto' }}>
              <table>
                <thead><tr>
                  <th>Semana</th>
                  <th style={{ minWidth: 220 }}>Rendimiento promedio</th>
                  <th>Novedades</th>
                  <th>Producido</th>
                </tr></thead>
                <tbody>
                  {rend.semanas.map(s => {
                    const pct = Math.min(s.avg_rend || 0, 100)
                    const isActual = s.semana === rend.semana_actual
                    const color = pct >= 90 ? 'var(--c-green)' : pct >= 70 ? 'var(--c-primary)' : pct >= 50 ? 'var(--c-amber)' : 'var(--c-red)'
                    return (
                      <tr key={s.semana} style={{ background: isActual ? 'var(--c-primary-lt)' : undefined }}>
                        <td style={{ fontWeight: isActual ? 700 : undefined, color: isActual ? 'var(--c-primary)' : undefined, fontSize: 12, whiteSpace: 'nowrap' }}>
                          {fmtD(s.fecha_inicio)}{isActual ? ' ◀ actual' : ''}
                        </td>
                        <td>
                          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                            <div className="progress-bar" style={{ flex: 1 }}>
                              <div className="progress-fill" style={{ width: `${pct}%`, background: color }} />
                            </div>
                            <span style={{ fontSize: 12, fontWeight: 600, color, minWidth: 36 }}>{pct}%</span>
                          </div>
                        </td>
                        <td style={{ fontSize: 12, textAlign: 'center' }}>{s.novedades || 0}</td>
                        <td style={{ fontSize: 12, textAlign: 'center' }}>{s.total_prod || 0}</td>
                      </tr>
                    )
                  })}
                </tbody>
              </table>
            </div>
        }
      </div>
    </div>
  )
}
