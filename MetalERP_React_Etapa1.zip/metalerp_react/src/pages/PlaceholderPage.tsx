interface PlaceholderProps {
  module: string
}

const MODULE_LABELS: Record<string, string> = {
  dash_economico: 'Dashboard Económico',
  ordenes: 'Órdenes de trabajo',
  procesos: 'Procesos / Productos',
  ctrl_prod: 'Control de producción',
  novedades_ot: 'Novedades por OT',
  mrp: 'Planificación MRP',
  ott: 'OTT — Terceros',
  maquinas: 'Máquinas',
  rrhh: 'Recursos humanos',
  rendimiento: 'Rendimiento operarios',
  inventario: 'Inventario',
  movimientos: 'Movimientos',
  lotes: 'Lotes',
  remitir: 'Remitir a cliente',
  presupuestos: 'Presupuestos',
  clientes: 'Clientes',
  oc_clientes: 'Pedidos de clientes',
  solicitudes: 'Solicitudes de compra',
  proveedores: 'Proveedores',
  liberacion_lotes: 'Liberación de lotes',
  configuracion: 'Configuración',
  carga_masiva: 'Carga masiva',
  usuarios: 'Usuarios',
}

export default function PlaceholderPage({ module }: PlaceholderProps) {
  const label = MODULE_LABELS[module] || module
  return (
    <div style={{
      display: 'flex', flexDirection: 'column', alignItems: 'center',
      justifyContent: 'center', height: 340, gap: 16,
    }}>
      <div style={{
        width: 56, height: 56, borderRadius: 14,
        background: 'var(--c-primary-lt)',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontSize: 26,
      }}>🔧</div>
      <div style={{ textAlign: 'center' }}>
        <h2 style={{ fontSize: 18, fontWeight: 700, marginBottom: 6 }}>{label}</h2>
        <p style={{ fontSize: 14, color: 'var(--c-text-3)', maxWidth: 320 }}>
          Este módulo se está migrando a React. Mientras tanto, podés acceder
          desde la versión anterior en el puerto 5000.
        </p>
      </div>
      <a
        href="http://localhost:5000"
        target="_blank"
        rel="noreferrer"
        className="btn btn-primary"
        style={{ textDecoration: 'none' }}
      >
        Abrir versión anterior →
      </a>
    </div>
  )
}
