import { useState } from 'react'
import type { FormEvent } from 'react'
import { useAuth } from '../context/AuthContext'
import { useToast } from '../context/ToastContext'

export default function LoginPage() {
  const { login } = useAuth()
  const toast = useToast()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()
    if (!username || !password) { toast('Ingresá usuario y contraseña', 'warn'); return }
    setLoading(true)
    try {
      await login(username, password)
    } catch (err: any) {
      toast(err.message || 'Credenciales incorrectas', 'error')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'linear-gradient(135deg, #1a3a5c 0%, #2C5F8A 60%, #3d7ab5 100%)',
    }}>
      <div style={{
        background: '#fff', borderRadius: 16, padding: '40px 36px',
        width: '100%', maxWidth: 400, boxShadow: '0 24px 48px rgba(0,0,0,.2)',
      }}>
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 32 }}>
          <div style={{
            width: 44, height: 44, background: 'var(--c-primary)',
            borderRadius: 12, display: 'flex', alignItems: 'center',
            justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 22,
          }}>M</div>
          <div>
            <div style={{ fontWeight: 800, fontSize: 20, letterSpacing: '-.5px', color: 'var(--c-text)' }}>
              MetalERP
            </div>
            <div style={{ fontSize: 11, color: 'var(--c-text-3)', marginTop: 1 }}>
              Sistema de gestión industrial
            </div>
          </div>
        </div>

        <h1 style={{ fontSize: 17, fontWeight: 600, marginBottom: 4 }}>Iniciar sesión</h1>
        <p style={{ fontSize: 13, color: 'var(--c-text-3)', marginBottom: 24 }}>
          Ingresá tus credenciales para continuar
        </p>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <div className="form-group">
            <label className="form-label">Usuario</label>
            <input
              className="form-input"
              placeholder="admin"
              value={username}
              onChange={e => setUsername(e.target.value)}
              autoFocus
              autoComplete="username"
            />
          </div>

          <div className="form-group">
            <label className="form-label">Contraseña</label>
            <input
              className="form-input"
              type="password"
              placeholder="••••••••"
              value={password}
              onChange={e => setPassword(e.target.value)}
              autoComplete="current-password"
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            disabled={loading}
            style={{ marginTop: 6, padding: '10px 0', fontSize: 14, justifyContent: 'center' }}
          >
            {loading ? <><span className="spinner" style={{ width: 16, height: 16 }} /> Ingresando...</> : 'Ingresar'}
          </button>
        </form>

        <p style={{ marginTop: 24, fontSize: 11, color: 'var(--c-text-3)', textAlign: 'center' }}>
          MetalERP v3 · Taller Metalúrgico
        </p>
      </div>
    </div>
  )
}
