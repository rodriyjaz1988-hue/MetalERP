// Typed API client — all requests go through here
const BASE = '/api'

async function request<T>(
  path: string,
  options?: RequestInit
): Promise<T> {
  const res = await fetch(`${BASE}${path}`, {
    headers: { 'Content-Type': 'application/json', ...options?.headers },
    ...options,
  })
  if (!res.ok) {
    const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }))
    throw new Error(err.error || `HTTP ${res.status}`)
  }
  return res.json()
}

export const api = {
  get: <T>(path: string) => request<T>(path),
  post: <T>(path: string, body: unknown) =>
    request<T>(path, { method: 'POST', body: JSON.stringify(body) }),
  put: <T>(path: string, body: unknown) =>
    request<T>(path, { method: 'PUT', body: JSON.stringify(body) }),
  delete: <T>(path: string) => request<T>(path, { method: 'DELETE' }),

  // Auth
  login: (username: string, password: string) =>
    api.post<{ ok: boolean; rol: string; nombre: string; perms: Record<string, string> }>(
      '/login', { username, password }
    ),
  logout: () => api.post<{ ok: boolean }>('/logout', {}),
  me: () => api.get<{ auth: boolean; nombre: string; rol: string; perms: Record<string, string> }>('/me'),

  // Dashboard
  dashOperativo: () => api.get<any>('/dashboard/operativo'),
  dashEconomico: () => api.get<any>('/dashboard/economico'),
  dashRendimiento: () => api.get<any>('/dashboard/rendimiento_semanal'),
  dashFacCliente: () => api.get<any>('/dashboard/facturacion_por_cliente'),

  // OTs
  ordenes: (estado?: string) =>
    api.get<any[]>(`/ordenes${estado ? `?estado=${estado}` : ''}`),
  orden: (id: number) => api.get<any>(`/ordenes/${id}`),
}
