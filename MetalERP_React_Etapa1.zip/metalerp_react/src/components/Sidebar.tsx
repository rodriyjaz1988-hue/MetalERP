import {
  LayoutDashboard, DollarSign, ClipboardList, Settings2,
  Activity, FileText, BarChart3, Wrench, Users, TrendingUp,
  Package, ArrowLeftRight, Layers, Send, Receipt, UserCheck,
  ShoppingCart, Truck, Shield, Cog, Upload, UserCog, Hexagon, ChevronRight
} from 'lucide-react'
import { useAuth } from '../context/AuthContext'

interface NavItem {
  key: string
  label: string
  icon: React.ReactNode
  section: string
}

const NAV: NavItem[] = [
  // Principal
  { key: 'dash_operativo',   label: 'Dashboard Producción', icon: <LayoutDashboard size={15}/>, section: 'Principal' },
  { key: 'dash_economico',   label: 'Dashboard Económico',  icon: <DollarSign size={15}/>,      section: 'Principal' },
  // Producción
  { key: 'ordenes',          label: 'Órdenes de trabajo',   icon: <ClipboardList size={15}/>,   section: 'Producción' },
  { key: 'procesos',         label: 'Procesos / Productos',  icon: <Settings2 size={15}/>,       section: 'Producción' },
  { key: 'ctrl_prod',        label: 'Control producción',   icon: <Activity size={15}/>,        section: 'Producción' },
  { key: 'novedades_ot',     label: 'Novedades por OT',     icon: <FileText size={15}/>,        section: 'Producción' },
  { key: 'mrp',              label: 'Planificación MRP',    icon: <BarChart3 size={15}/>,       section: 'Producción' },
  { key: 'ott',              label: 'OTT — Terceros',       icon: <Hexagon size={15}/>,         section: 'Producción' },
  // Recursos
  { key: 'maquinas',         label: 'Máquinas',             icon: <Wrench size={15}/>,          section: 'Recursos' },
  { key: 'rrhh',             label: 'Recursos humanos',     icon: <Users size={15}/>,           section: 'Recursos' },
  { key: 'rendimiento',      label: 'Rendimiento',          icon: <TrendingUp size={15}/>,      section: 'Recursos' },
  // Depósito
  { key: 'inventario',       label: 'Inventario',           icon: <Package size={15}/>,         section: 'Depósito' },
  { key: 'movimientos',      label: 'Movimientos',          icon: <ArrowLeftRight size={15}/>,  section: 'Depósito' },
  { key: 'lotes',            label: 'Lotes',                icon: <Layers size={15}/>,          section: 'Depósito' },
  { key: 'remitir',          label: 'Remitir a cliente',    icon: <Send size={15}/>,            section: 'Depósito' },
  // Ventas
  { key: 'presupuestos',     label: 'Presupuestos',         icon: <Receipt size={15}/>,         section: 'Ventas' },
  { key: 'clientes',         label: 'Clientes',             icon: <UserCheck size={15}/>,       section: 'Ventas' },
  { key: 'oc_clientes',      label: 'Pedidos de clientes',  icon: <ShoppingCart size={15}/>,    section: 'Ventas' },
  // Compras
  { key: 'solicitudes',      label: 'Solicitudes',          icon: <FileText size={15}/>,        section: 'Compras' },
  { key: 'proveedores',      label: 'Proveedores',          icon: <Truck size={15}/>,           section: 'Compras' },
  // Calidad
  { key: 'liberacion_lotes', label: 'Liberación de lotes',  icon: <Shield size={15}/>,          section: 'Calidad' },
  // Sistema
  { key: 'configuracion',    label: 'Configuración',        icon: <Cog size={15}/>,             section: 'Sistema' },
  { key: 'carga_masiva',     label: 'Carga masiva',         icon: <Upload size={15}/>,          section: 'Sistema' },
  { key: 'usuarios',         label: 'Usuarios',             icon: <UserCog size={15}/>,         section: 'Sistema' },
]

interface SidebarProps {
  active: string
  onNavigate: (key: string) => void
}

export default function Sidebar({ active, onNavigate }: SidebarProps) {
  const { user } = useAuth()
  const isAdmin = user?.rol === 'admin'

  const visible = NAV.filter(item => {
    if (item.key === 'usuarios' && !isAdmin) return false
    if (!user) return false
    const perm = user.perms[`mod_${item.key}`]
    if (perm === '0' && !isAdmin) return false
    return true
  })

  const sections = [...new Set(visible.map(i => i.section))]

  return (
    <nav className="sidebar">
      {/* Logo */}
      <div className="sidebar-logo">
        <div className="sidebar-logo-icon">M</div>
        <div>
          <div className="sidebar-logo-text">MetalERP</div>
          <div className="sidebar-logo-ver">v3 · Taller Metalúrgico</div>
        </div>
      </div>

      {/* Nav items grouped by section */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {sections.map(section => (
          <div key={section} className="nav-section">
            <div className="nav-section-label">{section}</div>
            {visible.filter(i => i.section === section).map(item => (
              <button
                key={item.key}
                className={`nav-item${active === item.key ? ' active' : ''}`}
                onClick={() => onNavigate(item.key)}
              >
                {item.icon}
                <span style={{ flex: 1 }}>{item.label}</span>
                {active === item.key && <ChevronRight size={12} style={{ opacity: .5 }}/>}
              </button>
            ))}
          </div>
        ))}
      </div>

      {/* User info at bottom */}
      {user && (
        <div style={{
          padding: '12px 16px',
          borderTop: '1px solid var(--c-border)',
          display: 'flex', alignItems: 'center', gap: 8,
        }}>
          <div className="header-avatar" style={{ width: 28, height: 28, fontSize: 11 }}>
            {user.nombre.charAt(0).toUpperCase()}
          </div>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, fontWeight: 600, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
              {user.nombre}
            </div>
            <div style={{ fontSize: 10, color: 'var(--c-text-3)' }}>{user.rol}</div>
          </div>
        </div>
      )}
    </nav>
  )
}
