import { useAuth } from './context/AuthContext'
import LoginPage from './pages/LoginPage'
import AppShell from './pages/AppShell'

export default function App() {
  const { user, loading } = useAuth()

  if (loading) {
    return (
      <div style={{
        minHeight: '100vh', display: 'flex',
        alignItems: 'center', justifyContent: 'center',
        background: 'var(--c-bg)',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 12, color: 'var(--c-text-3)' }}>
          <span className="spinner" style={{ width: 24, height: 24 }} />
          <span>Iniciando MetalERP...</span>
        </div>
      </div>
    )
  }

  return user ? <AppShell /> : <LoginPage />
}
