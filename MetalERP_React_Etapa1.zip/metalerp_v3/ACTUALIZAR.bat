@echo off
echo ====================================================
echo   MetalERP v3 - Actualizador
echo ====================================================
echo.
echo Este ZIP contiene: server.py, app.html, login.html
echo Tu base de datos NO sera modificada.
echo.
echo Ingresa la ruta completa a tu carpeta metalerp_v3
echo (la que contiene server.py e INICIAR_SERVIDOR.bat)
echo.
echo Ejemplo: C:\Users\mklei\Desktop\metalerp_v3
echo.
set /p INSTALL_DIR=Ruta: 

if not exist "%INSTALL_DIR%\server.py" (
    echo.
    echo ERROR: No se encontro server.py en "%INSTALL_DIR%"
    echo Verifica la ruta e intenta nuevamente.
    pause
    exit /b 1
)

echo.
echo Actualizando archivos en: %INSTALL_DIR%
echo.

copy /Y "%~dp0server.py" "%INSTALL_DIR%\server.py"
copy /Y "%~dp0templates\app.html" "%INSTALL_DIR%\templates\app.html"
copy /Y "%~dp0templates\login.html" "%INSTALL_DIR%\templates\login.html"

echo.
echo ====================================================
echo   Listo. Reinicia INICIAR_SERVIDOR.bat
echo ====================================================
pause
