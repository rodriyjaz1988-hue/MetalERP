import { useState } from 'react'
import Sidebar from '../components/Sidebar'
import DashOperativo from './DashOperativo'
import DashEconomico from './DashEconomico'
import OrdenesPage from './OrdenesPage'
import ProcesosPage from './ProcesosPage'
import OTTPage from './OTTPage'
import InventarioPage from './InventarioPage'
import LotesPage from './LotesPage'
import LiberacionPage from './LiberacionPage'
import ClientesPage from './ClientesPage'
import OCClientesPage from './OCClientesPage'
import ProveedoresPage from './ProveedoresPage'
import SolicitudesPage from './SolicitudesPage'
import MRPPage from './MRPPage'
import PlaceholderPage from './PlaceholderPage'
import { useAuth } from '../context/AuthContext'
import { LogOut, Menu } from 'lucide-react'

const PAGE_TITLES: Record<string, string> = {
  dash_operativo:   'Dashboard Producción / Calidad',
  dash_economico:   'Dashboard Económico / Financiero',
  ordenes:          'Órdenes de trabajo',
  procesos:         'Procesos / Productos',
  ctrl_prod:        'Control de producción',
  novedades_ot:     'Novedades por OT',
  mrp:              'Planificación MRP',
  ott:              'OTT — Órdenes de Trabajo de Terceros',
  maquinas:         'Máquinas',
  rrhh:             'Recursos humanos',
  rendimiento:      'Rendimiento operarios',
  inventario:       'Inventario',
  movimientos:      'Movimientos',
  lotes:            'Lotes',
  remitir:          'Remitir a cliente',
  presupuestos:     'Presupuestos',
  clientes:         'Clientes',
  oc_clientes:      'Pedidos de clientes',
  solicitudes:      'Solicitudes de compra',
  proveedores:      'Proveedores',
  liberacion_lotes: 'Liberación de lotes',
  configuracion:    'Configuración del sistema',
  carga_masiva:     'Carga masiva',
  usuarios:         'Usuarios',
}

export default function AppShell() {
  const { user, logout } = useAuth()
  const [active, setActive] = useState('dash_operativo')
  const [sidebarOpen, setSidebarOpen] = useState(true)

  function renderPage() {
    switch (active) {
      case 'dash_operativo':   return <DashOperativo />
      case 'dash_economico':   return <DashEconomico />
      case 'ordenes':          return <OrdenesPage />
      case 'procesos':         return <ProcesosPage />
      case 'ott':              return <OTTPage />
      case 'inventario':       return <InventarioPage />
      case 'lotes':            return <LotesPage />
      case 'liberacion_lotes': return <LiberacionPage />
      case 'clientes':         return <ClientesPage />
      case 'oc_clientes':      return <OCClientesPage />
      case 'proveedores':      return <ProveedoresPage />
      case 'solicitudes':      return <SolicitudesPage />
      case 'mrp':              return <MRPPage />
      default:                 return <PlaceholderPage module={active} />
    }
  }

  return (
    <div className="app-shell">
      {sidebarOpen && (
        <Sidebar active={active} onNavigate={key => setActive(key)} />
      )}
      <div className="main-area">
        <header className="top-header">
          <button
            className="btn btn-sm"
            style={{ border: 'none', background: 'none', padding: '4px' }}
            onClick={() => setSidebarOpen(v => !v)}
          >
            <Menu size={18} />
          </button>
          <div className="header-title">{PAGE_TITLES[active] || active}</div>
          <div className="header-user">
            <div className="header-avatar">{user?.nombre?.charAt(0).toUpperCase()}</div>
            <span style={{ fontSize: 13 }}>{user?.nombre}</span>
            <span className="badge badge-gray" style={{ fontSize: 10 }}>{user?.rol}</span>
            <button className="btn btn-sm" onClick={logout} title="Cerrar sesión" style={{ marginLeft: 4, color: 'var(--c-text-3)' }}>
              <LogOut size={14} />
            </button>
          </div>
        </header>
        <main className="page-content">{renderPage()}</main>
      </div>
    </div>
  )
}
